#if !defined(AFX_MYFONTWRAPPER_H__8CEC83F3_7FDF_11D2_898A_0000E73336C3__INCLUDED_)
#define AFX_MYFONTWRAPPER_H__8CEC83F3_7FDF_11D2_898A_0000E73336C3__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MyFontWrapper.h : header file
//


#include "IntrinsicControl.h"
 
/////////////////////////////////////////////////////////////////////////////
// CMyFontWrapper command target

class CMyFontWrapper : public CCmdTarget 
{
friend class CIntrinsicControl;

	DECLARE_DYNCREATE(CMyFontWrapper)
	CMyFontWrapper(LPPROPERTYNOTIFYSINK pNotify=NULL);           // protected constructor used by dynamic creation

// Attributes
public:
	CFontHolder			m_FontHolder;
	FONTDESC			m_FontDesc;
	LPPROPERTYNOTIFYSINK m_pNotify;
// Operations
public:
	void InitializeFont(const FONTDESC* pFontDesc,LPDISPATCH pFontDispAmbient);
	HFONT GetFontHandle();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyFontWrapper)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
	virtual ~CMyFontWrapper();
protected:
	void Notify(void);
	// Generated message map functions
	//{{AFX_MSG(CMyFontWrapper)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CMyFontWrapper)
	afx_msg BSTR GetName();
	afx_msg void SetName(LPCTSTR lpszNewValue);
	afx_msg long GetSize();
	afx_msg void SetSize(long nNewValue);
	afx_msg BOOL GetBold();
	afx_msg void SetBold(BOOL bNewValue);
	afx_msg BOOL GetUnderline();
	afx_msg void SetUnderline(BOOL bNewValue);
	afx_msg BOOL GetItalic();
	afx_msg void SetItalic(BOOL bNewValue);
	afx_msg BOOL GetStrikethrough();
	afx_msg void SetStrikethrough(BOOL bNewValue);
	afx_msg short GetWeight();
	afx_msg void SetWeight(short nNewValue);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYFONTWRAPPER_H__8CEC83F3_7FDF_11D2_898A_0000E73336C3__INCLUDED_)
