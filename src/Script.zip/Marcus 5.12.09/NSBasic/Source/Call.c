typedef struct tagVARIANT  {
    unsigned short vt;
    unsigned short wReserved1;
    unsigned short wReserved2;
    unsigned short wReserved3;
	double d;
} VARIANT;

int callInt(void *addr, int nArgs, int *args)
{
	typedef int (*FuncType)();

	FuncType func = (FuncType)addr;

	switch (nArgs)
	{
		case 0:
			return func();
		case 1:
			return func(args[0]);
		case 2:
			return func(args[0], args[1]);
		case 3:
			return func(args[0], args[1], args[2]);
		case 4:
			return func(args[0], args[1], args[2], args[3]);
		case 5:
			return func(args[0], args[1], args[2], args[3], args[4]);
		case 6:
			return func(args[0], args[1], args[2], args[3], args[4], args[5]);
		case 7:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6]);
		case 8:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7]);
		case 9:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8]);
		case 10:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9]);
		case 11:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10]);
		case 12:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11]);
		case 13:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12]);
		case 14:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13]);
		case 15:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14]);
		case 16:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15]);
		case 17:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16]);
		case 18:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17]);
		case 19:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17], args[18]);
		case 20:
		default:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17], args[18], args[19]);
	}
}

float callFloat(void *addr, int nArgs, int *args)
{
	typedef float (*FuncType)();

	FuncType func = (FuncType)addr;

	switch (nArgs)
	{
		case 0:
			return func();
		case 1:
			return func(args[0]);
		case 2:
			return func(args[0], args[1]);
		case 3:
			return func(args[0], args[1], args[2]);
		case 4:
			return func(args[0], args[1], args[2], args[3]);
		case 5:
			return func(args[0], args[1], args[2], args[3], args[4]);
		case 6:
			return func(args[0], args[1], args[2], args[3], args[4], args[5]);
		case 7:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6]);
		case 8:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7]);
		case 9:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8]);
		case 10:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9]);
		case 11:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10]);
		case 12:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11]);
		case 13:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12]);
		case 14:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13]);
		case 15:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14]);
		case 16:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15]);
		case 17:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16]);
		case 18:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17]);
		case 19:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17], args[18]);
		case 20:
		default:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17], args[18], args[19]);
	}
}

double callDouble(void *addr, int nArgs, int *args)
{
	typedef double (*FuncType)();

	FuncType func = (FuncType)addr;

	switch (nArgs)
	{
		case 0:
			return func();
		case 1:
			return func(args[0]);
		case 2:
			return func(args[0], args[1]);
		case 3:
			return func(args[0], args[1], args[2]);
		case 4:
			return func(args[0], args[1], args[2], args[3]);
		case 5:
			return func(args[0], args[1], args[2], args[3], args[4]);
		case 6:
			return func(args[0], args[1], args[2], args[3], args[4], args[5]);
		case 7:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6]);
		case 8:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7]);
		case 9:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8]);
		case 10:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9]);
		case 11:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10]);
		case 12:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11]);
		case 13:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12]);
		case 14:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13]);
		case 15:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14]);
		case 16:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15]);
		case 17:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16]);
		case 18:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17]);
		case 19:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17], args[18]);
		case 20:
		default:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17], args[18], args[19]);
	}
}

VARIANT callVariant(void *addr, int nArgs, int *args)
{
	typedef VARIANT (*FuncType)();

	FuncType func = (FuncType)addr;

	switch (nArgs)
	{
		case 0:
			return func();
		case 1:
			return func(args[0]);
		case 2:
			return func(args[0], args[1]);
		case 3:
			return func(args[0], args[1], args[2]);
		case 4:
			return func(args[0], args[1], args[2], args[3]);
		case 5:
			return func(args[0], args[1], args[2], args[3], args[4]);
		case 6:
			return func(args[0], args[1], args[2], args[3], args[4], args[5]);
		case 7:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6]);
		case 8:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7]);
		case 9:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8]);
		case 10:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9]);
		case 11:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10]);
		case 12:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11]);
		case 13:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12]);
		case 14:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13]);
		case 15:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14]);
		case 16:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15]);
		case 17:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16]);
		case 18:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17]);
		case 19:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17], args[18]);
		case 20:
		default:
			return func(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17], args[18], args[19]);
	}
}