// FindDialog.cpp : implementation file
//

#include "stdafx.h"
#include "script.h"
#include "utility.h"
#include "FindDialog.h"

#undef _DEBUG // EMP DIKEO

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFindDialog dialog


CFindDialog::CFindDialog(CWnd* pParent /*=NULL*/)
#ifdef _WIN32_WCE_PSPC
	: CDialog(IDD_REPLACEDIALOG_PPC,pParent)
#else
	: CDialog(IDD_REPLACEDIALOG,pParent)
#endif
{
#ifdef _WIN32_WCE_PSPC
	IDD = IDD_REPLACEDIALOG_PPC;
#else
	IDD = IDD_REPLACEDIALOG;
#endif

	//{{AFX_DATA_INIT(CFindDialog)
	m_bCaseSensitive = FALSE;
	m_cstrFind = _T("");
	m_bFindAll = FALSE;
	m_cstrReplace = _T("");
	//}}AFX_DATA_INIT
	m_bShowReplaceUI=FALSE;
}


void CFindDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFindDialog)
	DDX_Control(pDX, IDC_REPLACEPROMPT, m_ctrlReplacePrompt);
	DDX_Check(pDX, IDC_CHECK1, m_bCaseSensitive);
	DDX_Text(pDX, IDC_EDIT1, m_cstrFind);
	DDV_MaxChars(pDX, m_cstrFind, 255);
	DDX_Check(pDX, IDC_CHECK2, m_bFindAll);
	DDX_Text(pDX, IDC_EDIT2, m_cstrReplace);
	DDV_MaxChars(pDX, m_cstrReplace, 255);
	DDX_Control(pDX, IDC_EDIT2, m_ctrlReplace);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFindDialog, CDialog)
	//{{AFX_MSG_MAP(CFindDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFindDialog message handlers


BOOL CFindDialog::OnInitDialog() 
{

	CDialog::OnInitDialog();
	
	if(!m_bShowReplaceUI)
	{
		m_ctrlReplace.ShowWindow(SW_HIDE);
		m_ctrlReplacePrompt.ShowWindow(SW_HIDE);
	}
#ifdef _POCKET
   TCHAR szBuf[256];

   CButton *pCheck = (CButton *)GetDlgItem( IDC_CHECK1 );
   pCheck->GetWindowText( szBuf, 255 );
   MenuStripString( szBuf, false );
   pCheck->SetWindowText( szBuf );

   pCheck = (CButton *)GetDlgItem( IDC_CHECK2 );
   pCheck->GetWindowText( szBuf, 255 );
   MenuStripString( szBuf, false );
   pCheck->SetWindowText( szBuf );
#endif

   SetSIPState( true );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
