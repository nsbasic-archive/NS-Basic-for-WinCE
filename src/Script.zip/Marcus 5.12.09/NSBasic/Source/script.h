// script.h : main header file for the SCRIPT application
//

#if !defined(AFX_SCRIPT_H__B036D131_15EF_11D2_852D_2E9E34000000__INCLUDED_)
#define AFX_SCRIPT_H__B036D131_15EF_11D2_852D_2E9E34000000__INCLUDED_

//#define JSCRIPT
#define VBSCRIPT

#if( _WIN32_WCE >= 300 ) && defined( _WIN32_WCE_PSPC )
#  define _POCKET
#  define MENU_HEIGHT 26
#else
#  undef _POCKET
#endif

//#define kDISPLAY_REFCOUNT_DEBUG_MESSAGES

#define kVersionString TEXT("v 8.0.0")
#define kMagicVNSBFileName TEXT("nsb_temp.nsb")
#define kMagicVNSBFilePath TEXT("\\temp\\nsb_temp.nsb")
#define kNSBDirName TEXT("\\nsbasic\\")
#define kVNSBPath TEXT("\\program files\\nsbasic\\vnsb.exe")
#define kVNSBAppName TEXT("VNSB.EXE")

//#define kPrefsPathName TEXT("\\program files\\ns basic\\basic prefs.txt")
#define kPrefsPathName TEXT("\\windows\\basic prefs.txt")
#define kDebugPathName TEXT("\\windows\\basic debug.txt")

#define kTabString TEXT("  ")
#define kSingleTabString TEXT(" ")

#define kMenuStringDelimiter TEXT("||")

typedef enum {LM_FULL,LM_RUNTIME,LM_DEMO,LM_INVALID} LaunchModeType;

#define kPrefSaveProtected 0x1

void doWriteDebug(wchar_t *name);

#define kEXCEPTION_BASE					100
#define kEXCEPTION_INVALID_ARGUMENTS	kEXCEPTION_BASE+1
#define kEXCEPTION_MESSAGE				kEXCEPTION_BASE+2
#define kEXCEPTION_CLASSNOTFOUND		kEXCEPTION_BASE+3
#define kEXCEPTION_NOCLASSFACTORY		kEXCEPTION_BASE+4
#define kEXCEPTION_OBJECTEXISTS			kEXCEPTION_BASE+5
#define kEXCEPTION_CANTADDNAME			kEXCEPTION_BASE+6
#define kEXCEPTION_NOMEMORY				kEXCEPTION_BASE+7
#define kEXCEPTION_CONTROLERR			kEXCEPTION_BASE+8
#define kEXCEPTION_READONLY				kEXCEPTION_BASE+9
#define kEXCEPTION_NOTSUPPORTED			kEXCEPTION_BASE+10
#define kEXCEPTION_OUTOFBOUNDS			kEXCEPTION_BASE+11
#define kBaseMenuID 0x8100


void SetFlagsForLaunchMode(void);
void doWritePrefsFile(void);
void doReadPrefsFile(void);

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "debug.h"			// debug functions

extern RECT rtDesktop;
extern RECT rtNewDesktop;
extern RECT rtTaskBar;
extern int  InitFullScreen (void);
extern int  DoFullScreen   (bool);

/////////////////////////////////////////////////////////////////////////////
// CScriptApp:
// See script.cpp for the implementation of this class
//

class CScriptApp : public CWinApp
{
public:
	CString m_strCommandLine;
	//CString m_strCmdLine;
	//CScriptApp(LPCTSTR lpszAppName, LPCTSTR lpszHelpName);
	//vb6fix
#if(_WIN32_WCE != 200)  //**MARCH99 - only HPC has help name in constructor
	CScriptApp(LPCTSTR lpszAppName);
#else
	CScriptApp(LPCTSTR lpszAppName, LPCTSTR lpszHelpName);
#endif
	void ParseCommandLine(CCommandLineInfo& rCmdInfo);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScriptApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	BOOL DoPromptFileName(CString& fileName, UINT nIDSTitle, DWORD lFlags, BOOL bOpenFileDialog, CDocTemplate* pTemplate);

	//{{AFX_MSG(CScriptApp)
	afx_msg void OnFileOpen();
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCRIPT_H__B036D131_15EF_11D2_852D_2E9E34000000__INCLUDED_)
