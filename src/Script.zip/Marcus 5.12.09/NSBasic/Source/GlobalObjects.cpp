// GlobalObjects.cpp : implementation file
//

#include "stdafx.h"
#include "script.h"
#include "GlobalObjects.h"

#undef _DEBUG // EMP DIKEO

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GlobalObjects

IMPLEMENT_DYNCREATE(GlobalObjects, CCmdTarget)

GlobalObjects::GlobalObjects()
{
	EnableAutomation();
}

GlobalObjects::~GlobalObjects()
{
}


void GlobalObjects::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}


BEGIN_MESSAGE_MAP(GlobalObjects, CCmdTarget)
	//{{AFX_MSG_MAP(GlobalObjects)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(GlobalObjects, CCmdTarget)
	//{{AFX_DISPATCH_MAP(GlobalObjects)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IGlobalObjects to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {723F20A2-2EEB-11D2-9D8D-0000E73336C3}
static const IID IID_IGlobalObjects =
{ 0x723f20a2, 0x2eeb, 0x11d2, { 0x9d, 0x8d, 0x0, 0x0, 0xe7, 0x33, 0x36, 0xc3 } };

BEGIN_INTERFACE_MAP(GlobalObjects, CCmdTarget)
	INTERFACE_PART(GlobalObjects, IID_IGlobalObjects, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GlobalObjects message handlers
