// ExecuteDialog.cpp : implementation file
//

#include "stdafx.h"
#include "script.h"
#include "ExecuteDialog.h"

#undef _DEBUG //EMP DIKEO

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExecuteDialog dialog


CExecuteDialog::CExecuteDialog(CWnd* pParent /*=NULL*/)
#ifdef _WIN32_WCE_PSPC
	: CDialog(IDD_EXECUTEDIALOG_PPC, pParent)
#else
	: CDialog(IDD_EXECUTEDIALOG, pParent)
#endif
{
#ifdef _WIN32_WCE_PSPC
	IDD = IDD_EXECUTEDIALOG_PPC;
#else
	IDD = IDD_EXECUTEDIALOG;
#endif
	//{{AFX_DATA_INIT(CExecuteDialog)
	m_cstrText = _T("");
	//}}AFX_DATA_INIT
}


void CExecuteDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExecuteDialog)
	DDX_Control(pDX, IDC_EDIT1, m_EditControl);
	DDX_Text(pDX, IDC_EDIT1, m_cstrText);
	DDV_MaxChars(pDX, m_cstrText, 5000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExecuteDialog, CDialog)
	//{{AFX_MSG_MAP(CExecuteDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExecuteDialog message handlers
