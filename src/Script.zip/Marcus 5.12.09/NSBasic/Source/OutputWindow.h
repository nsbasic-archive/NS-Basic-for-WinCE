#if !defined(AFX_OUTPUTWINDOW_H__D4FE2D23_3DDF_11D2_890A_0000E73336C3__INCLUDED_)
#define AFX_OUTPUTWINDOW_H__D4FE2D23_3DDF_11D2_890A_0000E73336C3__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// OutputWindow.h : header file
//
#include <afxtempl.h>
#include "picturebox1.h"
#include "scriptengine.h"
#include "NewOutputDialog.h"
#include "breakpointdialog.h"
#include "utility.h"

typedef class CMenuObject
{
	public: 
		DWORD	dwFlags;
		HMENU	hmenuParent;
		CString cstrKey;
		CString cstrText;
		union	{
				HMENU	hMenu;
				UINT	iID;
				};


	public:
		CMenuObject(); 
		~CMenuObject() ;
} CMenuObject;

/////////////////////////////////////////////////////////////////////////////
// COutputWindow frame

class COutputWindow : public CFrameWnd
{
	DECLARE_DYNCREATE(COutputWindow)
//protected:
	COutputWindow();           // protected constructor used by dynamic creation

// Attributes
public:
#ifdef _POCKET
	CCeCommandBar m_wndCommandBar;
#endif
	CScriptEngine *pEngine;
	CNewOutputDialog dlgOutput;

	//CMap< CString, LPCTSTR, CMenuObject, CMenuObject& > m_menus;
	CMapStringToPtr m_menus;
	CMapPtrToPtr m_menuIDMap;

	bool m_bLaunchedWithFile;
	RECT m_rectSavedBounds;
	bool m_bChaining;
	bool m_bKeyPreview;
	BOOL m_bOKButton;

	void Update();
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COutputWindow)
	public:
	virtual void OnFinalRelease();
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void PostNcDestroy();

	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~COutputWindow();

	// Generated message map functions
	//{{AFX_MSG(COutputWindow)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnClose();
	afx_msg void OnUpdateClose(CCmdUI* pCmdUI);
	afx_msg void OnHibernate();
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg LRESULT OnSettingChange(WPARAM wParam, LPARAM lParam);
	afx_msg void OnOk();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(COutputWindow)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OUTPUTWINDOW_H__D4FE2D23_3DDF_11D2_890A_0000E73336C3__INCLUDED_)
