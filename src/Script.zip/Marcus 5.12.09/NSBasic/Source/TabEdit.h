#if !defined(AFX_TABEDIT_H__0A767193_40F1_11D2_8911_0000E73336C3__INCLUDED_)
#define AFX_TABEDIT_H__0A767193_40F1_11D2_8911_0000E73336C3__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// TabEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTabEdit window

class CTabEdit : public CEdit
{
// Construction
public:
	CTabEdit();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTabEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTabEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CTabEdit)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABEDIT_H__0A767193_40F1_11D2_8911_0000E73336C3__INCLUDED_)
