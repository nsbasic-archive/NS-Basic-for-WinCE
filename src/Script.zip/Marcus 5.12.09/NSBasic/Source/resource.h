//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by script.rc
//
#define IDS_INTRINSICCONTROL2           1
#define IDB_EXECUTE                     2
#define IDB_EVALUATE                    3
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAMETEXT               129
#define IDR_OUTPUTFRAME                 139
#define IDB_COLORLOGO                   149
#define IDD_ABOUTBOX_PPC                150
#define IDB_BITMAP1                     151
#define IDD_EXECUTEDIALOG_PPC           152
#define IDD_FUNCTIONDIALOG_PPC          154
#define IDD_GOTOLINEDIALOG_PPC          155
#define IDD_INPUTLINE_PPC               156
#define IDD_REPLACEDIALOG_PPC           157
#define IDD_BREAKPOINTDIALOG_PPC        158
#define IDD_OUTPUTDIALOG                160
#define IDB_runbutton                   164
#define IDR_MENUBAR1                    166
#define IDR_MENUBAR2                    168
#define IDR_MENUBAR3                    170
#define IDR_MAINFRAME_POCKET            171
#define IDB_BITMAP2                     172
#define IDB_MAINFRAME_POCKET            172
#define IDR_TEXT_SELECTION_CM           173
#define IDD_REGISTERDIALOG              174
#define IDD_ABOUTBOX                    250
#define IDD_EXECUTEDIALOG               252
#define IDD_FUNCTIONDIALOG              254
#define IDD_GOTOLINEDIALOG              255
#define IDD_INPUTLINE                   256
#define IDD_REPLACEDIALOG               257
#define IDD_BREAKPOINTDIALOG            258
#define IDS_PREAMBLE                    768
#define IDC_EDIT1                       1008
#define IDC_EDIT2                       1009
#define IDC_VERSION                     1012
#define IDC_CHECK1                      1013
#define IDC_CHECK2                      1014
#define IDC_LIST                        1016
#define IDC_LISTSORTED                  1017
#define IDC_PICTUREBOX1                 1024
#define IDC_REPLACEPROMPT               1027
#define IDC_PICTUREBOX2                 1028
#define IDI_SCRIPTICON                  1200
#define ID_TOOLS_RUN                    32771
#define ID_TOOL_RUN                     32772
#define ID_BUTTON32775                  32775
#define ID_RUNBUTTON                    32775
#define ID_EDIT_FORMAT                  32777
#define ID_EDIT_GOTO                    32778
#define IDS_EDIT_FIND                   32779
#define ID_EDIT_FINDNEXT                32780
#define ID_PROGRAM_EXIT                 32781
#define ID_EDIT_OVERVIEW                32782
#define ID_EDIT_FINDALL                 32783
#define ID_TOOLS_EXECUTECODE            32784
#define ID_TOOLS_CONTINUE               32785
#define ID_TOOLS_SHOWVARIABLE           32786
#define ID_EDIT_SELECTALL               32787
#define ID_TOOLS_STATS                  32788
#define ID_FILE_SAVE_ENCRYPTED          32789
#define ID_TOOLS_TRACE                  32793
#define ID_TOOLS_STEP                   32794
#define ID_TOOLS_DESIGNER               32795
#define ID_PROGRAM                      32796
#define IDS_CAP_PROGRAM                 32798
#define ID_PROGRAM_MENU                 32800
#define IDS_CAP_ESR                     32803
#define IDS_CAP_ASDF                    32807
#define ID_FILE                         32808
#define IDS_CAP_FILE                    32810
#define ID_EDIT                         32811
#define IDS_CAP_EDIT                    32813
#define ID_TOOLS                        32814
#define IDS_CAP_TOOLS                   32816
#define ID_MENUITEM32818                32818
#define ID_TOOLS_FONTSIZE_LARGER        32819
#define ID_TOOLS_FONTSIZE_SMALLER       32820
#define ID_BUTTON32821                  32821
#define IDS_EXCEPTION_INVALID_ARGUMENTS 61204
#define IDS_EXCEPTION_CANTLOAD          61205
#define IDS_EXCEPTION_NOMEMORY          61206
#define IDS_EXCEPTION_CONTROLERR        61207
#define IDS_EXCEPTION_READONLY          61208
#define IDS_EXCEPTION_NOTSUPPORTED      61209
#define IDS_EXCEPTION_OUTOFBOUNDS       61210
#define IDS_EXCEPTION_FILENOTFOUND      61211

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        176
#define _APS_NEXT_COMMAND_VALUE         32822
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
