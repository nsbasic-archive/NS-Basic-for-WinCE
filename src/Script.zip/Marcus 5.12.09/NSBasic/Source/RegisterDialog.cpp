// RegisterDialog.cpp : implementation file
//

#include "stdafx.h"
#include "script.h"
#include "RegisterDialog.h"

#undef _DEBUG // EMP DIKEO

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRegisterDialog dialog


CRegisterDialog::CRegisterDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CRegisterDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRegisterDialog)
	m_serialNumber = _T("");
	//}}AFX_DATA_INIT
}


void CRegisterDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRegisterDialog)
	DDX_Text(pDX, IDC_EDIT1, m_serialNumber);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRegisterDialog, CDialog)
	//{{AFX_MSG_MAP(CRegisterDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRegisterDialog message handlers
