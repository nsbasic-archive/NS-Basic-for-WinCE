#include <stdarg.h>
#include <tchar.h>
#include <unknwn.h>

#undef _DEBUG // EMP DIKEO

#ifdef _DEBUG
	void  DebugStr(const TCHAR *fmt, ...);
	void DebugRefCount(IUnknown *pUnk,const TCHAR *szName);
#else
	#define DebugStr
	#define DebugRefCount
#endif
