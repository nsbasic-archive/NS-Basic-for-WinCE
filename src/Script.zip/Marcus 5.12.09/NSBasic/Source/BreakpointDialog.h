#if !defined(AFX_BREAKPOINTDIALOG_H__15754321_8165_11D2_8990_0000E73336C3__INCLUDED_)
#define AFX_BREAKPOINTDIALOG_H__15754321_8165_11D2_8990_0000E73336C3__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000-
// BreakpointDialog.h : header file
//
#include "tabedit.h"
#include "ScriptEngine.h"

/////////////////////////////////////////////////////////////////////////////
// BreakpointDialog dialog

class CBreakpointDialog : public CDialog
{
// Construction
public:
	CBreakpointDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBreakpointDialog)
	//enum { IDD = IDD_BREAKPOINTDIALOG };
	int IDD;
	CTabEdit	m_EditBox;
	CString	m_Caption;
	CString	m_ExecuteString;
	CScriptEngine *m_pEngine;
	VARIANT *m_pvarResult;
	CWnd  *m_pOwner;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBreakpointDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CBreakpointDialog)
	afx_msg void OnExecute();
	afx_msg void OnEvaluate();
	virtual BOOL OnInitDialog();
	afx_msg void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BREAKPOINTDIALOG_H__15754321_8165_11D2_8990_0000E73336C3__INCLUDED_)
