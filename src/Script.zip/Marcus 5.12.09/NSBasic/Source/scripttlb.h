/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.02.88 */
/* at Sun Jul 17 11:37:10 2005
 */
/* Compiler settings for C:\E\NSBasic CE 5.2.1 evc3\script.odl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"

#ifndef __scripttlb_h__
#define __scripttlb_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IScript_FWD_DEFINED__
#define __IScript_FWD_DEFINED__
typedef interface IScript IScript;
#endif 	/* __IScript_FWD_DEFINED__ */


#ifndef __Document_FWD_DEFINED__
#define __Document_FWD_DEFINED__

#ifdef __cplusplus
typedef class Document Document;
#else
typedef struct Document Document;
#endif /* __cplusplus */

#endif 	/* __Document_FWD_DEFINED__ */


#ifndef __IScriptEngine_FWD_DEFINED__
#define __IScriptEngine_FWD_DEFINED__
typedef interface IScriptEngine IScriptEngine;
#endif 	/* __IScriptEngine_FWD_DEFINED__ */


#ifndef __ScriptEngine_FWD_DEFINED__
#define __ScriptEngine_FWD_DEFINED__

#ifdef __cplusplus
typedef class ScriptEngine ScriptEngine;
#else
typedef struct ScriptEngine ScriptEngine;
#endif /* __cplusplus */

#endif 	/* __ScriptEngine_FWD_DEFINED__ */


#ifndef __IGlobalObjects_FWD_DEFINED__
#define __IGlobalObjects_FWD_DEFINED__
typedef interface IGlobalObjects IGlobalObjects;
#endif 	/* __IGlobalObjects_FWD_DEFINED__ */


#ifndef __GlobalObjects_FWD_DEFINED__
#define __GlobalObjects_FWD_DEFINED__

#ifdef __cplusplus
typedef class GlobalObjects GlobalObjects;
#else
typedef struct GlobalObjects GlobalObjects;
#endif /* __cplusplus */

#endif 	/* __GlobalObjects_FWD_DEFINED__ */


#ifndef __IOutputWindow_FWD_DEFINED__
#define __IOutputWindow_FWD_DEFINED__
typedef interface IOutputWindow IOutputWindow;
#endif 	/* __IOutputWindow_FWD_DEFINED__ */


#ifndef __OutputWindow_FWD_DEFINED__
#define __OutputWindow_FWD_DEFINED__

#ifdef __cplusplus
typedef class OutputWindow OutputWindow;
#else
typedef struct OutputWindow OutputWindow;
#endif /* __cplusplus */

#endif 	/* __OutputWindow_FWD_DEFINED__ */


#ifndef __IIntrinsicControl_FWD_DEFINED__
#define __IIntrinsicControl_FWD_DEFINED__
typedef interface IIntrinsicControl IIntrinsicControl;
#endif 	/* __IIntrinsicControl_FWD_DEFINED__ */


#ifndef __DIntrinsicEvents_FWD_DEFINED__
#define __DIntrinsicEvents_FWD_DEFINED__
typedef interface DIntrinsicEvents DIntrinsicEvents;
#endif 	/* __DIntrinsicEvents_FWD_DEFINED__ */


#ifndef __IntrinsicControl_FWD_DEFINED__
#define __IntrinsicControl_FWD_DEFINED__

#ifdef __cplusplus
typedef class IntrinsicControl IntrinsicControl;
#else
typedef struct IntrinsicControl IntrinsicControl;
#endif /* __cplusplus */

#endif 	/* __IntrinsicControl_FWD_DEFINED__ */


#ifndef __IMyFontWrapper_FWD_DEFINED__
#define __IMyFontWrapper_FWD_DEFINED__
typedef interface IMyFontWrapper IMyFontWrapper;
#endif 	/* __IMyFontWrapper_FWD_DEFINED__ */


#ifndef __MyFontWrapper_FWD_DEFINED__
#define __MyFontWrapper_FWD_DEFINED__

#ifdef __cplusplus
typedef class MyFontWrapper MyFontWrapper;
#else
typedef struct MyFontWrapper MyFontWrapper;
#endif /* __cplusplus */

#endif 	/* __MyFontWrapper_FWD_DEFINED__ */


#ifndef __INewOutputDialog_FWD_DEFINED__
#define __INewOutputDialog_FWD_DEFINED__
typedef interface INewOutputDialog INewOutputDialog;
#endif 	/* __INewOutputDialog_FWD_DEFINED__ */


#ifndef __NewOutputDialog_FWD_DEFINED__
#define __NewOutputDialog_FWD_DEFINED__

#ifdef __cplusplus
typedef class NewOutputDialog NewOutputDialog;
#else
typedef struct NewOutputDialog NewOutputDialog;
#endif /* __cplusplus */

#endif 	/* __NewOutputDialog_FWD_DEFINED__ */


#ifndef __ISimpleDialog_FWD_DEFINED__
#define __ISimpleDialog_FWD_DEFINED__
typedef interface ISimpleDialog ISimpleDialog;
#endif 	/* __ISimpleDialog_FWD_DEFINED__ */


#ifndef __SimpleDialog_FWD_DEFINED__
#define __SimpleDialog_FWD_DEFINED__

#ifdef __cplusplus
typedef class SimpleDialog SimpleDialog;
#else
typedef struct SimpleDialog SimpleDialog;
#endif /* __cplusplus */

#endif 	/* __SimpleDialog_FWD_DEFINED__ */


void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __Script_LIBRARY_DEFINED__
#define __Script_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: Script
 * at Sun Jul 17 11:37:10 2005
 * using MIDL 3.02.88
 ****************************************/
/* [version][uuid] */ 



DEFINE_GUID(LIBID_Script,0xB036D113,0x15EF,0x11D2,0x85,0x2D,0x2E,0x9E,0x34,0x00,0x00,0x00);

#ifndef __IScript_DISPINTERFACE_DEFINED__
#define __IScript_DISPINTERFACE_DEFINED__

/****************************************
 * Generated header for dispinterface: IScript
 * at Sun Jul 17 11:37:10 2005
 * using MIDL 3.02.88
 ****************************************/
/* [uuid] */ 



DEFINE_GUID(DIID_IScript,0xB036D114,0x15EF,0x11D2,0x85,0x2D,0x2E,0x9E,0x34,0x00,0x00,0x00);

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface DECLSPEC_UUID("B036D114-15EF-11D2-852D-2E9E34000000")
    IScript : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct IScriptVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IScript __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IScript __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IScript __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IScript __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IScript __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IScript __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IScript __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IScriptVtbl;

    interface IScript
    {
        CONST_VTBL struct IScriptVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IScript_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IScript_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IScript_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IScript_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IScript_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IScript_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IScript_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __IScript_DISPINTERFACE_DEFINED__ */


DEFINE_GUID(CLSID_Document,0xB036D112,0x15EF,0x11D2,0x85,0x2D,0x2E,0x9E,0x34,0x00,0x00,0x00);

#ifdef __cplusplus

class DECLSPEC_UUID("B036D112-15EF-11D2-852D-2E9E34000000")
Document;
#endif

#ifndef __IScriptEngine_DISPINTERFACE_DEFINED__
#define __IScriptEngine_DISPINTERFACE_DEFINED__

/****************************************
 * Generated header for dispinterface: IScriptEngine
 * at Sun Jul 17 11:37:10 2005
 * using MIDL 3.02.88
 ****************************************/
/* [uuid] */ 



DEFINE_GUID(DIID_IScriptEngine,0x6CA5B121,0x1609,0x11D2,0x85,0x2F,0xF2,0x6A,0x3B,0x00,0x00,0x00);

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface DECLSPEC_UUID("6CA5B121-1609-11D2-852F-F26A3B000000")
    IScriptEngine : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct IScriptEngineVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IScriptEngine __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IScriptEngine __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IScriptEngine __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IScriptEngine __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IScriptEngine __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IScriptEngine __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IScriptEngine __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IScriptEngineVtbl;

    interface IScriptEngine
    {
        CONST_VTBL struct IScriptEngineVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IScriptEngine_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IScriptEngine_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IScriptEngine_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IScriptEngine_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IScriptEngine_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IScriptEngine_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IScriptEngine_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __IScriptEngine_DISPINTERFACE_DEFINED__ */


DEFINE_GUID(CLSID_ScriptEngine,0x6CA5B123,0x1609,0x11D2,0x85,0x2F,0xF2,0x6A,0x3B,0x00,0x00,0x00);

#ifdef __cplusplus

class DECLSPEC_UUID("6CA5B123-1609-11D2-852F-F26A3B000000")
ScriptEngine;
#endif

#ifndef __IGlobalObjects_DISPINTERFACE_DEFINED__
#define __IGlobalObjects_DISPINTERFACE_DEFINED__

/****************************************
 * Generated header for dispinterface: IGlobalObjects
 * at Sun Jul 17 11:37:10 2005
 * using MIDL 3.02.88
 ****************************************/
/* [uuid] */ 



DEFINE_GUID(DIID_IGlobalObjects,0x723F20A2,0x2EEB,0x11D2,0x9D,0x8D,0x00,0x00,0xE7,0x33,0x36,0xC3);

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface DECLSPEC_UUID("723F20A2-2EEB-11D2-9D8D-0000E73336C3")
    IGlobalObjects : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct IGlobalObjectsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IGlobalObjects __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IGlobalObjects __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IGlobalObjects __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IGlobalObjects __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IGlobalObjects __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IGlobalObjects __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IGlobalObjects __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IGlobalObjectsVtbl;

    interface IGlobalObjects
    {
        CONST_VTBL struct IGlobalObjectsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IGlobalObjects_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IGlobalObjects_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IGlobalObjects_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IGlobalObjects_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IGlobalObjects_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IGlobalObjects_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IGlobalObjects_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __IGlobalObjects_DISPINTERFACE_DEFINED__ */


DEFINE_GUID(CLSID_GlobalObjects,0x723F20A4,0x2EEB,0x11D2,0x9D,0x8D,0x00,0x00,0xE7,0x33,0x36,0xC3);

#ifdef __cplusplus

class DECLSPEC_UUID("723F20A4-2EEB-11D2-9D8D-0000E73336C3")
GlobalObjects;
#endif

#ifndef __IOutputWindow_DISPINTERFACE_DEFINED__
#define __IOutputWindow_DISPINTERFACE_DEFINED__

/****************************************
 * Generated header for dispinterface: IOutputWindow
 * at Sun Jul 17 11:37:10 2005
 * using MIDL 3.02.88
 ****************************************/
/* [uuid] */ 



DEFINE_GUID(DIID_IOutputWindow,0xD4FE2D22,0x3DDF,0x11D2,0x89,0x0A,0x00,0x00,0xE7,0x33,0x36,0xC3);

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface DECLSPEC_UUID("D4FE2D22-3DDF-11D2-890A-0000E73336C3")
    IOutputWindow : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct IOutputWindowVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IOutputWindow __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IOutputWindow __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IOutputWindow __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IOutputWindow __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IOutputWindow __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IOutputWindow __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IOutputWindow __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IOutputWindowVtbl;

    interface IOutputWindow
    {
        CONST_VTBL struct IOutputWindowVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IOutputWindow_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IOutputWindow_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IOutputWindow_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IOutputWindow_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IOutputWindow_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IOutputWindow_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IOutputWindow_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __IOutputWindow_DISPINTERFACE_DEFINED__ */


DEFINE_GUID(CLSID_OutputWindow,0xD4FE2D24,0x3DDF,0x11D2,0x89,0x0A,0x00,0x00,0xE7,0x33,0x36,0xC3);

#ifdef __cplusplus

class DECLSPEC_UUID("D4FE2D24-3DDF-11D2-890A-0000E73336C3")
OutputWindow;
#endif

#ifndef __IIntrinsicControl_DISPINTERFACE_DEFINED__
#define __IIntrinsicControl_DISPINTERFACE_DEFINED__

/****************************************
 * Generated header for dispinterface: IIntrinsicControl
 * at Sun Jul 17 11:37:10 2005
 * using MIDL 3.02.88
 ****************************************/
/* [uuid] */ 



DEFINE_GUID(DIID_IIntrinsicControl,0xE13F3DD5,0x4CBD,0x11D2,0x89,0x2D,0x00,0x00,0xE7,0x33,0x36,0xC3);

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface DECLSPEC_UUID("E13F3DD5-4CBD-11D2-892D-0000E73336C3")
    IIntrinsicControl : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct IIntrinsicControlVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IIntrinsicControl __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IIntrinsicControl __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IIntrinsicControl __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IIntrinsicControl __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IIntrinsicControl __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IIntrinsicControl __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IIntrinsicControl __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IIntrinsicControlVtbl;

    interface IIntrinsicControl
    {
        CONST_VTBL struct IIntrinsicControlVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IIntrinsicControl_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IIntrinsicControl_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IIntrinsicControl_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IIntrinsicControl_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IIntrinsicControl_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IIntrinsicControl_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IIntrinsicControl_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __IIntrinsicControl_DISPINTERFACE_DEFINED__ */


#ifndef __DIntrinsicEvents_DISPINTERFACE_DEFINED__
#define __DIntrinsicEvents_DISPINTERFACE_DEFINED__

/****************************************
 * Generated header for dispinterface: DIntrinsicEvents
 * at Sun Jul 17 11:37:10 2005
 * using MIDL 3.02.88
 ****************************************/
/* [helpstring][uuid] */ 



DEFINE_GUID(DIID_DIntrinsicEvents,0xC7C22DD1,0x4CD3,0x11d2,0x89,0x2D,0x00,0x00,0xE7,0x33,0x36,0xC3);

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface DECLSPEC_UUID("C7C22DD1-4CD3-11d2-892D-0000E73336C3")
    DIntrinsicEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct DIntrinsicEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DIntrinsicEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DIntrinsicEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DIntrinsicEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DIntrinsicEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DIntrinsicEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DIntrinsicEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DIntrinsicEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } DIntrinsicEventsVtbl;

    interface DIntrinsicEvents
    {
        CONST_VTBL struct DIntrinsicEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DIntrinsicEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DIntrinsicEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DIntrinsicEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DIntrinsicEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DIntrinsicEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DIntrinsicEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DIntrinsicEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __DIntrinsicEvents_DISPINTERFACE_DEFINED__ */


DEFINE_GUID(CLSID_IntrinsicControl,0xE13F3DD7,0x4CBD,0x11D2,0x89,0x2D,0x00,0x00,0xE7,0x33,0x36,0xC3);

#ifdef __cplusplus

class DECLSPEC_UUID("E13F3DD7-4CBD-11D2-892D-0000E73336C3")
IntrinsicControl;
#endif

#ifndef __IMyFontWrapper_DISPINTERFACE_DEFINED__
#define __IMyFontWrapper_DISPINTERFACE_DEFINED__

/****************************************
 * Generated header for dispinterface: IMyFontWrapper
 * at Sun Jul 17 11:37:10 2005
 * using MIDL 3.02.88
 ****************************************/
/* [uuid] */ 



DEFINE_GUID(DIID_IMyFontWrapper,0x8CEC83F2,0x7FDF,0x11D2,0x89,0x8A,0x00,0x00,0xE7,0x33,0x36,0xC3);

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface DECLSPEC_UUID("8CEC83F2-7FDF-11D2-898A-0000E73336C3")
    IMyFontWrapper : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct IMyFontWrapperVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMyFontWrapper __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMyFontWrapper __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMyFontWrapper __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IMyFontWrapper __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IMyFontWrapper __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IMyFontWrapper __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IMyFontWrapper __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IMyFontWrapperVtbl;

    interface IMyFontWrapper
    {
        CONST_VTBL struct IMyFontWrapperVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMyFontWrapper_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMyFontWrapper_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMyFontWrapper_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMyFontWrapper_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMyFontWrapper_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMyFontWrapper_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMyFontWrapper_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __IMyFontWrapper_DISPINTERFACE_DEFINED__ */


DEFINE_GUID(CLSID_MyFontWrapper,0x8CEC83F4,0x7FDF,0x11D2,0x89,0x8A,0x00,0x00,0xE7,0x33,0x36,0xC3);

#ifdef __cplusplus

class DECLSPEC_UUID("8CEC83F4-7FDF-11D2-898A-0000E73336C3")
MyFontWrapper;
#endif

#ifndef __INewOutputDialog_DISPINTERFACE_DEFINED__
#define __INewOutputDialog_DISPINTERFACE_DEFINED__

/****************************************
 * Generated header for dispinterface: INewOutputDialog
 * at Sun Jul 17 11:37:10 2005
 * using MIDL 3.02.88
 ****************************************/
/* [uuid] */ 



DEFINE_GUID(DIID_INewOutputDialog,0xC3F29AF5,0x9854,0x11D2,0x89,0xB8,0x00,0x00,0xE7,0x33,0x36,0xC3);

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface DECLSPEC_UUID("C3F29AF5-9854-11D2-89B8-0000E73336C3")
    INewOutputDialog : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct INewOutputDialogVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            INewOutputDialog __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            INewOutputDialog __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            INewOutputDialog __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            INewOutputDialog __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            INewOutputDialog __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            INewOutputDialog __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            INewOutputDialog __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } INewOutputDialogVtbl;

    interface INewOutputDialog
    {
        CONST_VTBL struct INewOutputDialogVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define INewOutputDialog_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define INewOutputDialog_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define INewOutputDialog_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define INewOutputDialog_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define INewOutputDialog_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define INewOutputDialog_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define INewOutputDialog_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __INewOutputDialog_DISPINTERFACE_DEFINED__ */


DEFINE_GUID(CLSID_NewOutputDialog,0xC3F29AF7,0x9854,0x11D2,0x89,0xB8,0x00,0x00,0xE7,0x33,0x36,0xC3);

#ifdef __cplusplus

class DECLSPEC_UUID("C3F29AF7-9854-11D2-89B8-0000E73336C3")
NewOutputDialog;
#endif

#ifndef __ISimpleDialog_DISPINTERFACE_DEFINED__
#define __ISimpleDialog_DISPINTERFACE_DEFINED__

/****************************************
 * Generated header for dispinterface: ISimpleDialog
 * at Sun Jul 17 11:37:10 2005
 * using MIDL 3.02.88
 ****************************************/
/* [uuid] */ 



DEFINE_GUID(DIID_ISimpleDialog,0xC3F29B07,0x9854,0x11D2,0x89,0xB8,0x00,0x00,0xE7,0x33,0x36,0xC3);

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface DECLSPEC_UUID("C3F29B07-9854-11D2-89B8-0000E73336C3")
    ISimpleDialog : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct ISimpleDialogVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISimpleDialog __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISimpleDialog __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISimpleDialog __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISimpleDialog __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISimpleDialog __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISimpleDialog __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISimpleDialog __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } ISimpleDialogVtbl;

    interface ISimpleDialog
    {
        CONST_VTBL struct ISimpleDialogVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISimpleDialog_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISimpleDialog_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISimpleDialog_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISimpleDialog_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISimpleDialog_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISimpleDialog_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISimpleDialog_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __ISimpleDialog_DISPINTERFACE_DEFINED__ */


DEFINE_GUID(CLSID_SimpleDialog,0xC3F29B09,0x9854,0x11D2,0x89,0xB8,0x00,0x00,0xE7,0x33,0x36,0xC3);

#ifdef __cplusplus

class DECLSPEC_UUID("C3F29B09-9854-11D2-89B8-0000E73336C3")
SimpleDialog;
#endif
#endif /* __Script_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
