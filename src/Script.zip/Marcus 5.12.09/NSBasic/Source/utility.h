#ifndef __UTILITY_H__
#define __UTILITY_H__

#if _WIN32_WCE >= 300 && defined(_POCKET) && !defined(_WIN32_WCE_HPC)
#include <aygshell.h>
#endif

#include "script.h"

const TCHAR *findSubstringCaseInsensitive(const TCHAR *string, TCHAR *substring);

int doFillListBoxWithLinesContaining(CListBox *pListBox,CEditView *pEditView,CStringArray *pacstrMatches,BOOL bCaseSensitive=false, BOOL bLineBeginningOnly=false, int * iStartAt=0,int iMaxMatches=0);

int doExtractIntFromVariant(const VARIANT *vVariant, int iDefault);
CString doExtractCStringFromVariant(const VARIANT *vVariant, LPCTSTR szDefault);
LPUNKNOWN doExtractLPUNKNOWNFromVariant(const VARIANT *vVariant, LPUNKNOWN lpDefault);
HRESULT LookupCLSID(LPCOLESTR lpszProgID, LPCLSID pclsid);
void doGetAdjustedBounds(CWnd *pCWnd,RECT *pRect=0,int *pLeft=0, int *pTop=0, int *pWidth=0, int *pHeight=0);
TCHAR *doBuildSizeString(int iSize, TCHAR *szBuf);
void doDeleteMenuRecursively(CMenu *pMenu, void *pWnd);
bool isCodeValid(unsigned long lCode);

#ifdef _POCKET
void MenuStripString( LPTSTR lpsz, bool bStripTab = false );
#endif



bool mySHSipInfo(UINT uiAction, UINT uiParam, PVOID pvParam, UINT fWinIni);
bool SetSIPState(bool bState);
bool GetSIPState();
void ClipToVisibleScreenRect(RECT *pRect);
void SetWaitCursor(BOOL bWait);

#endif
