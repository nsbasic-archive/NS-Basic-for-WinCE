#if !defined(AFX_FUNCTIONLISTDIALOG_H__116A2662_3D18_11D2_8909_0000E73336C3__INCLUDED_)
#define AFX_FUNCTIONLISTDIALOG_H__116A2662_3D18_11D2_8909_0000E73336C3__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// FunctionListDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFunctionListDialog dialog

class CFunctionListDialog : public CDialog
{
// Construction
public:
	CFunctionListDialog(CWnd* pParent = NULL);   // standard constructor
	CString m_cstrCaption; //IN - caption for dialog
	CString m_cstrButton; //IN - name of action button (optional)
	CEditView *m_pEditView; //IN - pointer to the edit view we are searching (required)
	CStringArray m_acstrMatches; //IN - array of strings to match
	BOOL	m_bSorted; //IN - sort list box?
	BOOL	m_bCaseSensitive; //IN - case sensitive search?
	BOOL	m_bLineBeginningsOnly; //IN - only look at the beginning of lines?
	CListBox *m_pList;

	CString m_cstrSelection; //OUT - the actual text of the selection
	int m_iSelectionCharPos; //OUT - the character position in the edit view of the selected text
	int m_iSelectionLine;	 //OUT - the line number (in the edit view) on which the selected text occurred.

// Dialog Data
	//{{AFX_DATA(CFunctionListDialog)
	//enum { IDD = IDD_FUNCTIONDIALOG };
	int IDD;
	CListBox	m_ListSorted;
	CButton	m_ActionButton;
	CListBox	m_ListBox;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFunctionListDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFunctionListDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkList();
	virtual void OnOK();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FUNCTIONLISTDIALOG_H__116A2662_3D18_11D2_8909_0000E73336C3__INCLUDED_)
