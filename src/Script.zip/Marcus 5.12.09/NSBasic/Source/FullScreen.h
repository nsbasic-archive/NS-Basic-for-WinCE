#ifndef __FULLSCREEN_H__
#define __FULLSCREEN_H__

#include <windows.h>

int InitFullScreen	(void);
int DoFullScreen	(bool);

#endif