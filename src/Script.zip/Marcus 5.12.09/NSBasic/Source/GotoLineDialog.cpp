// GotoLineDialog.cpp : implementation file
//

#include "stdafx.h"
#include "script.h"
#include "GotoLineDialog.h"

#undef _DEBUG // EMP DIKEO

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGotoLineDialog dialog


CGotoLineDialog::CGotoLineDialog(CWnd* pParent /*=NULL*/)
#ifdef _WIN32_WCE_PSPC
	: CDialog(IDD_GOTOLINEDIALOG_PPC, pParent)
#else
	: CDialog(IDD_GOTOLINEDIALOG, pParent)
#endif
{
#ifdef _WIN32_WCE_PSPC
	IDD = IDD_GOTOLINEDIALOG_PPC;
#else
	IDD = IDD_GOTOLINEDIALOG;
#endif
	//{{AFX_DATA_INIT(CGotoLineDialog)
	m_LineNumber = 0;
	//}}AFX_DATA_INIT
}


void CGotoLineDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGotoLineDialog)
	DDX_Text(pDX, IDC_EDIT1, m_LineNumber);
	DDV_MinMaxUInt(pDX, m_LineNumber, 0, 99999);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGotoLineDialog, CDialog)
	//{{AFX_MSG_MAP(CGotoLineDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGotoLineDialog message handlers
