
#include "stdafx.h"

#ifndef __CSTRINGEX_H__
#define __CSTRINGEX_H__

class CStringEx : public CString
{
public:
	int Find(TCHAR ch, int nStart) const;
	int Find(LPCTSTR lpszSub, int nStart) const;
	int Replace(TCHAR chOld, TCHAR chNew);
	int Replace(LPCTSTR lpszOld, LPCTSTR lpszNew);
	int Delete(int nIndex, int nCount /* = 1 */);
	int Insert(int nIndex, TCHAR ch);
	int Insert(int nIndex, LPCTSTR pstr);

	const CStringEx& operator=(LPCTSTR lpsz);


};

#endif //__CSTRINGEX_H__
