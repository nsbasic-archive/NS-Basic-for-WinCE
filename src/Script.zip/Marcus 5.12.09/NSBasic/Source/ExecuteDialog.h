#if !defined(AFX_EXECUTEDIALOG_H__0A767192_40F1_11D2_8911_0000E73336C3__INCLUDED_)
#define AFX_EXECUTEDIALOG_H__0A767192_40F1_11D2_8911_0000E73336C3__INCLUDED_

#include "tabedit.h"

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ExecuteDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CExecuteDialog dialog

class CExecuteDialog : public CDialog
{
// Construction
public:
	CExecuteDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CExecuteDialog)
	//enum { IDD = IDD_EXECUTEDIALOG };
	int IDD;
	//CEdit	m_EditControl;
	CTabEdit	m_EditControl;
	CString	m_cstrText;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExecuteDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CExecuteDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXECUTEDIALOG_H__0A767192_40F1_11D2_8911_0000E73336C3__INCLUDED_)
