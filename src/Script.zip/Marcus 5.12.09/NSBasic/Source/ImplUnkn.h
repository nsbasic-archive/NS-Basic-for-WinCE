//
// Implementations of the IUnknown functions for a component 
//	defined with MFC INTERFACE_PART
//
#define IMPLEMENT_IUNKNOWN(theClass, localClass)			\
	STDMETHODIMP theClass::X##localClass::QueryInterface(	\
		REFIID iid, PVOID* ppvObj)							\
	{														\
		METHOD_PROLOGUE_EX_(theClass, localClass)			\
		return pThis->ExternalQueryInterface(&iid, ppvObj);	\
	}														\
	STDMETHODIMP_(ULONG) theClass::X##localClass::AddRef()	\
	{														\
		METHOD_PROLOGUE_EX_(theClass, localClass)			\
		return pThis->ExternalAddRef();						\
	}														\
															\
	STDMETHODIMP_(ULONG) theClass::X##localClass::Release()	\
	{														\
		METHOD_PROLOGUE_EX_(theClass, localClass)			\
		return pThis->ExternalRelease();					\
	}
