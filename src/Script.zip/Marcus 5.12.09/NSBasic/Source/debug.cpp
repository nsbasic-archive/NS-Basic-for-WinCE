#include "stdafx.h"
#include "script.h"
#include "debug.h"

#if 1
//#ifdef _WIN32_WCE
	#include <string.h>
	#include <stdarg.h>

#undef _DEBUG // EMP DIKEO

#ifdef _DEBUG

	void  DebugStr(const TCHAR *fmt, ...)
	{ va_list args;
	  TCHAR DebugTempBuf[1024];

		va_start (args,fmt);
		wvsprintf(DebugTempBuf,fmt,args);

		OutputDebugString(DebugTempBuf);
		//OutputDebugString(TEXT("\n\r"));

	} ;

#ifdef kDISPLAY_REFCOUNT_DEBUG_MESSAGES
	void DebugRefCount(IUnknown *pUnk, const TCHAR *szName)
	{ 
		if(!pUnk)
			DebugStr(TEXT("Pointer to (%s) is NULL\n"),szName);
		else
		{
			pUnk->AddRef();
			DebugStr(TEXT("RefCount for (%s) is %i\n"),szName, pUnk->Release());
		}

	}

#else
	void DebugRefCount(IUnknown *pUnk,const TCHAR *szName)
	{
	}
#endif //kDISPLAY_REFCOUNT_DEBUG_MESSAGES
#else

	//nothing.  These functions are #defined out in the header in non-debug builds
#endif
#else //not windows CE
	#include <stdio.h>
#endif
