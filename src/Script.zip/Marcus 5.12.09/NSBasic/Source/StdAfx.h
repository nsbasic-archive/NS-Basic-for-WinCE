// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//
 
#if !defined(AFX_STDAFX_H__B036D133_15EF_11D2_852D_2E9E34000000__INCLUDED_)
#define AFX_STDAFX_H__B036D133_15EF_11D2_852D_2E9E34000000__INCLUDED_

#if !defined (_WIN32_WCE_PSPC)
#define _NOTPALM
#else
#undef _NOTPALM
#endif

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

//VC6fix
#if(UNDER_CE==211)
#include <wce.h>
#endif
 
#ifndef MIDL_INTERFACE
#define MIDL_INTERFACE(x)   struct __declspec(uuid(x)) __declspec(novtable)		// missed definition from rpcndr.h
#endif

#define SWP_NOCOPYBITS      0x0100
//end vc6fix

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC OLE automation classes
//#include <afxole.h>         // MFC OLE classes
#include <afxpriv.h>        // For String conversions
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

//#include <afxsock.h>		// MFC socket extensions
#include "ACTIVSCP.H"		// Active Script definitions
#include <afxctl.h>         // MFC support for ActiveX Controls

//#include <wcedb.h>			// WCE MFC database classes

#include "scriptTLB.h"
#include "ImplUnkn.h"    //got this from the calc project

//**MARCH99 - apparently not defined for HPC
#ifndef SEE_MASK_NOCLOSEPROCESS
	#define SEE_MASK_NOCLOSEPROCESS 0x00000040
#endif
#ifndef SEE_MASK_FLAG_NO_UI
	#define SEE_MASK_FLAG_NO_UI     0x00000400
#endif

#ifndef RDW_INVALIDATE
#define RDW_INVALIDATE                 (0x0001)
#define RDW_INTERNALPAINT              (0x0002)
#define RDW_ERASE                      (0x0004)
#define RDW_VALIDATE                   (0x0008)
#define RDW_NOINTERNALPAINT            (0x0010)
#define RDW_NOERASE                    (0x0020)
#define RDW_NOCHILDREN                 (0x0040)
#define RDW_ALLCHILDREN                (0x0080)
#define RDW_UPDATENOW                  (0x0100)
#define RDW_ERASENOW                   (0x0200)
#define RDW_FRAME                      (0x0400)
#define RDW_NOFRAME                    (0x0800)
#endif

extern const GUID IID_IPictureBox;
extern const wchar_t * IID_IPictureBoxTxt;


//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__B036D133_15EF_11D2_852D_2E9E34000000__INCLUDED_)


