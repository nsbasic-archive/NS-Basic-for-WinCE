//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by MFCTEST.RC
//
#define IDR_MAINFRAME				128
#define IDD_ABOUTBOX				100
#define IDS_EDIT					102
#define IDS_TOOL					103
#define IDM_MENU					104
#define IDR_MAIN_EDIT				105
#define IDR_MAIN_TOOL				106
#define IDR_DOC_TOOL				107
#define IDM_DOCLIST					108

#define IDS_NEW						65000
#define IDS_FILE					65001
#define IDS_MHELP					65002
#define IDS_SAVE					65003
#define IDS_CUT						65004
#define IDS_COPY					65005
#define IDS_PASTE					65006
// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE	130
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		101
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
