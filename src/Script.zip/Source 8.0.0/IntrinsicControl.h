#if !defined(AFX_INTRINSICCONTROL_H__E13F3DD6_4CBD_11D2_892D_0000E73336C3__INCLUDED_)
#define AFX_INTRINSICCONTROL_H__E13F3DD6_4CBD_11D2_892D_0000E73336C3__INCLUDED_


#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// IntrinsicControl.h : header file
//
//	Added Event Stuff
#include "scriptengine.h"
#include "MyFontWrapper.h"

#define k_maxNControls	256		/* Max # controls, same as in VB */

class CIntrinsicEventStub : public CCmdTarget
{
public:
  	static const AFX_DATA AFX_EVENTMAP eventMap;
};

typedef enum
{
	kTabLeft,
	kTabRight,
	kTabUp,
	kTabDown,
} TabDirection;

/////////////////////////////////////////////////////////////////////////////
// CIntrinsicControl window

class CIntrinsicControl : public CWnd
{
friend class CScriptEngine;
// Construction
public:
	CIntrinsicControl();

// Attributes
public:
	IntrinsicObject			*m_pioThis;  //pointer to the IntrinsicObject structure which describes this control
	//CScriptObject			*m_pcsoThis; //pointer to the CScriptObject
	CString					m_cstrName;  //the name given to this control by the user
	CString					m_cstrParent;  //the parent of this control, from AddObject (optional)
	DWORD					m_dwExStyle;   //any extended style attributes
	COLORREF				m_BackColor;
	COLORREF				m_TabColor;
	COLORREF				m_PseudoSelectColor;
	COLORREF				m_ForeColor;
	HBRUSH					m_hbrushBackground;
	HBRUSH					m_hbrushTab;
	int						m_NewIndex;

	 
protected:
	CMyFontWrapper			m_Font;
	//long					m_lTag; //**JULY99 - for new tag property
	CString					m_cstrTag; //**JULY99 - chgd tag to string property
	unsigned char				m_bProcessingChange; //**MARCH99
	unsigned char				m_bProcessingSelChange; //**MARCH99
	unsigned char				m_bReopening; //**JUNE06

BEGIN_INTERFACE_PART(FontNotification, IPropertyNotifySink)
INIT_INTERFACE_PART(CIntrinsicControl, FontNotification)
	STDMETHOD(OnRequestEdit) (DISPID);
	STDMETHOD(OnChanged) (DISPID);
END_INTERFACE_PART(FontNotification)

	// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIntrinsicControl)
	public:
	virtual void OnFinalRelease();
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	UINT m_nTimerDuration;
	UINT m_nTimer;
	virtual ~CIntrinsicControl();
	HRESULT myGetTypeLib(int iLCID,ITypeLib **ppTypeLib);
	LPCTSTR BuildMessage(LPCTSTR szMessage,CString &str);
	// Generated message map functions
	//**EVENTS_BEGIN
	DECLARE_OLETYPELIB(CIntrinsicControl)
protected:

	//	Added Event Stuff
	void FireEventV(DISPID dispid, BYTE* pbParams,
		va_list argList);
	void AFX_CDECL FireEvent(DISPID dispid, BYTE* pbParams, ...);

	// Event maps
	//{{AFX_EVENT(CIntrinsicControl)
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()
	
	BEGIN_CONNECTION_PART(CIntrinsicControl, EventConnPt)
		CONNECTION_IID(DIID_DIntrinsicEvents)
	END_CONNECTION_PART(EventConnPt)

	DECLARE_CONNECTION_MAP()

	enum {
	//{{AFX_DISP_ID(CIntrinsicControl)
	dispidLeft = 1L,
	dispidRight = 2L,
	dispidTop = 3L,
	dispidBottom = 4L,
	dispidWidth = 5L,
	dispidHeight = 6L,
	dispidVisible = 7L,
	dispidTabStop = 8L,
	dispidValue = 9L,
	dispidMultiLine = 10L,
	dispidAlignment = 11L,
	dispidMaxLength = 12L,
	dispidFontName = 13L,
	dispidFontSize = 14L,
	dispidFontBold = 15L,
	dispidFontItalic = 16L,
	dispidFontUnderline = 17L,
	dispidFontStrikethru = 18L,
	dispidFontWeight = 19L,
	dispidNewIndex = 20L,
	dispidSorted = 21L,
	dispidScrollBars = 22L,
	dispidListIndex = 24L,
	dispidIntegralHeight = 25L,
	dispidStyle = 26L,
	dispidListCount = 27L,
	dispidLineCount = 28L,
	dispidModified = 29L,
	dispidSelStart = 30L,
	dispidSelLength = 31L,
	dispidSelText = 32L,
	dispidLongFormat = 33L,
	dispidMinDate = 34L,
	dispidMaxDate = 35L,
	dispidDate = 36L,
	dispidBorderStyle = 37L,
	dispidHwnd = 38L,
	dispidTag = 39L,
	dispidEnabled = 40L,
	dispidMin = 41L,
	dispidMax = 42L,
	dispidLargeChange = 43L,
	dispidSmallChange = 44L,
	dispidGroup = 45L,
	dispidParentHWnd = 46L,
	dispidTimer = 47L,
	dispidDefault = 48L,
	dispidNumbersOnly = 49L,
	dispidLowercaseOnly = 50L,
	dispidUppercaseOnly = 51L,
	dispidLocked = 52L,
	dispidMultiSelect = 53L,
	dispidPassword = 54L,
	dispidRedraw = 55L,
	dispidSelCount = 56L,
	dispidTopIndex = 57L,
	dispidUseMnemonic = 58L,
	dispidHideSelection = 59L,
	dispidTabOrder = 61L,
	dispidTabLeft = 62L,
	dispidMove = 63L,
	dispidHide = 64L,
	dispidShow = 65L,
	dispidSetFocus = 66L,
	dispidReopen = 67L,
	dispidAddItem = 68L,
	dispidClear = 69L,
	dispidRemoveitem = 70L,
	dispidList = 71L,
	dispidWindowLong = 72L,
	dispidItemData = 73L,
	dispidSelected = 74L,
	//}}AFX_DISP_ID
	};
	
	//{{AFX_MSG(CIntrinsicControl)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg HBRUSH CtlColor ( CDC* pDC, UINT nCtlColor );
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg BOOL OnWndMsg( UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pResult );


	//}}AFX_MSG
	afx_msg void OnDropDown();
	afx_msg void OnChange();
	afx_msg void OnSelChange();
	afx_msg void OnClick();

	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CIntrinsicControl)
	afx_msg short GetLeft();
	afx_msg void SetLeft(short nNewValue);
	afx_msg short GetRight();
	afx_msg void SetRight(short nNewValue);
	afx_msg short GetTop();
	afx_msg void SetTop(short nNewValue);
	afx_msg short GetBottom();
	afx_msg void SetBottom(short nNewValue);
	afx_msg short GetWidth();
	afx_msg void SetWidth(short nNewValue);
	afx_msg short GetHeight();
	afx_msg void SetHeight(short nNewValue);
	afx_msg BOOL GetVisible();
	afx_msg void SetVisible(BOOL bNewValue);
	afx_msg BOOL GetTabStop();
	afx_msg void SetTabStop(BOOL bNewValue);
	afx_msg short GetValue();
	afx_msg void SetValue(short nNewValue);
	afx_msg BOOL GetMultiLine();
	afx_msg void SetMultiLine(BOOL bNewValue);
	afx_msg short GetAlignment();
	afx_msg void SetAlignment(short nNewValue);
	afx_msg long GetMaxLength();
	afx_msg void SetMaxLength(long nNewValue);
	afx_msg BSTR GetFontName();
	afx_msg void SetFontName(LPCTSTR lpszNewValue);
	afx_msg long GetFontSize();
	afx_msg void SetFontSize(long nNewValue);
	afx_msg BOOL GetFontBold();
	afx_msg void SetFontBold(BOOL bNewValue);
	afx_msg BOOL GetFontItalic();
	afx_msg void SetFontItalic(BOOL bNewValue);
	afx_msg BOOL GetFontUnderline();
	afx_msg void SetFontUnderline(BOOL bNewValue);
	afx_msg BOOL GetFontStrikethru();
	afx_msg void SetFontStrikethru(BOOL bNewValue);
	afx_msg short GetFontWeight();
	afx_msg void SetFontWeight(short nNewValue);
	afx_msg short GetNewIndex();
	afx_msg void SetNewIndex(short nNewValue);
	afx_msg BOOL GetSorted();
	afx_msg void SetSorted(BOOL bNewValue);
	afx_msg short GetScrollBars();
	afx_msg void SetScrollBars(short nNewValue);
	afx_msg short GetColumns();
	afx_msg void SetColumns(short nNewValue);
	afx_msg long GetListIndex();
	afx_msg void SetListIndex(long nNewValue);
	afx_msg BOOL GetIntegralHeight();
	afx_msg void SetIntegralHeight(BOOL bNewValue);
	afx_msg short GetStyle();
	afx_msg void SetStyle(short nNewValue);
	afx_msg long GetListCount();
	afx_msg void SetListCount(long nNewValue);
	afx_msg short GetLineCount();
	afx_msg void SetLineCount(short nNewValue);
	afx_msg BOOL GetModified();
	afx_msg void SetModified(BOOL bNewValue);
	afx_msg long GetSelStart();
	afx_msg void SetSelStart(long nNewValue);
	afx_msg long GetSelLength();
	afx_msg void SetSelLength(long nNewValue);
	afx_msg BSTR GetSelText();
	afx_msg void SetSelText(LPCTSTR lpszNewValue);
	afx_msg BOOL GetLongFormat();
	afx_msg void SetLongFormat(BOOL bNewValue);
	afx_msg DATE GetMinDate();
	afx_msg void SetMinDate(DATE newValue);
	afx_msg DATE GetMaxDate();
	afx_msg void SetMaxDate(DATE newValue);
	afx_msg DATE GetDate();
	afx_msg void SetDate(DATE newValue);
	afx_msg short GetBorderStyle();
	afx_msg void SetBorderStyle(short nNewValue);
	afx_msg OLE_HANDLE GetHwnd();
	afx_msg void SetHwnd(OLE_HANDLE nNewValue);
	afx_msg BSTR GetTag();
	afx_msg void SetTag(LPCTSTR lpszNewValue);
	afx_msg BOOL GetEnabled();
	afx_msg void SetEnabled(BOOL bNewValue);
	afx_msg short GetMin();
	afx_msg void SetMin(short nNewValue);
	afx_msg short GetMax();
	afx_msg void SetMax(short nNewValue);
	afx_msg short GetLargeChange();
	afx_msg void SetLargeChange(short nNewValue);
	afx_msg short GetSmallChange();
	afx_msg void SetSmallChange(short nNewValue);
	afx_msg BOOL GetGroup();
	afx_msg void SetGroup(BOOL bNewValue);
	afx_msg OLE_HANDLE GetParentHWnd();
	afx_msg void SetParentHWnd(OLE_HANDLE nNewValue);
	afx_msg long doGetTimer();
	afx_msg void doSetTimer(long nNewValue);
	afx_msg BOOL GetDefault();
	afx_msg void SetDefault(BOOL bNewValue);
	afx_msg BOOL GetNumbersOnly();
	afx_msg void SetNumbersOnly(BOOL bNewValue);
	afx_msg BOOL GetLowercaseOnly();
	afx_msg void SetLowercaseOnly(BOOL bNewValue);
	afx_msg BOOL GetUppercaseOnly();
	afx_msg void SetUppercaseOnly(BOOL bNewValue);
	afx_msg BOOL GetLocked();
	afx_msg void SetLocked(BOOL bNewValue);
	afx_msg BOOL GetMultiSelect();
	afx_msg void SetMultiSelect(BOOL bNewValue);
	afx_msg BOOL GetPassword();
	afx_msg void SetPassword(BOOL bNewValue);
	afx_msg BOOL GetRedraw();
	afx_msg void SetRedraw(BOOL bNewValue);
	afx_msg long GetSelCount();
	afx_msg long GetTopIndex();
	afx_msg void SetTopIndex(long nNewValue);
	afx_msg BOOL GetUseMnemonic();
	afx_msg void SetUseMnemonic(BOOL bNewValue);
	afx_msg BOOL GetHideSelection();
	afx_msg void SetHideSelection(BOOL bNewValue);
	afx_msg void SetSpinBox(BOOL bNewValue);
	afx_msg long GetTabOrder();
	afx_msg void SetTabOrder(long nNewValue);
	afx_msg BSTR GetTabLeft();
	afx_msg void SetTabLeft(LPCTSTR lpszNewValue);
	afx_msg BSTR GetTabRight();
	afx_msg void SetTabRight(LPCTSTR lpszNewValue);
	afx_msg BSTR GetTabUp();
	afx_msg void SetTabUp(LPCTSTR lpszNewValue);
	afx_msg BSTR GetTabDown();
	afx_msg void SetTabDown(LPCTSTR lpszNewValue);
	afx_msg void move(const VARIANT FAR& left, const VARIANT FAR& top, const VARIANT FAR& width, const VARIANT FAR& height);
	afx_msg void Hide();
	afx_msg void Show();
	afx_msg void SetFocusProcedure();
	afx_msg void Reopen();
	afx_msg void AddItem(LPCTSTR item, const VARIANT FAR& index);
	afx_msg void Clear();
	afx_msg void Removeitem(long lIndex);
	afx_msg BSTR GetList(long iIndex);
	afx_msg void SetList(long iIndex, LPCTSTR lpszNewValue);
	afx_msg long doGetWindowLong(short nLong);
	afx_msg void doSetWindowLong(short nLong, long nNewValue);
	afx_msg long GetItemData(short nIndex);
	afx_msg void SetItemData(short nIndex, long nNewValue);
	afx_msg BOOL GetSelected(short nIndex);
	afx_msg void SetSelected(short nIndex, BOOL bNewValue);
	afx_msg BSTR GetText();
	afx_msg void SetText(LPCTSTR lpszNewValue);
	afx_msg OLE_COLOR GetBackColor();
	afx_msg void SetBackColor(OLE_COLOR nNewValue);
	afx_msg OLE_COLOR GetForeColor();
	afx_msg void SetForeColor(OLE_COLOR nNewValue);
	afx_msg LPDISPATCH GetFont();
	afx_msg void SetFont(LPDISPATCH newValue);
	afx_msg BSTR GetCaption();
	afx_msg void SetCaption(LPCTSTR lpszNewValue);
	//}}AFX_DISPATCH
	afx_msg void OnNotifyChange( NMHDR * pNotifyStruct, LRESULT * result );
	afx_msg void OnNotifyDropDown( NMHDR * pNotifyStruct, LRESULT * result );
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
private:
	int m_nSmallScroll;
	int m_nColumns;
	bool m_bClicking;
	CIntrinsicControl **m_tabControls;
	CIntrinsicControl *m_LastFocused;

	CString tabLeft, tabRight, tabUp, tabDown;

	/* Find the control adjacent to this one in TabDirection */
	CIntrinsicControl *AdjacentControl(TabDirection);

	bool m_marked;		/* Used for mark and sweep */
	bool m_tabStop;		/* Used for tab stop, since SmartPhone messes up the bit! */

public:

	static Reset(void);

	/* Refocus on the correct control */
	static void Refocus(void);

	// EMP tab is in OnSetFocus
	// virtual CWnd *SetFocus(void);

	/* Get the intrinsic controls for an object or global for none */
	static CIntrinsicControl **GetTabControls(CIntrinsicControl *root);

	/* Find an initial tab position for this control in the list of controls */
	void FindTabPosition(void);

	/* Find the position of this control in the static controls.  <0 for not found. */
	int TabPosition(void);

	/* Go to the next control in the tab order beyond the current, or the first if none is focused */
	static void NextTab(TabDirection, bool mandatory);

	/* Find the root of a control, or none. */
	CIntrinsicControl *CIntrinsicControl::GetRoot(void);

	/* Return true iff this is a root */
	bool IsRoot(void);

	CIntrinsicControl *m_focusChild, *m_focusParent;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTRINSICCONTROL_H__E13F3DD6_4CBD_11D2_892D_0000E73336C3__INCLUDED_)
