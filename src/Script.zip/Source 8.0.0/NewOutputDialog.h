//{{AFX_INCLUDES()
#include "picturebox1.h"
//}}AFX_INCLUDES
#if !defined(AFX_NEWOUTPUTDIALOG_H__C3F29AF6_9854_11D2_89B8_0000E73336C3__INCLUDED_)
#define AFX_NEWOUTPUTDIALOG_H__C3F29AF6_9854_11D2_89B8_0000E73336C3__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// NewOutputDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNewOutputDialog dialog

class CNewOutputDialog : public CDialog
{
// Construction
public:
	CNewOutputDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNewOutputDialog)
	enum { IDD = IDD_OUTPUTDIALOG };
	CPictureBox1	m_PictureBox2;
	CEdit	m_EditControl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewOutputDialog)
	public:
	protected:
	virtual void OnFinalRelease();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
		void myMoveWindow(RECT *pRect);
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewOutputDialog)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnDestroy();
	afx_msg void OnSetFocus( CWnd* pOldWnd );
	afx_msg void OnKeyPressPicturebox(long KeyASCII);
	afx_msg void OnKeyUpPicturebox(long KeyCode, long Shift);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyDownPicturebox(long KeyCode, long Shift);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CNewOutputDialog)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	long OnCtlColorBtn(DWORD wParam, DWORD lParam);
	long OnCtlColorListBox(DWORD wParam, DWORD lParam);
	long OnCtlColorEdit(DWORD wParam, DWORD lParam);
	long OnCtlColorStatic(DWORD wParam, DWORD lParam);
	long OnCtlColorScrollBar(DWORD wParam, DWORD lParam);
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWOUTPUTDIALOG_H__C3F29AF6_9854_11D2_89B8_0000E73336C3__INCLUDED_)
