Installation
------------
You can find an installation instructions in the HTML help - Grid.chm.

System requirements
-------------------
- eMbedded Visual Basic or eMbedded Visual C++
- Emulation environmen
- Pocket PC
- Handheld PC 2000

Supported platforms
-------------------
- Pocket PC 2002
- Pocket PC
- Handheld PC 2000

NOTE: used directory convention
Pc - Desktop PC
PPC - Pocket PC
PPC2002 - Pocket PC 2002
HPC - Handheld PC 2000
