Before you run the demo, copy "buy.bmp" image to 
the root of your target device or emulator.
