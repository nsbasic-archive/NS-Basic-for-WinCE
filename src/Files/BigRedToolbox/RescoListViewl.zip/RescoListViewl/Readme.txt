Installation
------------
You can find an installation instructions in the HTML help - ListView.chm.

System requirements
-------------------
- eMbedded Visual Basic or eMbedded Visual C++
- Emulation environmen
- Pocket PC or Handhelp PC 2000 device

Supported platforms
-------------------
- Pocket PC 2002
- Pocket PC
- HPC 2000

NOTE: used directory convention
HPC - Handheld PC 2000
Pc - Desktop PC
PPC - Pocket PC
PPC2002 - Pocket PC 2002
