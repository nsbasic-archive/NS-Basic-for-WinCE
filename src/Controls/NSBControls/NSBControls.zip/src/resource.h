//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ComCtl.rc
//
#define IDS_PROJNAME                    100
#define IDB_NSLISTVIEW                  101
#define IDR_NSLISTVIEW                  102
#define IDR_NSBIMAGELIST                103
#define IDR_NSBLISTIMAGE                104
#define IDR_NSCOLUMNHEADERS             105
#define IDR_NSCOLUMNHEADER              106
#define IDR_NSLISTITEMS                 107
#define IDR_NSLISTITEM                  108
#define IDR_NSLISTSUBITEMS              109
#define IDR_NSLISTSUBITEM               110
#define IDR_NSLISTVIEWEVENT             111
#define IDR_NSFONT                      112
#define IDR_NSCOLUMNITEMS               113
#define IDR_NSCOMCTLCOLL                114
#define IDI_ICON1                       202

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           115
#endif
#endif
