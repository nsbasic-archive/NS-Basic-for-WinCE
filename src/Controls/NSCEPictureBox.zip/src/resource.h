//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by NSCEPictureBox.rc
//
#define IDS_NSCEPICTUREBOX              1
#define IDD_ABOUTBOX_NSCEPICTUREBOX     1
#define IDB_NSCEPICTUREBOX              1
#define IDI_ABOUTDLL                    1
#define IDS_NSCEPICTUREBOX_PPG          2
#define IDB_WILD0                       100
#define IDB_WILD1                       101
#define IDB_WILD2                       102
#define IDB_JOKER                       153
#define IDB_BLANK                       154
#define IDB_BLANKFACE                   155
#define IDB_SUIT1                       156
#define IDB_SUIT2                       157
#define IDB_SUIT3                       158
#define IDB_SUIT4                       159
#define IDB_ROCKET                      161
#define IDS_NSCEPICTUREBOX_PPG_CAPTION  200
#define IDD_PROPPAGE_NSCEPICTUREBOX     200
#define IDS_STRINGVALUEOUTOFRANGE       201
#define IDS_STRINGSETNOTVALID           202

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
