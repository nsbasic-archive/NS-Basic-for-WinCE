#if !defined(AFX_STDAFX_H__D4D7C4BC_2CC5_11D3_AE29_00608CC1DD62__INCLUDED_)
#define AFX_STDAFX_H__D4D7C4BC_2CC5_11D3_AE29_00608CC1DD62__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// stdafx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxctl.h>         // MFC support for ActiveX Controls

#include <Afxtempl.h>
#include <afxmt.h>

#define _S309_CONTROL_BASE_ TEXT("S309.PictureBox")
#define _S309_CONTROL_VERSION_ TEXT("S309.PictureBox.2.8")
#define _S309_CONTROL_DESCRIPTION_ TEXT("Software 309 PictureBox")

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__D4D7C4BC_2CC5_11D3_AE29_00608CC1DD62__INCLUDED_)
