
Welcome to MGCEListView setup! MGCEListView provides a listview object to Windows CE applications which use objects, such as NS Basic.


When installation is complete, refer to MGCEListView.txt for documentation and sample code written in NS Basic.

Control documentation and NS Basic example source code are located in the "\My Documents" folder in text format.

NS Basic is (c) NS Basic Corporation
Windows CE is (c) Microsoft Corporation.
MGCEListView is by Mark Gamber, September 1999
