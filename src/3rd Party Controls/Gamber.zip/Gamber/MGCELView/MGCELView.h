/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sat Nov 06 01:39:48 1999
 */
/* Compiler settings for MGCELView.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __MGCELView_h__
#define __MGCELView_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IListView_FWD_DEFINED__
#define __IListView_FWD_DEFINED__
typedef interface IListView IListView;
#endif 	/* __IListView_FWD_DEFINED__ */


#ifndef ___IListViewEvents_FWD_DEFINED__
#define ___IListViewEvents_FWD_DEFINED__
typedef interface _IListViewEvents _IListViewEvents;
#endif 	/* ___IListViewEvents_FWD_DEFINED__ */


#ifndef __ListView_FWD_DEFINED__
#define __ListView_FWD_DEFINED__

#ifdef __cplusplus
typedef class ListView ListView;
#else
typedef struct ListView ListView;
#endif /* __cplusplus */

#endif 	/* __ListView_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IListView_INTERFACE_DEFINED__
#define __IListView_INTERFACE_DEFINED__

/* interface IListView */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IListView;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("88D0CA77-64DC-11D3-99AC-0040055A16DF")
    IListView : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddSmImage( 
            BSTR bFilename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddLgImage( 
            BSTR bFilename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RemoveSmImage( 
            long lIndex) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RemoveLgImage( 
            long lIndex) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SmImageCount( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_LgImageCount( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Border( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Border( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_View( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_View( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE InsertColumn( 
            /* [optional][in] */ long lCol,
            BSTR bName,
            /* [optional][in] */ long lWidth,
            /* [optional][in] */ long lImg) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetItem( 
            /* [optional][in] */ long lItem,
            /* [optional][in] */ long lSubItem,
            BSTR bText,
            /* [optional][in] */ long lImg,
            /* [optional][in] */ long lValue) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE InsertItem( 
            /* [optional][in] */ long lItem,
            BSTR bText,
            /* [optional][in] */ long lImg,
            /* [optional][in] */ long lValue,
            /* [retval][out] */ long __RPC_FAR *plItem) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ImageLists( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ImageLists( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Clear( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteItem( 
            /* [optional][in] */ long lItem) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteColumn( 
            /* [optional][in] */ long lColumn) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Selection( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Selection( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectionDisplay( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectionDisplay( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Sort( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Sort( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Checkboxes( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Checkboxes( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FullRowSelect( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FullRowSelect( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_GridLines( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_GridLines( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SubItemImages( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SubItemImages( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Count( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Select( 
            long lSelect,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Select( 
            long lSelect,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectedCount( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_BackColor( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_BackColor( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TextColor( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_TextColor( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ColumnWidth( 
            long lColumn,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ColumnWidth( 
            long lColumn,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Checked( 
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetColumn( 
            /* [optional][in] */ long lCol,
            BSTR bText,
            /* [optional][in] */ long lWidth,
            /* [optional][in] */ long lImg) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ColumnOrder( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ColumnOrder( 
            /* [in] */ VARIANT __RPC_FAR *newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_EditItems( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_EditItems( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FindText( 
            /* [optional][in] */ long lStart,
            /* [in] */ BSTR bFind,
            /* [retval][out] */ long __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Arrange( 
            long lType) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ColumnText( 
            long lIndex,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ColumnText( 
            long lIndex,
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ColumnImage( 
            long lIndex,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ColumnImage( 
            long lIndex,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ItemText( 
            long lItem,
            long lSubItem,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ItemText( 
            long lItem,
            long lSubItem,
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ItemImage( 
            long lItem,
            long lSubItem,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ItemImage( 
            long lItem,
            long lSubItem,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ItemValue( 
            long lItem,
            long lSubItem,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ItemValue( 
            long lItem,
            long lSubItem,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetFocus( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Tabstop( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Tabstop( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontName( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontSize( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontSize( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontBold( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontBold( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Style( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Style( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_AllowEventAsDefault( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_AllowEventAsDefault( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_AllowEvent( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddContextItem( 
            BSTR bText) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RemoveContextItem( 
            long lIndex) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ClearContext( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Version( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE EnsureVisible( 
            long lItem) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Show( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Hide( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ColumnCount( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_RowsPerPage( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TopIndex( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_hWnd( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IListViewVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IListView __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IListView __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IListView __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IListView __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IListView __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IListView __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IListView __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddSmImage )( 
            IListView __RPC_FAR * This,
            BSTR bFilename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddLgImage )( 
            IListView __RPC_FAR * This,
            BSTR bFilename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RemoveSmImage )( 
            IListView __RPC_FAR * This,
            long lIndex);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RemoveLgImage )( 
            IListView __RPC_FAR * This,
            long lIndex);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SmImageCount )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LgImageCount )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Border )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Border )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_View )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_View )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *InsertColumn )( 
            IListView __RPC_FAR * This,
            /* [optional][in] */ long lCol,
            BSTR bName,
            /* [optional][in] */ long lWidth,
            /* [optional][in] */ long lImg);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetItem )( 
            IListView __RPC_FAR * This,
            /* [optional][in] */ long lItem,
            /* [optional][in] */ long lSubItem,
            BSTR bText,
            /* [optional][in] */ long lImg,
            /* [optional][in] */ long lValue);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *InsertItem )( 
            IListView __RPC_FAR * This,
            /* [optional][in] */ long lItem,
            BSTR bText,
            /* [optional][in] */ long lImg,
            /* [optional][in] */ long lValue,
            /* [retval][out] */ long __RPC_FAR *plItem);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ImageLists )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ImageLists )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clear )( 
            IListView __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteItem )( 
            IListView __RPC_FAR * This,
            /* [optional][in] */ long lItem);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteColumn )( 
            IListView __RPC_FAR * This,
            /* [optional][in] */ long lColumn);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Selection )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Selection )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectionDisplay )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelectionDisplay )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Sort )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Sort )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Checkboxes )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Checkboxes )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FullRowSelect )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FullRowSelect )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_GridLines )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_GridLines )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SubItemImages )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SubItemImages )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Count )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Count )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Select )( 
            IListView __RPC_FAR * This,
            long lSelect,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Select )( 
            IListView __RPC_FAR * This,
            long lSelect,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectedCount )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BackColor )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_BackColor )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TextColor )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_TextColor )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ColumnWidth )( 
            IListView __RPC_FAR * This,
            long lColumn,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ColumnWidth )( 
            IListView __RPC_FAR * This,
            long lColumn,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Checked )( 
            IListView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetColumn )( 
            IListView __RPC_FAR * This,
            /* [optional][in] */ long lCol,
            BSTR bText,
            /* [optional][in] */ long lWidth,
            /* [optional][in] */ long lImg);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ColumnOrder )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ColumnOrder )( 
            IListView __RPC_FAR * This,
            /* [in] */ VARIANT __RPC_FAR *newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_EditItems )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_EditItems )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindText )( 
            IListView __RPC_FAR * This,
            /* [optional][in] */ long lStart,
            /* [in] */ BSTR bFind,
            /* [retval][out] */ long __RPC_FAR *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Arrange )( 
            IListView __RPC_FAR * This,
            long lType);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ColumnText )( 
            IListView __RPC_FAR * This,
            long lIndex,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ColumnText )( 
            IListView __RPC_FAR * This,
            long lIndex,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ColumnImage )( 
            IListView __RPC_FAR * This,
            long lIndex,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ColumnImage )( 
            IListView __RPC_FAR * This,
            long lIndex,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ItemText )( 
            IListView __RPC_FAR * This,
            long lItem,
            long lSubItem,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ItemText )( 
            IListView __RPC_FAR * This,
            long lItem,
            long lSubItem,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ItemImage )( 
            IListView __RPC_FAR * This,
            long lItem,
            long lSubItem,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ItemImage )( 
            IListView __RPC_FAR * This,
            long lItem,
            long lSubItem,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ItemValue )( 
            IListView __RPC_FAR * This,
            long lItem,
            long lSubItem,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ItemValue )( 
            IListView __RPC_FAR * This,
            long lItem,
            long lSubItem,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFocus )( 
            IListView __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Tabstop )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Tabstop )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontName )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontName )( 
            IListView __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontSize )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontSize )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontBold )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontBold )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Style )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Style )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AllowEventAsDefault )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_AllowEventAsDefault )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_AllowEvent )( 
            IListView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddContextItem )( 
            IListView __RPC_FAR * This,
            BSTR bText);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RemoveContextItem )( 
            IListView __RPC_FAR * This,
            long lIndex);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ClearContext )( 
            IListView __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Version )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *EnsureVisible )( 
            IListView __RPC_FAR * This,
            long lItem);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Show )( 
            IListView __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Hide )( 
            IListView __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ColumnCount )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_RowsPerPage )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TopIndex )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_hWnd )( 
            IListView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        END_INTERFACE
    } IListViewVtbl;

    interface IListView
    {
        CONST_VTBL struct IListViewVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IListView_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IListView_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IListView_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IListView_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IListView_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IListView_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IListView_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IListView_AddSmImage(This,bFilename)	\
    (This)->lpVtbl -> AddSmImage(This,bFilename)

#define IListView_AddLgImage(This,bFilename)	\
    (This)->lpVtbl -> AddLgImage(This,bFilename)

#define IListView_RemoveSmImage(This,lIndex)	\
    (This)->lpVtbl -> RemoveSmImage(This,lIndex)

#define IListView_RemoveLgImage(This,lIndex)	\
    (This)->lpVtbl -> RemoveLgImage(This,lIndex)

#define IListView_get_SmImageCount(This,pVal)	\
    (This)->lpVtbl -> get_SmImageCount(This,pVal)

#define IListView_get_LgImageCount(This,pVal)	\
    (This)->lpVtbl -> get_LgImageCount(This,pVal)

#define IListView_get_Border(This,pVal)	\
    (This)->lpVtbl -> get_Border(This,pVal)

#define IListView_put_Border(This,newVal)	\
    (This)->lpVtbl -> put_Border(This,newVal)

#define IListView_get_View(This,pVal)	\
    (This)->lpVtbl -> get_View(This,pVal)

#define IListView_put_View(This,newVal)	\
    (This)->lpVtbl -> put_View(This,newVal)

#define IListView_InsertColumn(This,lCol,bName,lWidth,lImg)	\
    (This)->lpVtbl -> InsertColumn(This,lCol,bName,lWidth,lImg)

#define IListView_SetItem(This,lItem,lSubItem,bText,lImg,lValue)	\
    (This)->lpVtbl -> SetItem(This,lItem,lSubItem,bText,lImg,lValue)

#define IListView_InsertItem(This,lItem,bText,lImg,lValue,plItem)	\
    (This)->lpVtbl -> InsertItem(This,lItem,bText,lImg,lValue,plItem)

#define IListView_get_ImageLists(This,pVal)	\
    (This)->lpVtbl -> get_ImageLists(This,pVal)

#define IListView_put_ImageLists(This,newVal)	\
    (This)->lpVtbl -> put_ImageLists(This,newVal)

#define IListView_Clear(This)	\
    (This)->lpVtbl -> Clear(This)

#define IListView_DeleteItem(This,lItem)	\
    (This)->lpVtbl -> DeleteItem(This,lItem)

#define IListView_DeleteColumn(This,lColumn)	\
    (This)->lpVtbl -> DeleteColumn(This,lColumn)

#define IListView_get_Selection(This,pVal)	\
    (This)->lpVtbl -> get_Selection(This,pVal)

#define IListView_put_Selection(This,newVal)	\
    (This)->lpVtbl -> put_Selection(This,newVal)

#define IListView_get_SelectionDisplay(This,pVal)	\
    (This)->lpVtbl -> get_SelectionDisplay(This,pVal)

#define IListView_put_SelectionDisplay(This,newVal)	\
    (This)->lpVtbl -> put_SelectionDisplay(This,newVal)

#define IListView_get_Sort(This,pVal)	\
    (This)->lpVtbl -> get_Sort(This,pVal)

#define IListView_put_Sort(This,newVal)	\
    (This)->lpVtbl -> put_Sort(This,newVal)

#define IListView_get_Checkboxes(This,pVal)	\
    (This)->lpVtbl -> get_Checkboxes(This,pVal)

#define IListView_put_Checkboxes(This,newVal)	\
    (This)->lpVtbl -> put_Checkboxes(This,newVal)

#define IListView_get_FullRowSelect(This,pVal)	\
    (This)->lpVtbl -> get_FullRowSelect(This,pVal)

#define IListView_put_FullRowSelect(This,newVal)	\
    (This)->lpVtbl -> put_FullRowSelect(This,newVal)

#define IListView_get_GridLines(This,pVal)	\
    (This)->lpVtbl -> get_GridLines(This,pVal)

#define IListView_put_GridLines(This,newVal)	\
    (This)->lpVtbl -> put_GridLines(This,newVal)

#define IListView_get_SubItemImages(This,pVal)	\
    (This)->lpVtbl -> get_SubItemImages(This,pVal)

#define IListView_put_SubItemImages(This,newVal)	\
    (This)->lpVtbl -> put_SubItemImages(This,newVal)

#define IListView_get_Count(This,pVal)	\
    (This)->lpVtbl -> get_Count(This,pVal)

#define IListView_put_Count(This,newVal)	\
    (This)->lpVtbl -> put_Count(This,newVal)

#define IListView_get_Select(This,lSelect,pVal)	\
    (This)->lpVtbl -> get_Select(This,lSelect,pVal)

#define IListView_put_Select(This,lSelect,newVal)	\
    (This)->lpVtbl -> put_Select(This,lSelect,newVal)

#define IListView_get_SelectedCount(This,pVal)	\
    (This)->lpVtbl -> get_SelectedCount(This,pVal)

#define IListView_get_BackColor(This,pVal)	\
    (This)->lpVtbl -> get_BackColor(This,pVal)

#define IListView_put_BackColor(This,newVal)	\
    (This)->lpVtbl -> put_BackColor(This,newVal)

#define IListView_get_TextColor(This,pVal)	\
    (This)->lpVtbl -> get_TextColor(This,pVal)

#define IListView_put_TextColor(This,newVal)	\
    (This)->lpVtbl -> put_TextColor(This,newVal)

#define IListView_get_ColumnWidth(This,lColumn,pVal)	\
    (This)->lpVtbl -> get_ColumnWidth(This,lColumn,pVal)

#define IListView_put_ColumnWidth(This,lColumn,newVal)	\
    (This)->lpVtbl -> put_ColumnWidth(This,lColumn,newVal)

#define IListView_get_Checked(This,lItem,pVal)	\
    (This)->lpVtbl -> get_Checked(This,lItem,pVal)

#define IListView_SetColumn(This,lCol,bText,lWidth,lImg)	\
    (This)->lpVtbl -> SetColumn(This,lCol,bText,lWidth,lImg)

#define IListView_get_ColumnOrder(This,pVal)	\
    (This)->lpVtbl -> get_ColumnOrder(This,pVal)

#define IListView_put_ColumnOrder(This,newVal)	\
    (This)->lpVtbl -> put_ColumnOrder(This,newVal)

#define IListView_get_EditItems(This,pVal)	\
    (This)->lpVtbl -> get_EditItems(This,pVal)

#define IListView_put_EditItems(This,newVal)	\
    (This)->lpVtbl -> put_EditItems(This,newVal)

#define IListView_FindText(This,lStart,bFind,pRet)	\
    (This)->lpVtbl -> FindText(This,lStart,bFind,pRet)

#define IListView_Arrange(This,lType)	\
    (This)->lpVtbl -> Arrange(This,lType)

#define IListView_get_ColumnText(This,lIndex,pVal)	\
    (This)->lpVtbl -> get_ColumnText(This,lIndex,pVal)

#define IListView_put_ColumnText(This,lIndex,newVal)	\
    (This)->lpVtbl -> put_ColumnText(This,lIndex,newVal)

#define IListView_get_ColumnImage(This,lIndex,pVal)	\
    (This)->lpVtbl -> get_ColumnImage(This,lIndex,pVal)

#define IListView_put_ColumnImage(This,lIndex,newVal)	\
    (This)->lpVtbl -> put_ColumnImage(This,lIndex,newVal)

#define IListView_get_ItemText(This,lItem,lSubItem,pVal)	\
    (This)->lpVtbl -> get_ItemText(This,lItem,lSubItem,pVal)

#define IListView_put_ItemText(This,lItem,lSubItem,newVal)	\
    (This)->lpVtbl -> put_ItemText(This,lItem,lSubItem,newVal)

#define IListView_get_ItemImage(This,lItem,lSubItem,pVal)	\
    (This)->lpVtbl -> get_ItemImage(This,lItem,lSubItem,pVal)

#define IListView_put_ItemImage(This,lItem,lSubItem,newVal)	\
    (This)->lpVtbl -> put_ItemImage(This,lItem,lSubItem,newVal)

#define IListView_get_ItemValue(This,lItem,lSubItem,pVal)	\
    (This)->lpVtbl -> get_ItemValue(This,lItem,lSubItem,pVal)

#define IListView_put_ItemValue(This,lItem,lSubItem,newVal)	\
    (This)->lpVtbl -> put_ItemValue(This,lItem,lSubItem,newVal)

#define IListView_SetFocus(This)	\
    (This)->lpVtbl -> SetFocus(This)

#define IListView_get_Tabstop(This,pVal)	\
    (This)->lpVtbl -> get_Tabstop(This,pVal)

#define IListView_put_Tabstop(This,newVal)	\
    (This)->lpVtbl -> put_Tabstop(This,newVal)

#define IListView_get_FontName(This,pVal)	\
    (This)->lpVtbl -> get_FontName(This,pVal)

#define IListView_put_FontName(This,newVal)	\
    (This)->lpVtbl -> put_FontName(This,newVal)

#define IListView_get_FontSize(This,pVal)	\
    (This)->lpVtbl -> get_FontSize(This,pVal)

#define IListView_put_FontSize(This,newVal)	\
    (This)->lpVtbl -> put_FontSize(This,newVal)

#define IListView_get_FontBold(This,pVal)	\
    (This)->lpVtbl -> get_FontBold(This,pVal)

#define IListView_put_FontBold(This,newVal)	\
    (This)->lpVtbl -> put_FontBold(This,newVal)

#define IListView_get_Style(This,pVal)	\
    (This)->lpVtbl -> get_Style(This,pVal)

#define IListView_put_Style(This,newVal)	\
    (This)->lpVtbl -> put_Style(This,newVal)

#define IListView_get_AllowEventAsDefault(This,pVal)	\
    (This)->lpVtbl -> get_AllowEventAsDefault(This,pVal)

#define IListView_put_AllowEventAsDefault(This,newVal)	\
    (This)->lpVtbl -> put_AllowEventAsDefault(This,newVal)

#define IListView_put_AllowEvent(This,newVal)	\
    (This)->lpVtbl -> put_AllowEvent(This,newVal)

#define IListView_AddContextItem(This,bText)	\
    (This)->lpVtbl -> AddContextItem(This,bText)

#define IListView_RemoveContextItem(This,lIndex)	\
    (This)->lpVtbl -> RemoveContextItem(This,lIndex)

#define IListView_ClearContext(This)	\
    (This)->lpVtbl -> ClearContext(This)

#define IListView_get_Version(This,pVal)	\
    (This)->lpVtbl -> get_Version(This,pVal)

#define IListView_EnsureVisible(This,lItem)	\
    (This)->lpVtbl -> EnsureVisible(This,lItem)

#define IListView_Show(This)	\
    (This)->lpVtbl -> Show(This)

#define IListView_Hide(This)	\
    (This)->lpVtbl -> Hide(This)

#define IListView_get_ColumnCount(This,pVal)	\
    (This)->lpVtbl -> get_ColumnCount(This,pVal)

#define IListView_get_RowsPerPage(This,pVal)	\
    (This)->lpVtbl -> get_RowsPerPage(This,pVal)

#define IListView_get_TopIndex(This,pVal)	\
    (This)->lpVtbl -> get_TopIndex(This,pVal)

#define IListView_get_hWnd(This,pVal)	\
    (This)->lpVtbl -> get_hWnd(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_AddSmImage_Proxy( 
    IListView __RPC_FAR * This,
    BSTR bFilename);


void __RPC_STUB IListView_AddSmImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_AddLgImage_Proxy( 
    IListView __RPC_FAR * This,
    BSTR bFilename);


void __RPC_STUB IListView_AddLgImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_RemoveSmImage_Proxy( 
    IListView __RPC_FAR * This,
    long lIndex);


void __RPC_STUB IListView_RemoveSmImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_RemoveLgImage_Proxy( 
    IListView __RPC_FAR * This,
    long lIndex);


void __RPC_STUB IListView_RemoveLgImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_SmImageCount_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_SmImageCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_LgImageCount_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_LgImageCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_Border_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_Border_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_Border_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_Border_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_View_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_View_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_View_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_View_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_InsertColumn_Proxy( 
    IListView __RPC_FAR * This,
    /* [optional][in] */ long lCol,
    BSTR bName,
    /* [optional][in] */ long lWidth,
    /* [optional][in] */ long lImg);


void __RPC_STUB IListView_InsertColumn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_SetItem_Proxy( 
    IListView __RPC_FAR * This,
    /* [optional][in] */ long lItem,
    /* [optional][in] */ long lSubItem,
    BSTR bText,
    /* [optional][in] */ long lImg,
    /* [optional][in] */ long lValue);


void __RPC_STUB IListView_SetItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_InsertItem_Proxy( 
    IListView __RPC_FAR * This,
    /* [optional][in] */ long lItem,
    BSTR bText,
    /* [optional][in] */ long lImg,
    /* [optional][in] */ long lValue,
    /* [retval][out] */ long __RPC_FAR *plItem);


void __RPC_STUB IListView_InsertItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_ImageLists_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_ImageLists_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_ImageLists_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_ImageLists_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_Clear_Proxy( 
    IListView __RPC_FAR * This);


void __RPC_STUB IListView_Clear_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_DeleteItem_Proxy( 
    IListView __RPC_FAR * This,
    /* [optional][in] */ long lItem);


void __RPC_STUB IListView_DeleteItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_DeleteColumn_Proxy( 
    IListView __RPC_FAR * This,
    /* [optional][in] */ long lColumn);


void __RPC_STUB IListView_DeleteColumn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_Selection_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_Selection_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_Selection_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_Selection_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_SelectionDisplay_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_SelectionDisplay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_SelectionDisplay_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_SelectionDisplay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_Sort_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_Sort_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_Sort_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_Sort_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_Checkboxes_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_Checkboxes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_Checkboxes_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_Checkboxes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_FullRowSelect_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_FullRowSelect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_FullRowSelect_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_FullRowSelect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_GridLines_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_GridLines_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_GridLines_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_GridLines_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_SubItemImages_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_SubItemImages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_SubItemImages_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_SubItemImages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_Count_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_Count_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_Select_Proxy( 
    IListView __RPC_FAR * This,
    long lSelect,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_Select_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_Select_Proxy( 
    IListView __RPC_FAR * This,
    long lSelect,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_Select_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_SelectedCount_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_SelectedCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_BackColor_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_BackColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_BackColor_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_BackColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_TextColor_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_TextColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_TextColor_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_TextColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_ColumnWidth_Proxy( 
    IListView __RPC_FAR * This,
    long lColumn,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_ColumnWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_ColumnWidth_Proxy( 
    IListView __RPC_FAR * This,
    long lColumn,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_ColumnWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_Checked_Proxy( 
    IListView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_Checked_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_SetColumn_Proxy( 
    IListView __RPC_FAR * This,
    /* [optional][in] */ long lCol,
    BSTR bText,
    /* [optional][in] */ long lWidth,
    /* [optional][in] */ long lImg);


void __RPC_STUB IListView_SetColumn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_ColumnOrder_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IListView_get_ColumnOrder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_ColumnOrder_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ VARIANT __RPC_FAR *newVal);


void __RPC_STUB IListView_put_ColumnOrder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_EditItems_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_EditItems_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_EditItems_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_EditItems_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_FindText_Proxy( 
    IListView __RPC_FAR * This,
    /* [optional][in] */ long lStart,
    /* [in] */ BSTR bFind,
    /* [retval][out] */ long __RPC_FAR *pRet);


void __RPC_STUB IListView_FindText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_Arrange_Proxy( 
    IListView __RPC_FAR * This,
    long lType);


void __RPC_STUB IListView_Arrange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_ColumnText_Proxy( 
    IListView __RPC_FAR * This,
    long lIndex,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IListView_get_ColumnText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_ColumnText_Proxy( 
    IListView __RPC_FAR * This,
    long lIndex,
    /* [in] */ BSTR newVal);


void __RPC_STUB IListView_put_ColumnText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_ColumnImage_Proxy( 
    IListView __RPC_FAR * This,
    long lIndex,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_ColumnImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_ColumnImage_Proxy( 
    IListView __RPC_FAR * This,
    long lIndex,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_ColumnImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_ItemText_Proxy( 
    IListView __RPC_FAR * This,
    long lItem,
    long lSubItem,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IListView_get_ItemText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_ItemText_Proxy( 
    IListView __RPC_FAR * This,
    long lItem,
    long lSubItem,
    /* [in] */ BSTR newVal);


void __RPC_STUB IListView_put_ItemText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_ItemImage_Proxy( 
    IListView __RPC_FAR * This,
    long lItem,
    long lSubItem,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_ItemImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_ItemImage_Proxy( 
    IListView __RPC_FAR * This,
    long lItem,
    long lSubItem,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_ItemImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_ItemValue_Proxy( 
    IListView __RPC_FAR * This,
    long lItem,
    long lSubItem,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_ItemValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_ItemValue_Proxy( 
    IListView __RPC_FAR * This,
    long lItem,
    long lSubItem,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_ItemValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_SetFocus_Proxy( 
    IListView __RPC_FAR * This);


void __RPC_STUB IListView_SetFocus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_Tabstop_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_Tabstop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_Tabstop_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_Tabstop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_FontName_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IListView_get_FontName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_FontName_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IListView_put_FontName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_FontSize_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_FontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_FontSize_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_FontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_FontBold_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_FontBold_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_FontBold_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_FontBold_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_Style_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_Style_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_Style_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_Style_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_AllowEventAsDefault_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_AllowEventAsDefault_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_AllowEventAsDefault_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_AllowEventAsDefault_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IListView_put_AllowEvent_Proxy( 
    IListView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IListView_put_AllowEvent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_AddContextItem_Proxy( 
    IListView __RPC_FAR * This,
    BSTR bText);


void __RPC_STUB IListView_AddContextItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_RemoveContextItem_Proxy( 
    IListView __RPC_FAR * This,
    long lIndex);


void __RPC_STUB IListView_RemoveContextItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_ClearContext_Proxy( 
    IListView __RPC_FAR * This);


void __RPC_STUB IListView_ClearContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_Version_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_Version_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_EnsureVisible_Proxy( 
    IListView __RPC_FAR * This,
    long lItem);


void __RPC_STUB IListView_EnsureVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_Show_Proxy( 
    IListView __RPC_FAR * This);


void __RPC_STUB IListView_Show_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IListView_Hide_Proxy( 
    IListView __RPC_FAR * This);


void __RPC_STUB IListView_Hide_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_ColumnCount_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_ColumnCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_RowsPerPage_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_RowsPerPage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_TopIndex_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_TopIndex_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IListView_get_hWnd_Proxy( 
    IListView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IListView_get_hWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IListView_INTERFACE_DEFINED__ */



#ifndef __MGCELVIEWLib_LIBRARY_DEFINED__
#define __MGCELVIEWLib_LIBRARY_DEFINED__

/* library MGCELVIEWLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_MGCELVIEWLib;

#ifndef ___IListViewEvents_DISPINTERFACE_DEFINED__
#define ___IListViewEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IListViewEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IListViewEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("88D0CA79-64DC-11D3-99AC-0040055A16DF")
    _IListViewEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IListViewEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IListViewEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IListViewEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IListViewEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IListViewEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IListViewEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IListViewEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IListViewEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IListViewEventsVtbl;

    interface _IListViewEvents
    {
        CONST_VTBL struct _IListViewEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IListViewEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IListViewEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IListViewEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IListViewEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IListViewEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IListViewEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IListViewEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IListViewEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_ListView;

#ifdef __cplusplus

class DECLSPEC_UUID("88D0CA78-64DC-11D3-99AC-0040055A16DF")
ListView;
#endif
#endif /* __MGCELVIEWLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
