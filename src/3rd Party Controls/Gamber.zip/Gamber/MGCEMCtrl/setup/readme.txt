
Welcome to MGCEBarsNPops setup! MGCEBarsNPops provides several controls to applications capable of using objects such as NS Basic. Included with this package are:

Vertical and Horizontal Scrollbar controls
Vertical and Horizontal Trackbar controls
Vertical and Horizontal "VU Meter" controls
Progress Bar control
Popup Menu control
Statusbar control
Control documentation and NS Basic example source code

Control documentation and NS Basic example source code are located in the "\My Documents" folder in text format.

NS Basic is (c) NS Basic Corporation
Windows CE is (c) Microsoft Corporation.
MGCEBarsNPops is by Mark Gamber, September 1999
