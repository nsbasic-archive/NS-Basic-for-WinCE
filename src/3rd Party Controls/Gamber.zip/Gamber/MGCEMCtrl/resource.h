//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MGCEMCtrl.rc
//
#define IDS_PROJNAME                    100
#define IDB_SCROLLBAR                   101
#define IDR_SCROLLBAR                   102
#define IDB_TRACKBAR                    103
#define IDR_TRACKBAR                    104
#define IDB_PROGRESS                    105
#define IDR_PROGRESS                    106
#define IDB_VUMETER                     107
#define IDR_VUMETER                     108
#define IDB_POPUPMENU                   109
#define IDR_POPUPMENU                   110
#define IDB_HTML                        111
#define IDR_HTML                        112
#define IDB_STATUSBAR                   113
#define IDR_STATUSBAR                   114

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           115
#endif
#endif
