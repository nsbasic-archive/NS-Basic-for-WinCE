
Welcome to MGCERichInk setup! MGCERichInk provides a rich ink (scratchpad) control to applications capable of using objects such as NS Basic. Included with this package are:

Rich Ink control
Control documentation and NS Basic example source code

Control documentation and NS Basic example source code are located in the "\My Documents" folder in text format.

NS Basic is (c) NS Basic Corporation
Windows CE is (c) Microsoft Corporation.
MGCERichInk is by Mark Gamber, October 1999
