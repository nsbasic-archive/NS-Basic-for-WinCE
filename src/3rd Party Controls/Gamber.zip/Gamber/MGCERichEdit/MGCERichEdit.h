/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sat Nov 06 14:43:35 1999
 */
/* Compiler settings for MGCERichEdit.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __MGCERichEdit_h__
#define __MGCERichEdit_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IRichEdit_FWD_DEFINED__
#define __IRichEdit_FWD_DEFINED__
typedef interface IRichEdit IRichEdit;
#endif 	/* __IRichEdit_FWD_DEFINED__ */


#ifndef ___IRichEditEvents_FWD_DEFINED__
#define ___IRichEditEvents_FWD_DEFINED__
typedef interface _IRichEditEvents _IRichEditEvents;
#endif 	/* ___IRichEditEvents_FWD_DEFINED__ */


#ifndef __RichEdit_FWD_DEFINED__
#define __RichEdit_FWD_DEFINED__

#ifdef __cplusplus
typedef class RichEdit RichEdit;
#else
typedef struct RichEdit RichEdit;
#endif /* __cplusplus */

#endif 	/* __RichEdit_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IRichEdit_INTERFACE_DEFINED__
#define __IRichEdit_INTERFACE_DEFINED__

/* interface IRichEdit */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IRichEdit;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8F9258F8-70CB-11D3-99BA-0040055A16DF")
    IRichEdit : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_BackColor( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_BackColor( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontName( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ForeColor( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ForeColor( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontSize( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontSize( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontBold( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontBold( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontItalic( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontItalic( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontUnderline( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontUnderline( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontStrikeout( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontStrikeout( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Multiline( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Multiline( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Scrollbars( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Scrollbars( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Border( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Border( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Caption( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Caption( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_RTFText( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_RTFText( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Style( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Style( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Show( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Hide( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetFocus( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_MaxLength( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_MaxLength( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectionFontName( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectionFontName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectionForeColor( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectionForeColor( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectionFontSize( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectionFontSize( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectionFontBold( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectionFontBold( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectionFontItalic( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectionFontItalic( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectionFontUnderline( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectionFontUnderline( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectionFontStrikeout( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectionFontStrikeout( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Undo( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Redo( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectionDisplay( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectionDisplay( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ReadOnly( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ReadOnly( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE EmptyUndo( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Cut( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Copy( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Paste( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReplaceSelection( 
            BSTR bText) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SetStart( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SetStart( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelLength( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelLength( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_LineCount( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Save( 
            BSTR bFilename,
            /* [optional][in] */ long lOverWrite,
            /* [retval][out] */ long __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Load( 
            BSTR bFilename,
            /* [retval][out] */ long __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Modify( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Modify( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontOffset( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontOffset( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectionFontOffset( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectionFontOffset( 
            /* [optional][in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FindText( 
            /* [optional][in] */ long lType,
            /* [optional][in] */ long lStart,
            /* [optional][in] */ long lLength,
            /* [in] */ BSTR bText,
            /* [retval][out] */ long __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetTextRange( 
            long lStart,
            long lLength,
            /* [retval][out] */ BSTR __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CharLine( 
            long lIndex,
            /* [retval][out] */ long __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE LineChar( 
            long lLine,
            /* [retval][out] */ long __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE LineScroll( 
            long lXScroll,
            long lYScroll) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_LeftMargin( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_LeftMargin( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_RightMargin( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_RightMargin( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetTabstops( 
            VARIANT __RPC_FAR *pVar) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Version( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Tabstop( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Tabstop( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectionFontFlags( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectionFontFlags( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_hWnd( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelStart( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelStart( 
            /* [in] */ long newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IRichEditVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IRichEdit __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IRichEdit __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IRichEdit __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BackColor )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_BackColor )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontName )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontName )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ForeColor )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ForeColor )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontSize )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontSize )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontBold )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontBold )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontItalic )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontItalic )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontUnderline )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontUnderline )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontStrikeout )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontStrikeout )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Multiline )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Multiline )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Scrollbars )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Scrollbars )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Border )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Border )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Caption )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Caption )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_RTFText )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_RTFText )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Style )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Style )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Show )( 
            IRichEdit __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Hide )( 
            IRichEdit __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFocus )( 
            IRichEdit __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_MaxLength )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_MaxLength )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectionFontName )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelectionFontName )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectionForeColor )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelectionForeColor )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectionFontSize )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelectionFontSize )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectionFontBold )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelectionFontBold )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectionFontItalic )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelectionFontItalic )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectionFontUnderline )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelectionFontUnderline )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectionFontStrikeout )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelectionFontStrikeout )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Undo )( 
            IRichEdit __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Redo )( 
            IRichEdit __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectionDisplay )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelectionDisplay )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ReadOnly )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ReadOnly )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *EmptyUndo )( 
            IRichEdit __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Cut )( 
            IRichEdit __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Copy )( 
            IRichEdit __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Paste )( 
            IRichEdit __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReplaceSelection )( 
            IRichEdit __RPC_FAR * This,
            BSTR bText);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SetStart )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SetStart )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelLength )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelLength )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LineCount )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Save )( 
            IRichEdit __RPC_FAR * This,
            BSTR bFilename,
            /* [optional][in] */ long lOverWrite,
            /* [retval][out] */ long __RPC_FAR *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Load )( 
            IRichEdit __RPC_FAR * This,
            BSTR bFilename,
            /* [retval][out] */ long __RPC_FAR *pRet);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Modify )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Modify )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontOffset )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontOffset )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectionFontOffset )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelectionFontOffset )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindText )( 
            IRichEdit __RPC_FAR * This,
            /* [optional][in] */ long lType,
            /* [optional][in] */ long lStart,
            /* [optional][in] */ long lLength,
            /* [in] */ BSTR bText,
            /* [retval][out] */ long __RPC_FAR *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTextRange )( 
            IRichEdit __RPC_FAR * This,
            long lStart,
            long lLength,
            /* [retval][out] */ BSTR __RPC_FAR *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CharLine )( 
            IRichEdit __RPC_FAR * This,
            long lIndex,
            /* [retval][out] */ long __RPC_FAR *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LineChar )( 
            IRichEdit __RPC_FAR * This,
            long lLine,
            /* [retval][out] */ long __RPC_FAR *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LineScroll )( 
            IRichEdit __RPC_FAR * This,
            long lXScroll,
            long lYScroll);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LeftMargin )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_LeftMargin )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_RightMargin )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_RightMargin )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetTabstops )( 
            IRichEdit __RPC_FAR * This,
            VARIANT __RPC_FAR *pVar);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Version )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Tabstop )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Tabstop )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectionFontFlags )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelectionFontFlags )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_hWnd )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelStart )( 
            IRichEdit __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelStart )( 
            IRichEdit __RPC_FAR * This,
            /* [in] */ long newVal);
        
        END_INTERFACE
    } IRichEditVtbl;

    interface IRichEdit
    {
        CONST_VTBL struct IRichEditVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IRichEdit_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IRichEdit_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IRichEdit_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IRichEdit_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IRichEdit_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IRichEdit_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IRichEdit_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IRichEdit_get_BackColor(This,pVal)	\
    (This)->lpVtbl -> get_BackColor(This,pVal)

#define IRichEdit_put_BackColor(This,newVal)	\
    (This)->lpVtbl -> put_BackColor(This,newVal)

#define IRichEdit_get_FontName(This,pVal)	\
    (This)->lpVtbl -> get_FontName(This,pVal)

#define IRichEdit_put_FontName(This,newVal)	\
    (This)->lpVtbl -> put_FontName(This,newVal)

#define IRichEdit_get_ForeColor(This,pVal)	\
    (This)->lpVtbl -> get_ForeColor(This,pVal)

#define IRichEdit_put_ForeColor(This,newVal)	\
    (This)->lpVtbl -> put_ForeColor(This,newVal)

#define IRichEdit_get_FontSize(This,pVal)	\
    (This)->lpVtbl -> get_FontSize(This,pVal)

#define IRichEdit_put_FontSize(This,newVal)	\
    (This)->lpVtbl -> put_FontSize(This,newVal)

#define IRichEdit_get_FontBold(This,pVal)	\
    (This)->lpVtbl -> get_FontBold(This,pVal)

#define IRichEdit_put_FontBold(This,newVal)	\
    (This)->lpVtbl -> put_FontBold(This,newVal)

#define IRichEdit_get_FontItalic(This,pVal)	\
    (This)->lpVtbl -> get_FontItalic(This,pVal)

#define IRichEdit_put_FontItalic(This,newVal)	\
    (This)->lpVtbl -> put_FontItalic(This,newVal)

#define IRichEdit_get_FontUnderline(This,pVal)	\
    (This)->lpVtbl -> get_FontUnderline(This,pVal)

#define IRichEdit_put_FontUnderline(This,newVal)	\
    (This)->lpVtbl -> put_FontUnderline(This,newVal)

#define IRichEdit_get_FontStrikeout(This,pVal)	\
    (This)->lpVtbl -> get_FontStrikeout(This,pVal)

#define IRichEdit_put_FontStrikeout(This,newVal)	\
    (This)->lpVtbl -> put_FontStrikeout(This,newVal)

#define IRichEdit_get_Multiline(This,pVal)	\
    (This)->lpVtbl -> get_Multiline(This,pVal)

#define IRichEdit_put_Multiline(This,newVal)	\
    (This)->lpVtbl -> put_Multiline(This,newVal)

#define IRichEdit_get_Scrollbars(This,pVal)	\
    (This)->lpVtbl -> get_Scrollbars(This,pVal)

#define IRichEdit_put_Scrollbars(This,newVal)	\
    (This)->lpVtbl -> put_Scrollbars(This,newVal)

#define IRichEdit_get_Border(This,pVal)	\
    (This)->lpVtbl -> get_Border(This,pVal)

#define IRichEdit_put_Border(This,newVal)	\
    (This)->lpVtbl -> put_Border(This,newVal)

#define IRichEdit_get_Caption(This,pVal)	\
    (This)->lpVtbl -> get_Caption(This,pVal)

#define IRichEdit_put_Caption(This,newVal)	\
    (This)->lpVtbl -> put_Caption(This,newVal)

#define IRichEdit_get_RTFText(This,pVal)	\
    (This)->lpVtbl -> get_RTFText(This,pVal)

#define IRichEdit_put_RTFText(This,newVal)	\
    (This)->lpVtbl -> put_RTFText(This,newVal)

#define IRichEdit_get_Style(This,pVal)	\
    (This)->lpVtbl -> get_Style(This,pVal)

#define IRichEdit_put_Style(This,newVal)	\
    (This)->lpVtbl -> put_Style(This,newVal)

#define IRichEdit_Show(This)	\
    (This)->lpVtbl -> Show(This)

#define IRichEdit_Hide(This)	\
    (This)->lpVtbl -> Hide(This)

#define IRichEdit_SetFocus(This)	\
    (This)->lpVtbl -> SetFocus(This)

#define IRichEdit_get_MaxLength(This,pVal)	\
    (This)->lpVtbl -> get_MaxLength(This,pVal)

#define IRichEdit_put_MaxLength(This,newVal)	\
    (This)->lpVtbl -> put_MaxLength(This,newVal)

#define IRichEdit_get_SelectionFontName(This,pVal)	\
    (This)->lpVtbl -> get_SelectionFontName(This,pVal)

#define IRichEdit_put_SelectionFontName(This,newVal)	\
    (This)->lpVtbl -> put_SelectionFontName(This,newVal)

#define IRichEdit_get_SelectionForeColor(This,pVal)	\
    (This)->lpVtbl -> get_SelectionForeColor(This,pVal)

#define IRichEdit_put_SelectionForeColor(This,newVal)	\
    (This)->lpVtbl -> put_SelectionForeColor(This,newVal)

#define IRichEdit_get_SelectionFontSize(This,pVal)	\
    (This)->lpVtbl -> get_SelectionFontSize(This,pVal)

#define IRichEdit_put_SelectionFontSize(This,newVal)	\
    (This)->lpVtbl -> put_SelectionFontSize(This,newVal)

#define IRichEdit_get_SelectionFontBold(This,pVal)	\
    (This)->lpVtbl -> get_SelectionFontBold(This,pVal)

#define IRichEdit_put_SelectionFontBold(This,newVal)	\
    (This)->lpVtbl -> put_SelectionFontBold(This,newVal)

#define IRichEdit_get_SelectionFontItalic(This,pVal)	\
    (This)->lpVtbl -> get_SelectionFontItalic(This,pVal)

#define IRichEdit_put_SelectionFontItalic(This,newVal)	\
    (This)->lpVtbl -> put_SelectionFontItalic(This,newVal)

#define IRichEdit_get_SelectionFontUnderline(This,pVal)	\
    (This)->lpVtbl -> get_SelectionFontUnderline(This,pVal)

#define IRichEdit_put_SelectionFontUnderline(This,newVal)	\
    (This)->lpVtbl -> put_SelectionFontUnderline(This,newVal)

#define IRichEdit_get_SelectionFontStrikeout(This,pVal)	\
    (This)->lpVtbl -> get_SelectionFontStrikeout(This,pVal)

#define IRichEdit_put_SelectionFontStrikeout(This,newVal)	\
    (This)->lpVtbl -> put_SelectionFontStrikeout(This,newVal)

#define IRichEdit_Undo(This)	\
    (This)->lpVtbl -> Undo(This)

#define IRichEdit_Redo(This)	\
    (This)->lpVtbl -> Redo(This)

#define IRichEdit_get_SelectionDisplay(This,pVal)	\
    (This)->lpVtbl -> get_SelectionDisplay(This,pVal)

#define IRichEdit_put_SelectionDisplay(This,newVal)	\
    (This)->lpVtbl -> put_SelectionDisplay(This,newVal)

#define IRichEdit_get_ReadOnly(This,pVal)	\
    (This)->lpVtbl -> get_ReadOnly(This,pVal)

#define IRichEdit_put_ReadOnly(This,newVal)	\
    (This)->lpVtbl -> put_ReadOnly(This,newVal)

#define IRichEdit_EmptyUndo(This)	\
    (This)->lpVtbl -> EmptyUndo(This)

#define IRichEdit_Cut(This)	\
    (This)->lpVtbl -> Cut(This)

#define IRichEdit_Copy(This)	\
    (This)->lpVtbl -> Copy(This)

#define IRichEdit_Paste(This)	\
    (This)->lpVtbl -> Paste(This)

#define IRichEdit_ReplaceSelection(This,bText)	\
    (This)->lpVtbl -> ReplaceSelection(This,bText)

#define IRichEdit_get_SetStart(This,pVal)	\
    (This)->lpVtbl -> get_SetStart(This,pVal)

#define IRichEdit_put_SetStart(This,newVal)	\
    (This)->lpVtbl -> put_SetStart(This,newVal)

#define IRichEdit_get_SelLength(This,pVal)	\
    (This)->lpVtbl -> get_SelLength(This,pVal)

#define IRichEdit_put_SelLength(This,newVal)	\
    (This)->lpVtbl -> put_SelLength(This,newVal)

#define IRichEdit_get_LineCount(This,pVal)	\
    (This)->lpVtbl -> get_LineCount(This,pVal)

#define IRichEdit_Save(This,bFilename,lOverWrite,pRet)	\
    (This)->lpVtbl -> Save(This,bFilename,lOverWrite,pRet)

#define IRichEdit_Load(This,bFilename,pRet)	\
    (This)->lpVtbl -> Load(This,bFilename,pRet)

#define IRichEdit_get_Modify(This,pVal)	\
    (This)->lpVtbl -> get_Modify(This,pVal)

#define IRichEdit_put_Modify(This,newVal)	\
    (This)->lpVtbl -> put_Modify(This,newVal)

#define IRichEdit_get_FontOffset(This,pVal)	\
    (This)->lpVtbl -> get_FontOffset(This,pVal)

#define IRichEdit_put_FontOffset(This,newVal)	\
    (This)->lpVtbl -> put_FontOffset(This,newVal)

#define IRichEdit_get_SelectionFontOffset(This,pVal)	\
    (This)->lpVtbl -> get_SelectionFontOffset(This,pVal)

#define IRichEdit_put_SelectionFontOffset(This,newVal)	\
    (This)->lpVtbl -> put_SelectionFontOffset(This,newVal)

#define IRichEdit_FindText(This,lType,lStart,lLength,bText,pRet)	\
    (This)->lpVtbl -> FindText(This,lType,lStart,lLength,bText,pRet)

#define IRichEdit_GetTextRange(This,lStart,lLength,pRet)	\
    (This)->lpVtbl -> GetTextRange(This,lStart,lLength,pRet)

#define IRichEdit_CharLine(This,lIndex,pRet)	\
    (This)->lpVtbl -> CharLine(This,lIndex,pRet)

#define IRichEdit_LineChar(This,lLine,pRet)	\
    (This)->lpVtbl -> LineChar(This,lLine,pRet)

#define IRichEdit_LineScroll(This,lXScroll,lYScroll)	\
    (This)->lpVtbl -> LineScroll(This,lXScroll,lYScroll)

#define IRichEdit_get_LeftMargin(This,pVal)	\
    (This)->lpVtbl -> get_LeftMargin(This,pVal)

#define IRichEdit_put_LeftMargin(This,newVal)	\
    (This)->lpVtbl -> put_LeftMargin(This,newVal)

#define IRichEdit_get_RightMargin(This,pVal)	\
    (This)->lpVtbl -> get_RightMargin(This,pVal)

#define IRichEdit_put_RightMargin(This,newVal)	\
    (This)->lpVtbl -> put_RightMargin(This,newVal)

#define IRichEdit_SetTabstops(This,pVar)	\
    (This)->lpVtbl -> SetTabstops(This,pVar)

#define IRichEdit_get_Version(This,pVal)	\
    (This)->lpVtbl -> get_Version(This,pVal)

#define IRichEdit_get_Tabstop(This,pVal)	\
    (This)->lpVtbl -> get_Tabstop(This,pVal)

#define IRichEdit_put_Tabstop(This,newVal)	\
    (This)->lpVtbl -> put_Tabstop(This,newVal)

#define IRichEdit_get_SelectionFontFlags(This,pVal)	\
    (This)->lpVtbl -> get_SelectionFontFlags(This,pVal)

#define IRichEdit_put_SelectionFontFlags(This,newVal)	\
    (This)->lpVtbl -> put_SelectionFontFlags(This,newVal)

#define IRichEdit_get_hWnd(This,pVal)	\
    (This)->lpVtbl -> get_hWnd(This,pVal)

#define IRichEdit_get_SelStart(This,pVal)	\
    (This)->lpVtbl -> get_SelStart(This,pVal)

#define IRichEdit_put_SelStart(This,newVal)	\
    (This)->lpVtbl -> put_SelStart(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_BackColor_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_BackColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_BackColor_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRichEdit_put_BackColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_FontName_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_FontName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_FontName_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IRichEdit_put_FontName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_ForeColor_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_ForeColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_ForeColor_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRichEdit_put_ForeColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_FontSize_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_FontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_FontSize_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRichEdit_put_FontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_FontBold_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_FontBold_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_FontBold_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_FontBold_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_FontItalic_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_FontItalic_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_FontItalic_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_FontItalic_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_FontUnderline_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_FontUnderline_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_FontUnderline_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_FontUnderline_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_FontStrikeout_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_FontStrikeout_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_FontStrikeout_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_FontStrikeout_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_Multiline_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_Multiline_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_Multiline_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_Multiline_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_Scrollbars_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_Scrollbars_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_Scrollbars_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_Scrollbars_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_Border_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_Border_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_Border_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRichEdit_put_Border_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_Caption_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_Caption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_Caption_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IRichEdit_put_Caption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_RTFText_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_RTFText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_RTFText_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IRichEdit_put_RTFText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_Style_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_Style_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_Style_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRichEdit_put_Style_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_Show_Proxy( 
    IRichEdit __RPC_FAR * This);


void __RPC_STUB IRichEdit_Show_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_Hide_Proxy( 
    IRichEdit __RPC_FAR * This);


void __RPC_STUB IRichEdit_Hide_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_SetFocus_Proxy( 
    IRichEdit __RPC_FAR * This);


void __RPC_STUB IRichEdit_SetFocus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_MaxLength_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_MaxLength_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_MaxLength_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRichEdit_put_MaxLength_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SelectionFontName_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SelectionFontName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SelectionFontName_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IRichEdit_put_SelectionFontName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SelectionForeColor_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SelectionForeColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SelectionForeColor_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRichEdit_put_SelectionForeColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SelectionFontSize_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SelectionFontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SelectionFontSize_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_SelectionFontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SelectionFontBold_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SelectionFontBold_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SelectionFontBold_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_SelectionFontBold_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SelectionFontItalic_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SelectionFontItalic_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SelectionFontItalic_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_SelectionFontItalic_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SelectionFontUnderline_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SelectionFontUnderline_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SelectionFontUnderline_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_SelectionFontUnderline_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SelectionFontStrikeout_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SelectionFontStrikeout_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SelectionFontStrikeout_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_SelectionFontStrikeout_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_Undo_Proxy( 
    IRichEdit __RPC_FAR * This);


void __RPC_STUB IRichEdit_Undo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_Redo_Proxy( 
    IRichEdit __RPC_FAR * This);


void __RPC_STUB IRichEdit_Redo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SelectionDisplay_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SelectionDisplay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SelectionDisplay_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_SelectionDisplay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_ReadOnly_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_ReadOnly_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_ReadOnly_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_ReadOnly_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_EmptyUndo_Proxy( 
    IRichEdit __RPC_FAR * This);


void __RPC_STUB IRichEdit_EmptyUndo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_Cut_Proxy( 
    IRichEdit __RPC_FAR * This);


void __RPC_STUB IRichEdit_Cut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_Copy_Proxy( 
    IRichEdit __RPC_FAR * This);


void __RPC_STUB IRichEdit_Copy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_Paste_Proxy( 
    IRichEdit __RPC_FAR * This);


void __RPC_STUB IRichEdit_Paste_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_ReplaceSelection_Proxy( 
    IRichEdit __RPC_FAR * This,
    BSTR bText);


void __RPC_STUB IRichEdit_ReplaceSelection_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SetStart_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SetStart_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SetStart_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_SetStart_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SelLength_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SelLength_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SelLength_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_SelLength_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_LineCount_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_LineCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_Save_Proxy( 
    IRichEdit __RPC_FAR * This,
    BSTR bFilename,
    /* [optional][in] */ long lOverWrite,
    /* [retval][out] */ long __RPC_FAR *pRet);


void __RPC_STUB IRichEdit_Save_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_Load_Proxy( 
    IRichEdit __RPC_FAR * This,
    BSTR bFilename,
    /* [retval][out] */ long __RPC_FAR *pRet);


void __RPC_STUB IRichEdit_Load_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_Modify_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_Modify_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_Modify_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_Modify_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_FontOffset_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_FontOffset_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_FontOffset_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_FontOffset_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SelectionFontOffset_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SelectionFontOffset_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SelectionFontOffset_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long newVal);


void __RPC_STUB IRichEdit_put_SelectionFontOffset_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_FindText_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [optional][in] */ long lType,
    /* [optional][in] */ long lStart,
    /* [optional][in] */ long lLength,
    /* [in] */ BSTR bText,
    /* [retval][out] */ long __RPC_FAR *pRet);


void __RPC_STUB IRichEdit_FindText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_GetTextRange_Proxy( 
    IRichEdit __RPC_FAR * This,
    long lStart,
    long lLength,
    /* [retval][out] */ BSTR __RPC_FAR *pRet);


void __RPC_STUB IRichEdit_GetTextRange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_CharLine_Proxy( 
    IRichEdit __RPC_FAR * This,
    long lIndex,
    /* [retval][out] */ long __RPC_FAR *pRet);


void __RPC_STUB IRichEdit_CharLine_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_LineChar_Proxy( 
    IRichEdit __RPC_FAR * This,
    long lLine,
    /* [retval][out] */ long __RPC_FAR *pRet);


void __RPC_STUB IRichEdit_LineChar_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_LineScroll_Proxy( 
    IRichEdit __RPC_FAR * This,
    long lXScroll,
    long lYScroll);


void __RPC_STUB IRichEdit_LineScroll_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_LeftMargin_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_LeftMargin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_LeftMargin_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRichEdit_put_LeftMargin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_RightMargin_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_RightMargin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_RightMargin_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRichEdit_put_RightMargin_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRichEdit_SetTabstops_Proxy( 
    IRichEdit __RPC_FAR * This,
    VARIANT __RPC_FAR *pVar);


void __RPC_STUB IRichEdit_SetTabstops_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_Version_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_Version_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_Tabstop_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_Tabstop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_Tabstop_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRichEdit_put_Tabstop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SelectionFontFlags_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SelectionFontFlags_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SelectionFontFlags_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRichEdit_put_SelectionFontFlags_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_hWnd_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_hWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRichEdit_get_SelStart_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRichEdit_get_SelStart_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRichEdit_put_SelStart_Proxy( 
    IRichEdit __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRichEdit_put_SelStart_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IRichEdit_INTERFACE_DEFINED__ */



#ifndef __MGCERICHEDITLib_LIBRARY_DEFINED__
#define __MGCERICHEDITLib_LIBRARY_DEFINED__

/* library MGCERICHEDITLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_MGCERICHEDITLib;

#ifndef ___IRichEditEvents_DISPINTERFACE_DEFINED__
#define ___IRichEditEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IRichEditEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IRichEditEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("8F9258FA-70CB-11D3-99BA-0040055A16DF")
    _IRichEditEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IRichEditEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IRichEditEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IRichEditEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IRichEditEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IRichEditEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IRichEditEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IRichEditEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IRichEditEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IRichEditEventsVtbl;

    interface _IRichEditEvents
    {
        CONST_VTBL struct _IRichEditEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IRichEditEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IRichEditEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IRichEditEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IRichEditEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IRichEditEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IRichEditEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IRichEditEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IRichEditEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_RichEdit;

#ifdef __cplusplus

class DECLSPEC_UUID("8F9258F9-70CB-11D3-99BA-0040055A16DF")
RichEdit;
#endif
#endif /* __MGCERICHEDITLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
