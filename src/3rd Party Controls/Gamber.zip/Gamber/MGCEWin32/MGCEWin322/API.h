// API.h : Declaration of the CAPI

#ifndef __API_H_
#define __API_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CAPI
class ATL_NO_VTABLE CAPI : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CAPI, &CLSID_API>,
	public IConnectionPointContainerImpl<CAPI>,
	public IDispatchImpl<IAPI, &IID_IAPI, &LIBID_MGCEWIN322Lib>
{
public:
	CAPI()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_API)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CAPI)
	COM_INTERFACE_ENTRY(IAPI)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
END_COM_MAP()
BEGIN_CONNECTION_POINT_MAP(CAPI)
END_CONNECTION_POINT_MAP()


// IAPI
public:
};

#endif //__API_H_
