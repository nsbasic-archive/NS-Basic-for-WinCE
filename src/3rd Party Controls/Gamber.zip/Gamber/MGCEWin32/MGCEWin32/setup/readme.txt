
Welcome to MGCEWin32 setup! MGCEWin32 provides several controls to applications capable of using objects such as NS Basic. Included with this package are:

Registry Control
Tray Image Control
Win32 API Control
Timer Control
Control documentation and NS Basic example source code

Control documentation and NS Basic example source code are located in the "\My Documents" folder in text format.

NS Basic is (c) NS Basic Corporation
Windows CE is (c) Microsoft Corporation.
MGCEWin32 is by Mark Gamber, September 1999
