//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MGCEWin32.rc
//
#define IDS_PROJNAME                    100
#define IDB_TRAY                        101
#define IDR_TRAY                        102
#define IDB_REGISTRY                    103
#define IDR_REGISTRY                    104
#define IDB_API                         105
#define IDR_API                         106
#define IDB_TIMER                       107
#define IDR_TIMER                       108
#define IDB_RAS                         109
#define IDR_RAS                         110

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           111
#endif
#endif
