/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Dec 03 07:54:20 1999
 */
/* Compiler settings for MGCEWin32.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __MGCEWin32_h__
#define __MGCEWin32_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ITray_FWD_DEFINED__
#define __ITray_FWD_DEFINED__
typedef interface ITray ITray;
#endif 	/* __ITray_FWD_DEFINED__ */


#ifndef ___ITrayEvents_FWD_DEFINED__
#define ___ITrayEvents_FWD_DEFINED__
typedef interface _ITrayEvents _ITrayEvents;
#endif 	/* ___ITrayEvents_FWD_DEFINED__ */


#ifndef __IRegistry_FWD_DEFINED__
#define __IRegistry_FWD_DEFINED__
typedef interface IRegistry IRegistry;
#endif 	/* __IRegistry_FWD_DEFINED__ */


#ifndef __IAPI_FWD_DEFINED__
#define __IAPI_FWD_DEFINED__
typedef interface IAPI IAPI;
#endif 	/* __IAPI_FWD_DEFINED__ */


#ifndef __Tray_FWD_DEFINED__
#define __Tray_FWD_DEFINED__

#ifdef __cplusplus
typedef class Tray Tray;
#else
typedef struct Tray Tray;
#endif /* __cplusplus */

#endif 	/* __Tray_FWD_DEFINED__ */


#ifndef __Registry_FWD_DEFINED__
#define __Registry_FWD_DEFINED__

#ifdef __cplusplus
typedef class Registry Registry;
#else
typedef struct Registry Registry;
#endif /* __cplusplus */

#endif 	/* __Registry_FWD_DEFINED__ */


#ifndef ___IAPIEvents_FWD_DEFINED__
#define ___IAPIEvents_FWD_DEFINED__
typedef interface _IAPIEvents _IAPIEvents;
#endif 	/* ___IAPIEvents_FWD_DEFINED__ */


#ifndef __ITimer_FWD_DEFINED__
#define __ITimer_FWD_DEFINED__
typedef interface ITimer ITimer;
#endif 	/* __ITimer_FWD_DEFINED__ */


#ifndef __API_FWD_DEFINED__
#define __API_FWD_DEFINED__

#ifdef __cplusplus
typedef class API API;
#else
typedef struct API API;
#endif /* __cplusplus */

#endif 	/* __API_FWD_DEFINED__ */


#ifndef ___ITimerEvents_FWD_DEFINED__
#define ___ITimerEvents_FWD_DEFINED__
typedef interface _ITimerEvents _ITimerEvents;
#endif 	/* ___ITimerEvents_FWD_DEFINED__ */


#ifndef __IRAS_FWD_DEFINED__
#define __IRAS_FWD_DEFINED__
typedef interface IRAS IRAS;
#endif 	/* __IRAS_FWD_DEFINED__ */


#ifndef __Timer_FWD_DEFINED__
#define __Timer_FWD_DEFINED__

#ifdef __cplusplus
typedef class Timer Timer;
#else
typedef struct Timer Timer;
#endif /* __cplusplus */

#endif 	/* __Timer_FWD_DEFINED__ */


#ifndef __RAS_FWD_DEFINED__
#define __RAS_FWD_DEFINED__

#ifdef __cplusplus
typedef class RAS RAS;
#else
typedef struct RAS RAS;
#endif /* __cplusplus */

#endif 	/* __RAS_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ITray_INTERFACE_DEFINED__
#define __ITray_INTERFACE_DEFINED__

/* interface ITray */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITray;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5E073C71-6730-11D3-99AC-0040055A16DF")
    ITray : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddImage( 
            BSTR bFilename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RemoveImage( 
            long lImage) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Image( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Image( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Version( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Tag( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Tag( 
            /* [in] */ VARIANT __RPC_FAR *newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITrayVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITray __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITray __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITray __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ITray __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ITray __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ITray __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ITray __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddImage )( 
            ITray __RPC_FAR * This,
            BSTR bFilename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RemoveImage )( 
            ITray __RPC_FAR * This,
            long lImage);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Image )( 
            ITray __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Image )( 
            ITray __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Version )( 
            ITray __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Tag )( 
            ITray __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Tag )( 
            ITray __RPC_FAR * This,
            /* [in] */ VARIANT __RPC_FAR *newVal);
        
        END_INTERFACE
    } ITrayVtbl;

    interface ITray
    {
        CONST_VTBL struct ITrayVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITray_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITray_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITray_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITray_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITray_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITray_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITray_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITray_AddImage(This,bFilename)	\
    (This)->lpVtbl -> AddImage(This,bFilename)

#define ITray_RemoveImage(This,lImage)	\
    (This)->lpVtbl -> RemoveImage(This,lImage)

#define ITray_get_Image(This,pVal)	\
    (This)->lpVtbl -> get_Image(This,pVal)

#define ITray_put_Image(This,newVal)	\
    (This)->lpVtbl -> put_Image(This,newVal)

#define ITray_get_Version(This,pVal)	\
    (This)->lpVtbl -> get_Version(This,pVal)

#define ITray_get_Tag(This,pVal)	\
    (This)->lpVtbl -> get_Tag(This,pVal)

#define ITray_put_Tag(This,newVal)	\
    (This)->lpVtbl -> put_Tag(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITray_AddImage_Proxy( 
    ITray __RPC_FAR * This,
    BSTR bFilename);


void __RPC_STUB ITray_AddImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITray_RemoveImage_Proxy( 
    ITray __RPC_FAR * This,
    long lImage);


void __RPC_STUB ITray_RemoveImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITray_get_Image_Proxy( 
    ITray __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITray_get_Image_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITray_put_Image_Proxy( 
    ITray __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITray_put_Image_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITray_get_Version_Proxy( 
    ITray __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITray_get_Version_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITray_get_Tag_Proxy( 
    ITray __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB ITray_get_Tag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITray_put_Tag_Proxy( 
    ITray __RPC_FAR * This,
    /* [in] */ VARIANT __RPC_FAR *newVal);


void __RPC_STUB ITray_put_Tag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITray_INTERFACE_DEFINED__ */



#ifndef __MGCEWIN32Lib_LIBRARY_DEFINED__
#define __MGCEWIN32Lib_LIBRARY_DEFINED__

/* library MGCEWIN32Lib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_MGCEWIN32Lib;

#ifndef ___ITrayEvents_DISPINTERFACE_DEFINED__
#define ___ITrayEvents_DISPINTERFACE_DEFINED__

/* dispinterface _ITrayEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__ITrayEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("5E073C73-6730-11D3-99AC-0040055A16DF")
    _ITrayEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _ITrayEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _ITrayEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _ITrayEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _ITrayEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _ITrayEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _ITrayEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _ITrayEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _ITrayEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _ITrayEventsVtbl;

    interface _ITrayEvents
    {
        CONST_VTBL struct _ITrayEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _ITrayEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _ITrayEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _ITrayEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _ITrayEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _ITrayEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _ITrayEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _ITrayEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___ITrayEvents_DISPINTERFACE_DEFINED__ */


#ifndef __IRegistry_INTERFACE_DEFINED__
#define __IRegistry_INTERFACE_DEFINED__

/* interface IRegistry */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IRegistry;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D7355FD1-6733-11D3-99AC-0040055A16DF")
    IRegistry : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Key( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Key( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Path( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Path( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Name( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ValueType( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ValueType( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreatePath( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeletePath( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Value( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Value( 
            /* [in] */ VARIANT __RPC_FAR *newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteValue( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetPathName( 
            /* [in] */ long lVal,
            /* [retval][out] */ BSTR __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetValueName( 
            /* [in] */ long lVal,
            /* [retval][out] */ BSTR __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Version( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IRegistryVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IRegistry __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IRegistry __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IRegistry __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IRegistry __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IRegistry __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IRegistry __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IRegistry __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Key )( 
            IRegistry __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Key )( 
            IRegistry __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Path )( 
            IRegistry __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Path )( 
            IRegistry __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Name )( 
            IRegistry __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Name )( 
            IRegistry __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ValueType )( 
            IRegistry __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ValueType )( 
            IRegistry __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreatePath )( 
            IRegistry __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeletePath )( 
            IRegistry __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Value )( 
            IRegistry __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Value )( 
            IRegistry __RPC_FAR * This,
            /* [in] */ VARIANT __RPC_FAR *newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteValue )( 
            IRegistry __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetPathName )( 
            IRegistry __RPC_FAR * This,
            /* [in] */ long lVal,
            /* [retval][out] */ BSTR __RPC_FAR *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetValueName )( 
            IRegistry __RPC_FAR * This,
            /* [in] */ long lVal,
            /* [retval][out] */ BSTR __RPC_FAR *pRet);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Version )( 
            IRegistry __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        END_INTERFACE
    } IRegistryVtbl;

    interface IRegistry
    {
        CONST_VTBL struct IRegistryVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IRegistry_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IRegistry_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IRegistry_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IRegistry_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IRegistry_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IRegistry_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IRegistry_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IRegistry_get_Key(This,pVal)	\
    (This)->lpVtbl -> get_Key(This,pVal)

#define IRegistry_put_Key(This,newVal)	\
    (This)->lpVtbl -> put_Key(This,newVal)

#define IRegistry_get_Path(This,pVal)	\
    (This)->lpVtbl -> get_Path(This,pVal)

#define IRegistry_put_Path(This,newVal)	\
    (This)->lpVtbl -> put_Path(This,newVal)

#define IRegistry_get_Name(This,pVal)	\
    (This)->lpVtbl -> get_Name(This,pVal)

#define IRegistry_put_Name(This,newVal)	\
    (This)->lpVtbl -> put_Name(This,newVal)

#define IRegistry_get_ValueType(This,pVal)	\
    (This)->lpVtbl -> get_ValueType(This,pVal)

#define IRegistry_put_ValueType(This,newVal)	\
    (This)->lpVtbl -> put_ValueType(This,newVal)

#define IRegistry_CreatePath(This)	\
    (This)->lpVtbl -> CreatePath(This)

#define IRegistry_DeletePath(This)	\
    (This)->lpVtbl -> DeletePath(This)

#define IRegistry_get_Value(This,pVal)	\
    (This)->lpVtbl -> get_Value(This,pVal)

#define IRegistry_put_Value(This,newVal)	\
    (This)->lpVtbl -> put_Value(This,newVal)

#define IRegistry_DeleteValue(This)	\
    (This)->lpVtbl -> DeleteValue(This)

#define IRegistry_GetPathName(This,lVal,pRet)	\
    (This)->lpVtbl -> GetPathName(This,lVal,pRet)

#define IRegistry_GetValueName(This,lVal,pRet)	\
    (This)->lpVtbl -> GetValueName(This,lVal,pRet)

#define IRegistry_get_Version(This,pVal)	\
    (This)->lpVtbl -> get_Version(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRegistry_get_Key_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRegistry_get_Key_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRegistry_put_Key_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRegistry_put_Key_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRegistry_get_Path_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IRegistry_get_Path_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRegistry_put_Path_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IRegistry_put_Path_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRegistry_get_Name_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IRegistry_get_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRegistry_put_Name_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IRegistry_put_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRegistry_get_ValueType_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRegistry_get_ValueType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRegistry_put_ValueType_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IRegistry_put_ValueType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRegistry_CreatePath_Proxy( 
    IRegistry __RPC_FAR * This);


void __RPC_STUB IRegistry_CreatePath_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRegistry_DeletePath_Proxy( 
    IRegistry __RPC_FAR * This);


void __RPC_STUB IRegistry_DeletePath_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRegistry_get_Value_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IRegistry_get_Value_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRegistry_put_Value_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [in] */ VARIANT __RPC_FAR *newVal);


void __RPC_STUB IRegistry_put_Value_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRegistry_DeleteValue_Proxy( 
    IRegistry __RPC_FAR * This);


void __RPC_STUB IRegistry_DeleteValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRegistry_GetPathName_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [in] */ long lVal,
    /* [retval][out] */ BSTR __RPC_FAR *pRet);


void __RPC_STUB IRegistry_GetPathName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRegistry_GetValueName_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [in] */ long lVal,
    /* [retval][out] */ BSTR __RPC_FAR *pRet);


void __RPC_STUB IRegistry_GetValueName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRegistry_get_Version_Proxy( 
    IRegistry __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRegistry_get_Version_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IRegistry_INTERFACE_DEFINED__ */


#ifndef __IAPI_INTERFACE_DEFINED__
#define __IAPI_INTERFACE_DEFINED__

/* interface IAPI */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IAPI;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D0C503C9-6736-11D3-99AC-0040055A16DF")
    IAPI : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FindWindow( 
            /* [in] */ BSTR bTitle,
            /* [retval][out] */ long __RPC_FAR *plRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReleaseCapture( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendMessage( 
            /* [in] */ long lWnd,
            /* [in] */ long lMsg,
            /* [in] */ long wParam,
            /* [in] */ long lParam,
            /* [retval][out] */ long __RPC_FAR *plRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendMessageText( 
            /* [in] */ long lWnd,
            /* [in] */ long lMsg,
            /* [in] */ long wParam,
            /* [in] */ BSTR bText,
            /* [retval][out] */ long __RPC_FAR *plRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WindowFromPoint( 
            /* [in] */ long lXpos,
            /* [in] */ long lYpos,
            /* [retval][out] */ long __RPC_FAR *plRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ChildWindowFromPoint( 
            /* [in] */ long lWnd,
            /* [in] */ long lXpos,
            /* [in] */ long lYpos,
            /* [retval][out] */ long __RPC_FAR *plRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE PostMessage( 
            /* [in] */ long lWnd,
            /* [in] */ long lMsg,
            /* [in] */ long wParam,
            /* [in] */ long lParam,
            /* [retval][out] */ long __RPC_FAR *plRet) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ForegroundWindow( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ForegroundWindow( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Focus( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Focus( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Capture( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Capture( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_EnableKeyboard( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_EnableKeyboard( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_WindowText( 
            long lWnd,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_WindowText( 
            long lWnd,
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SystemColor( 
            long lType,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SystemColor( 
            long lType,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Topmost( 
            long lWnd,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_GetWindow( 
            long lWnd,
            long lType,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ClassName( 
            long lWnd,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE showWindow( 
            long lWnd,
            long lFlag) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetAsyncKeyState( 
            /* [in] */ long lKey,
            /* [retval][out] */ long __RPC_FAR *plRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendKeys( 
            BSTR bText,
            long lSilent) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMemoryStatus( 
            /* [in] */ long lType,
            /* [retval][out] */ long __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetStorageStatus( 
            /* [in] */ long lType,
            /* [retval][out] */ long __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetPowerStatus( 
            /* [in] */ long lType,
            /* [retval][out] */ long __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SystemParameters( 
            long lType,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SystemParameters( 
            long lType,
            /* [in] */ VARIANT __RPC_FAR *newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreateShortcut( 
            BSTR bShortcut,
            BSTR bTarget) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddToRecent( 
            BSTR bPath) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetSpecialFolder( 
            /* [in] */ long lType,
            /* [retval][out] */ BSTR __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_GetShortcutTarget( 
            BSTR bTarget,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE FindWindowByClass( 
            BSTR bClass,
            /* [retval][out] */ long __RPC_FAR *lRet) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ClipText( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ClipText( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Version( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CursorPos( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SystemVersion( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_WindowLong( 
            long lWnd,
            long lPos,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_WindowLong( 
            long lWnd,
            long lPos,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Ticks( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SystemTime( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SystemTime( 
            /* [in] */ VARIANT __RPC_FAR *newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_LocalTime( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_LocalTime( 
            /* [in] */ VARIANT __RPC_FAR *newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_WindowParent( 
            long lWnd,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_WindowParent( 
            long lWnd,
            /* [in] */ long newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAPIVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IAPI __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IAPI __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IAPI __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IAPI __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IAPI __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IAPI __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IAPI __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindWindow )( 
            IAPI __RPC_FAR * This,
            /* [in] */ BSTR bTitle,
            /* [retval][out] */ long __RPC_FAR *plRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReleaseCapture )( 
            IAPI __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SendMessage )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long lWnd,
            /* [in] */ long lMsg,
            /* [in] */ long wParam,
            /* [in] */ long lParam,
            /* [retval][out] */ long __RPC_FAR *plRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SendMessageText )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long lWnd,
            /* [in] */ long lMsg,
            /* [in] */ long wParam,
            /* [in] */ BSTR bText,
            /* [retval][out] */ long __RPC_FAR *plRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WindowFromPoint )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long lXpos,
            /* [in] */ long lYpos,
            /* [retval][out] */ long __RPC_FAR *plRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ChildWindowFromPoint )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long lWnd,
            /* [in] */ long lXpos,
            /* [in] */ long lYpos,
            /* [retval][out] */ long __RPC_FAR *plRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PostMessage )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long lWnd,
            /* [in] */ long lMsg,
            /* [in] */ long wParam,
            /* [in] */ long lParam,
            /* [retval][out] */ long __RPC_FAR *plRet);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ForegroundWindow )( 
            IAPI __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ForegroundWindow )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Focus )( 
            IAPI __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Focus )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Capture )( 
            IAPI __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Capture )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_EnableKeyboard )( 
            IAPI __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_EnableKeyboard )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_WindowText )( 
            IAPI __RPC_FAR * This,
            long lWnd,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_WindowText )( 
            IAPI __RPC_FAR * This,
            long lWnd,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SystemColor )( 
            IAPI __RPC_FAR * This,
            long lType,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SystemColor )( 
            IAPI __RPC_FAR * This,
            long lType,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Topmost )( 
            IAPI __RPC_FAR * This,
            long lWnd,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_GetWindow )( 
            IAPI __RPC_FAR * This,
            long lWnd,
            long lType,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ClassName )( 
            IAPI __RPC_FAR * This,
            long lWnd,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *showWindow )( 
            IAPI __RPC_FAR * This,
            long lWnd,
            long lFlag);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAsyncKeyState )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long lKey,
            /* [retval][out] */ long __RPC_FAR *plRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SendKeys )( 
            IAPI __RPC_FAR * This,
            BSTR bText,
            long lSilent);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetMemoryStatus )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long lType,
            /* [retval][out] */ long __RPC_FAR *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetStorageStatus )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long lType,
            /* [retval][out] */ long __RPC_FAR *pRet);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetPowerStatus )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long lType,
            /* [retval][out] */ long __RPC_FAR *pRet);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SystemParameters )( 
            IAPI __RPC_FAR * This,
            long lType,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SystemParameters )( 
            IAPI __RPC_FAR * This,
            long lType,
            /* [in] */ VARIANT __RPC_FAR *newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreateShortcut )( 
            IAPI __RPC_FAR * This,
            BSTR bShortcut,
            BSTR bTarget);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddToRecent )( 
            IAPI __RPC_FAR * This,
            BSTR bPath);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetSpecialFolder )( 
            IAPI __RPC_FAR * This,
            /* [in] */ long lType,
            /* [retval][out] */ BSTR __RPC_FAR *pRet);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_GetShortcutTarget )( 
            IAPI __RPC_FAR * This,
            BSTR bTarget,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindWindowByClass )( 
            IAPI __RPC_FAR * This,
            BSTR bClass,
            /* [retval][out] */ long __RPC_FAR *lRet);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ClipText )( 
            IAPI __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ClipText )( 
            IAPI __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Version )( 
            IAPI __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CursorPos )( 
            IAPI __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SystemVersion )( 
            IAPI __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_WindowLong )( 
            IAPI __RPC_FAR * This,
            long lWnd,
            long lPos,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_WindowLong )( 
            IAPI __RPC_FAR * This,
            long lWnd,
            long lPos,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Ticks )( 
            IAPI __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SystemTime )( 
            IAPI __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SystemTime )( 
            IAPI __RPC_FAR * This,
            /* [in] */ VARIANT __RPC_FAR *newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_LocalTime )( 
            IAPI __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_LocalTime )( 
            IAPI __RPC_FAR * This,
            /* [in] */ VARIANT __RPC_FAR *newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_WindowParent )( 
            IAPI __RPC_FAR * This,
            long lWnd,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_WindowParent )( 
            IAPI __RPC_FAR * This,
            long lWnd,
            /* [in] */ long newVal);
        
        END_INTERFACE
    } IAPIVtbl;

    interface IAPI
    {
        CONST_VTBL struct IAPIVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAPI_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IAPI_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IAPI_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IAPI_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IAPI_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IAPI_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IAPI_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IAPI_FindWindow(This,bTitle,plRet)	\
    (This)->lpVtbl -> FindWindow(This,bTitle,plRet)

#define IAPI_ReleaseCapture(This)	\
    (This)->lpVtbl -> ReleaseCapture(This)

#define IAPI_SendMessage(This,lWnd,lMsg,wParam,lParam,plRet)	\
    (This)->lpVtbl -> SendMessage(This,lWnd,lMsg,wParam,lParam,plRet)

#define IAPI_SendMessageText(This,lWnd,lMsg,wParam,bText,plRet)	\
    (This)->lpVtbl -> SendMessageText(This,lWnd,lMsg,wParam,bText,plRet)

#define IAPI_WindowFromPoint(This,lXpos,lYpos,plRet)	\
    (This)->lpVtbl -> WindowFromPoint(This,lXpos,lYpos,plRet)

#define IAPI_ChildWindowFromPoint(This,lWnd,lXpos,lYpos,plRet)	\
    (This)->lpVtbl -> ChildWindowFromPoint(This,lWnd,lXpos,lYpos,plRet)

#define IAPI_PostMessage(This,lWnd,lMsg,wParam,lParam,plRet)	\
    (This)->lpVtbl -> PostMessage(This,lWnd,lMsg,wParam,lParam,plRet)

#define IAPI_get_ForegroundWindow(This,pVal)	\
    (This)->lpVtbl -> get_ForegroundWindow(This,pVal)

#define IAPI_put_ForegroundWindow(This,newVal)	\
    (This)->lpVtbl -> put_ForegroundWindow(This,newVal)

#define IAPI_get_Focus(This,pVal)	\
    (This)->lpVtbl -> get_Focus(This,pVal)

#define IAPI_put_Focus(This,newVal)	\
    (This)->lpVtbl -> put_Focus(This,newVal)

#define IAPI_get_Capture(This,pVal)	\
    (This)->lpVtbl -> get_Capture(This,pVal)

#define IAPI_put_Capture(This,newVal)	\
    (This)->lpVtbl -> put_Capture(This,newVal)

#define IAPI_get_EnableKeyboard(This,pVal)	\
    (This)->lpVtbl -> get_EnableKeyboard(This,pVal)

#define IAPI_put_EnableKeyboard(This,newVal)	\
    (This)->lpVtbl -> put_EnableKeyboard(This,newVal)

#define IAPI_get_WindowText(This,lWnd,pVal)	\
    (This)->lpVtbl -> get_WindowText(This,lWnd,pVal)

#define IAPI_put_WindowText(This,lWnd,newVal)	\
    (This)->lpVtbl -> put_WindowText(This,lWnd,newVal)

#define IAPI_get_SystemColor(This,lType,pVal)	\
    (This)->lpVtbl -> get_SystemColor(This,lType,pVal)

#define IAPI_put_SystemColor(This,lType,newVal)	\
    (This)->lpVtbl -> put_SystemColor(This,lType,newVal)

#define IAPI_put_Topmost(This,lWnd,newVal)	\
    (This)->lpVtbl -> put_Topmost(This,lWnd,newVal)

#define IAPI_get_GetWindow(This,lWnd,lType,pVal)	\
    (This)->lpVtbl -> get_GetWindow(This,lWnd,lType,pVal)

#define IAPI_get_ClassName(This,lWnd,pVal)	\
    (This)->lpVtbl -> get_ClassName(This,lWnd,pVal)

#define IAPI_showWindow(This,lWnd,lFlag)	\
    (This)->lpVtbl -> showWindow(This,lWnd,lFlag)

#define IAPI_GetAsyncKeyState(This,lKey,plRet)	\
    (This)->lpVtbl -> GetAsyncKeyState(This,lKey,plRet)

#define IAPI_SendKeys(This,bText,lSilent)	\
    (This)->lpVtbl -> SendKeys(This,bText,lSilent)

#define IAPI_GetMemoryStatus(This,lType,pRet)	\
    (This)->lpVtbl -> GetMemoryStatus(This,lType,pRet)

#define IAPI_GetStorageStatus(This,lType,pRet)	\
    (This)->lpVtbl -> GetStorageStatus(This,lType,pRet)

#define IAPI_GetPowerStatus(This,lType,pRet)	\
    (This)->lpVtbl -> GetPowerStatus(This,lType,pRet)

#define IAPI_get_SystemParameters(This,lType,pVal)	\
    (This)->lpVtbl -> get_SystemParameters(This,lType,pVal)

#define IAPI_put_SystemParameters(This,lType,newVal)	\
    (This)->lpVtbl -> put_SystemParameters(This,lType,newVal)

#define IAPI_CreateShortcut(This,bShortcut,bTarget)	\
    (This)->lpVtbl -> CreateShortcut(This,bShortcut,bTarget)

#define IAPI_AddToRecent(This,bPath)	\
    (This)->lpVtbl -> AddToRecent(This,bPath)

#define IAPI_GetSpecialFolder(This,lType,pRet)	\
    (This)->lpVtbl -> GetSpecialFolder(This,lType,pRet)

#define IAPI_get_GetShortcutTarget(This,bTarget,pVal)	\
    (This)->lpVtbl -> get_GetShortcutTarget(This,bTarget,pVal)

#define IAPI_FindWindowByClass(This,bClass,lRet)	\
    (This)->lpVtbl -> FindWindowByClass(This,bClass,lRet)

#define IAPI_get_ClipText(This,pVal)	\
    (This)->lpVtbl -> get_ClipText(This,pVal)

#define IAPI_put_ClipText(This,newVal)	\
    (This)->lpVtbl -> put_ClipText(This,newVal)

#define IAPI_get_Version(This,pVal)	\
    (This)->lpVtbl -> get_Version(This,pVal)

#define IAPI_get_CursorPos(This,pVal)	\
    (This)->lpVtbl -> get_CursorPos(This,pVal)

#define IAPI_get_SystemVersion(This,pVal)	\
    (This)->lpVtbl -> get_SystemVersion(This,pVal)

#define IAPI_get_WindowLong(This,lWnd,lPos,pVal)	\
    (This)->lpVtbl -> get_WindowLong(This,lWnd,lPos,pVal)

#define IAPI_put_WindowLong(This,lWnd,lPos,newVal)	\
    (This)->lpVtbl -> put_WindowLong(This,lWnd,lPos,newVal)

#define IAPI_get_Ticks(This,pVal)	\
    (This)->lpVtbl -> get_Ticks(This,pVal)

#define IAPI_get_SystemTime(This,pVal)	\
    (This)->lpVtbl -> get_SystemTime(This,pVal)

#define IAPI_put_SystemTime(This,newVal)	\
    (This)->lpVtbl -> put_SystemTime(This,newVal)

#define IAPI_get_LocalTime(This,pVal)	\
    (This)->lpVtbl -> get_LocalTime(This,pVal)

#define IAPI_put_LocalTime(This,newVal)	\
    (This)->lpVtbl -> put_LocalTime(This,newVal)

#define IAPI_get_WindowParent(This,lWnd,pVal)	\
    (This)->lpVtbl -> get_WindowParent(This,lWnd,pVal)

#define IAPI_put_WindowParent(This,lWnd,newVal)	\
    (This)->lpVtbl -> put_WindowParent(This,lWnd,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_FindWindow_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ BSTR bTitle,
    /* [retval][out] */ long __RPC_FAR *plRet);


void __RPC_STUB IAPI_FindWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_ReleaseCapture_Proxy( 
    IAPI __RPC_FAR * This);


void __RPC_STUB IAPI_ReleaseCapture_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_SendMessage_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long lWnd,
    /* [in] */ long lMsg,
    /* [in] */ long wParam,
    /* [in] */ long lParam,
    /* [retval][out] */ long __RPC_FAR *plRet);


void __RPC_STUB IAPI_SendMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_SendMessageText_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long lWnd,
    /* [in] */ long lMsg,
    /* [in] */ long wParam,
    /* [in] */ BSTR bText,
    /* [retval][out] */ long __RPC_FAR *plRet);


void __RPC_STUB IAPI_SendMessageText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_WindowFromPoint_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long lXpos,
    /* [in] */ long lYpos,
    /* [retval][out] */ long __RPC_FAR *plRet);


void __RPC_STUB IAPI_WindowFromPoint_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_ChildWindowFromPoint_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long lWnd,
    /* [in] */ long lXpos,
    /* [in] */ long lYpos,
    /* [retval][out] */ long __RPC_FAR *plRet);


void __RPC_STUB IAPI_ChildWindowFromPoint_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_PostMessage_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long lWnd,
    /* [in] */ long lMsg,
    /* [in] */ long wParam,
    /* [in] */ long lParam,
    /* [retval][out] */ long __RPC_FAR *plRet);


void __RPC_STUB IAPI_PostMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_ForegroundWindow_Proxy( 
    IAPI __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_ForegroundWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_ForegroundWindow_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IAPI_put_ForegroundWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_Focus_Proxy( 
    IAPI __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_Focus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_Focus_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IAPI_put_Focus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_Capture_Proxy( 
    IAPI __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_Capture_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_Capture_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IAPI_put_Capture_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_EnableKeyboard_Proxy( 
    IAPI __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_EnableKeyboard_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_EnableKeyboard_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IAPI_put_EnableKeyboard_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_WindowText_Proxy( 
    IAPI __RPC_FAR * This,
    long lWnd,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_WindowText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_WindowText_Proxy( 
    IAPI __RPC_FAR * This,
    long lWnd,
    /* [in] */ BSTR newVal);


void __RPC_STUB IAPI_put_WindowText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_SystemColor_Proxy( 
    IAPI __RPC_FAR * This,
    long lType,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_SystemColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_SystemColor_Proxy( 
    IAPI __RPC_FAR * This,
    long lType,
    /* [in] */ long newVal);


void __RPC_STUB IAPI_put_SystemColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_Topmost_Proxy( 
    IAPI __RPC_FAR * This,
    long lWnd,
    /* [in] */ long newVal);


void __RPC_STUB IAPI_put_Topmost_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_GetWindow_Proxy( 
    IAPI __RPC_FAR * This,
    long lWnd,
    long lType,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_GetWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_ClassName_Proxy( 
    IAPI __RPC_FAR * This,
    long lWnd,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_ClassName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_showWindow_Proxy( 
    IAPI __RPC_FAR * This,
    long lWnd,
    long lFlag);


void __RPC_STUB IAPI_showWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_GetAsyncKeyState_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long lKey,
    /* [retval][out] */ long __RPC_FAR *plRet);


void __RPC_STUB IAPI_GetAsyncKeyState_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_SendKeys_Proxy( 
    IAPI __RPC_FAR * This,
    BSTR bText,
    long lSilent);


void __RPC_STUB IAPI_SendKeys_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_GetMemoryStatus_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long lType,
    /* [retval][out] */ long __RPC_FAR *pRet);


void __RPC_STUB IAPI_GetMemoryStatus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_GetStorageStatus_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long lType,
    /* [retval][out] */ long __RPC_FAR *pRet);


void __RPC_STUB IAPI_GetStorageStatus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_GetPowerStatus_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long lType,
    /* [retval][out] */ long __RPC_FAR *pRet);


void __RPC_STUB IAPI_GetPowerStatus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_SystemParameters_Proxy( 
    IAPI __RPC_FAR * This,
    long lType,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_SystemParameters_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_SystemParameters_Proxy( 
    IAPI __RPC_FAR * This,
    long lType,
    /* [in] */ VARIANT __RPC_FAR *newVal);


void __RPC_STUB IAPI_put_SystemParameters_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_CreateShortcut_Proxy( 
    IAPI __RPC_FAR * This,
    BSTR bShortcut,
    BSTR bTarget);


void __RPC_STUB IAPI_CreateShortcut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_AddToRecent_Proxy( 
    IAPI __RPC_FAR * This,
    BSTR bPath);


void __RPC_STUB IAPI_AddToRecent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_GetSpecialFolder_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ long lType,
    /* [retval][out] */ BSTR __RPC_FAR *pRet);


void __RPC_STUB IAPI_GetSpecialFolder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_GetShortcutTarget_Proxy( 
    IAPI __RPC_FAR * This,
    BSTR bTarget,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_GetShortcutTarget_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAPI_FindWindowByClass_Proxy( 
    IAPI __RPC_FAR * This,
    BSTR bClass,
    /* [retval][out] */ long __RPC_FAR *lRet);


void __RPC_STUB IAPI_FindWindowByClass_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_ClipText_Proxy( 
    IAPI __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_ClipText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_ClipText_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IAPI_put_ClipText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_Version_Proxy( 
    IAPI __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_Version_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_CursorPos_Proxy( 
    IAPI __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_CursorPos_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_SystemVersion_Proxy( 
    IAPI __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_SystemVersion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_WindowLong_Proxy( 
    IAPI __RPC_FAR * This,
    long lWnd,
    long lPos,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_WindowLong_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_WindowLong_Proxy( 
    IAPI __RPC_FAR * This,
    long lWnd,
    long lPos,
    /* [in] */ long newVal);


void __RPC_STUB IAPI_put_WindowLong_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_Ticks_Proxy( 
    IAPI __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_Ticks_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_SystemTime_Proxy( 
    IAPI __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_SystemTime_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_SystemTime_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ VARIANT __RPC_FAR *newVal);


void __RPC_STUB IAPI_put_SystemTime_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_LocalTime_Proxy( 
    IAPI __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_LocalTime_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_LocalTime_Proxy( 
    IAPI __RPC_FAR * This,
    /* [in] */ VARIANT __RPC_FAR *newVal);


void __RPC_STUB IAPI_put_LocalTime_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAPI_get_WindowParent_Proxy( 
    IAPI __RPC_FAR * This,
    long lWnd,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IAPI_get_WindowParent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAPI_put_WindowParent_Proxy( 
    IAPI __RPC_FAR * This,
    long lWnd,
    /* [in] */ long newVal);


void __RPC_STUB IAPI_put_WindowParent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IAPI_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_Tray;

#ifdef __cplusplus

class DECLSPEC_UUID("5E073C72-6730-11D3-99AC-0040055A16DF")
Tray;
#endif

EXTERN_C const CLSID CLSID_Registry;

#ifdef __cplusplus

class DECLSPEC_UUID("D7355FD2-6733-11D3-99AC-0040055A16DF")
Registry;
#endif

#ifndef ___IAPIEvents_DISPINTERFACE_DEFINED__
#define ___IAPIEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IAPIEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IAPIEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("D0C503CB-6736-11D3-99AC-0040055A16DF")
    _IAPIEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IAPIEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IAPIEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IAPIEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IAPIEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IAPIEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IAPIEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IAPIEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IAPIEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IAPIEventsVtbl;

    interface _IAPIEvents
    {
        CONST_VTBL struct _IAPIEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IAPIEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IAPIEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IAPIEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IAPIEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IAPIEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IAPIEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IAPIEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IAPIEvents_DISPINTERFACE_DEFINED__ */


#ifndef __ITimer_INTERFACE_DEFINED__
#define __ITimer_INTERFACE_DEFINED__

/* interface ITimer */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITimer;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B1F386DF-6986-11D3-99B1-0040055A16DF")
    ITimer : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Interval( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Interval( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Start( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Stop( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Version( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Tag( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Tag( 
            /* [in] */ VARIANT __RPC_FAR *newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITimerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITimer __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITimer __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITimer __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ITimer __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ITimer __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ITimer __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ITimer __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Interval )( 
            ITimer __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Interval )( 
            ITimer __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Start )( 
            ITimer __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Stop )( 
            ITimer __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Version )( 
            ITimer __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Tag )( 
            ITimer __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Tag )( 
            ITimer __RPC_FAR * This,
            /* [in] */ VARIANT __RPC_FAR *newVal);
        
        END_INTERFACE
    } ITimerVtbl;

    interface ITimer
    {
        CONST_VTBL struct ITimerVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITimer_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITimer_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITimer_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITimer_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITimer_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITimer_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITimer_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITimer_get_Interval(This,pVal)	\
    (This)->lpVtbl -> get_Interval(This,pVal)

#define ITimer_put_Interval(This,newVal)	\
    (This)->lpVtbl -> put_Interval(This,newVal)

#define ITimer_Start(This)	\
    (This)->lpVtbl -> Start(This)

#define ITimer_Stop(This)	\
    (This)->lpVtbl -> Stop(This)

#define ITimer_get_Version(This,pVal)	\
    (This)->lpVtbl -> get_Version(This,pVal)

#define ITimer_get_Tag(This,pVal)	\
    (This)->lpVtbl -> get_Tag(This,pVal)

#define ITimer_put_Tag(This,newVal)	\
    (This)->lpVtbl -> put_Tag(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITimer_get_Interval_Proxy( 
    ITimer __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITimer_get_Interval_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITimer_put_Interval_Proxy( 
    ITimer __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITimer_put_Interval_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITimer_Start_Proxy( 
    ITimer __RPC_FAR * This);


void __RPC_STUB ITimer_Start_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITimer_Stop_Proxy( 
    ITimer __RPC_FAR * This);


void __RPC_STUB ITimer_Stop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITimer_get_Version_Proxy( 
    ITimer __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITimer_get_Version_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITimer_get_Tag_Proxy( 
    ITimer __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB ITimer_get_Tag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITimer_put_Tag_Proxy( 
    ITimer __RPC_FAR * This,
    /* [in] */ VARIANT __RPC_FAR *newVal);


void __RPC_STUB ITimer_put_Tag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITimer_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_API;

#ifdef __cplusplus

class DECLSPEC_UUID("D0C503CA-6736-11D3-99AC-0040055A16DF")
API;
#endif

#ifndef ___ITimerEvents_DISPINTERFACE_DEFINED__
#define ___ITimerEvents_DISPINTERFACE_DEFINED__

/* dispinterface _ITimerEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__ITimerEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("B1F386E1-6986-11D3-99B1-0040055A16DF")
    _ITimerEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _ITimerEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _ITimerEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _ITimerEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _ITimerEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _ITimerEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _ITimerEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _ITimerEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _ITimerEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _ITimerEventsVtbl;

    interface _ITimerEvents
    {
        CONST_VTBL struct _ITimerEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _ITimerEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _ITimerEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _ITimerEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _ITimerEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _ITimerEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _ITimerEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _ITimerEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___ITimerEvents_DISPINTERFACE_DEFINED__ */


#ifndef __IRAS_INTERFACE_DEFINED__
#define __IRAS_INTERFACE_DEFINED__

/* interface IRAS */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IRAS;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("A60ADFB5-8530-11D3-9C5A-0040055A16DF")
    IRAS : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_AllEntries( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_EntryName( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_EntryName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_PhoneNumber( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_PhoneNumber( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_UserName( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_UserName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Password( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Password( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Domain( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Domain( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Connect( 
            /* [retval][out] */ long __RPC_FAR *plConn) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Disconnect( 
            long lConn) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ConnectionStatus( 
            long lConn,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetDialParams( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetDialParams( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RenameEntry( 
            BSTR bFrom,
            BSTR bTo) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Clear( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Validate( 
            BSTR bName,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_AllConnections( 
            /* [retval][out] */ VARIANT __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteEntry( 
            BSTR bName) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Version( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IRASVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IRAS __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IRAS __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IRAS __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IRAS __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IRAS __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IRAS __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IRAS __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AllEntries )( 
            IRAS __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_EntryName )( 
            IRAS __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_EntryName )( 
            IRAS __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PhoneNumber )( 
            IRAS __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_PhoneNumber )( 
            IRAS __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_UserName )( 
            IRAS __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_UserName )( 
            IRAS __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Password )( 
            IRAS __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Password )( 
            IRAS __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Domain )( 
            IRAS __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Domain )( 
            IRAS __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Connect )( 
            IRAS __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plConn);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Disconnect )( 
            IRAS __RPC_FAR * This,
            long lConn);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ConnectionStatus )( 
            IRAS __RPC_FAR * This,
            long lConn,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDialParams )( 
            IRAS __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDialParams )( 
            IRAS __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RenameEntry )( 
            IRAS __RPC_FAR * This,
            BSTR bFrom,
            BSTR bTo);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clear )( 
            IRAS __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Validate )( 
            IRAS __RPC_FAR * This,
            BSTR bName,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AllConnections )( 
            IRAS __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteEntry )( 
            IRAS __RPC_FAR * This,
            BSTR bName);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Version )( 
            IRAS __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        END_INTERFACE
    } IRASVtbl;

    interface IRAS
    {
        CONST_VTBL struct IRASVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IRAS_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IRAS_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IRAS_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IRAS_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IRAS_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IRAS_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IRAS_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IRAS_get_AllEntries(This,pVal)	\
    (This)->lpVtbl -> get_AllEntries(This,pVal)

#define IRAS_get_EntryName(This,pVal)	\
    (This)->lpVtbl -> get_EntryName(This,pVal)

#define IRAS_put_EntryName(This,newVal)	\
    (This)->lpVtbl -> put_EntryName(This,newVal)

#define IRAS_get_PhoneNumber(This,pVal)	\
    (This)->lpVtbl -> get_PhoneNumber(This,pVal)

#define IRAS_put_PhoneNumber(This,newVal)	\
    (This)->lpVtbl -> put_PhoneNumber(This,newVal)

#define IRAS_get_UserName(This,pVal)	\
    (This)->lpVtbl -> get_UserName(This,pVal)

#define IRAS_put_UserName(This,newVal)	\
    (This)->lpVtbl -> put_UserName(This,newVal)

#define IRAS_get_Password(This,pVal)	\
    (This)->lpVtbl -> get_Password(This,pVal)

#define IRAS_put_Password(This,newVal)	\
    (This)->lpVtbl -> put_Password(This,newVal)

#define IRAS_get_Domain(This,pVal)	\
    (This)->lpVtbl -> get_Domain(This,pVal)

#define IRAS_put_Domain(This,newVal)	\
    (This)->lpVtbl -> put_Domain(This,newVal)

#define IRAS_Connect(This,plConn)	\
    (This)->lpVtbl -> Connect(This,plConn)

#define IRAS_Disconnect(This,lConn)	\
    (This)->lpVtbl -> Disconnect(This,lConn)

#define IRAS_get_ConnectionStatus(This,lConn,pVal)	\
    (This)->lpVtbl -> get_ConnectionStatus(This,lConn,pVal)

#define IRAS_GetDialParams(This)	\
    (This)->lpVtbl -> GetDialParams(This)

#define IRAS_SetDialParams(This)	\
    (This)->lpVtbl -> SetDialParams(This)

#define IRAS_RenameEntry(This,bFrom,bTo)	\
    (This)->lpVtbl -> RenameEntry(This,bFrom,bTo)

#define IRAS_Clear(This)	\
    (This)->lpVtbl -> Clear(This)

#define IRAS_get_Validate(This,bName,pVal)	\
    (This)->lpVtbl -> get_Validate(This,bName,pVal)

#define IRAS_get_AllConnections(This,pVal)	\
    (This)->lpVtbl -> get_AllConnections(This,pVal)

#define IRAS_DeleteEntry(This,bName)	\
    (This)->lpVtbl -> DeleteEntry(This,bName)

#define IRAS_get_Version(This,pVal)	\
    (This)->lpVtbl -> get_Version(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRAS_get_AllEntries_Proxy( 
    IRAS __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IRAS_get_AllEntries_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRAS_get_EntryName_Proxy( 
    IRAS __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IRAS_get_EntryName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRAS_put_EntryName_Proxy( 
    IRAS __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IRAS_put_EntryName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRAS_get_PhoneNumber_Proxy( 
    IRAS __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IRAS_get_PhoneNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRAS_put_PhoneNumber_Proxy( 
    IRAS __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IRAS_put_PhoneNumber_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRAS_get_UserName_Proxy( 
    IRAS __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IRAS_get_UserName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRAS_put_UserName_Proxy( 
    IRAS __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IRAS_put_UserName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRAS_get_Password_Proxy( 
    IRAS __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IRAS_get_Password_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRAS_put_Password_Proxy( 
    IRAS __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IRAS_put_Password_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRAS_get_Domain_Proxy( 
    IRAS __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IRAS_get_Domain_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IRAS_put_Domain_Proxy( 
    IRAS __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IRAS_put_Domain_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRAS_Connect_Proxy( 
    IRAS __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plConn);


void __RPC_STUB IRAS_Connect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRAS_Disconnect_Proxy( 
    IRAS __RPC_FAR * This,
    long lConn);


void __RPC_STUB IRAS_Disconnect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRAS_get_ConnectionStatus_Proxy( 
    IRAS __RPC_FAR * This,
    long lConn,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRAS_get_ConnectionStatus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRAS_GetDialParams_Proxy( 
    IRAS __RPC_FAR * This);


void __RPC_STUB IRAS_GetDialParams_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRAS_SetDialParams_Proxy( 
    IRAS __RPC_FAR * This);


void __RPC_STUB IRAS_SetDialParams_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRAS_RenameEntry_Proxy( 
    IRAS __RPC_FAR * This,
    BSTR bFrom,
    BSTR bTo);


void __RPC_STUB IRAS_RenameEntry_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRAS_Clear_Proxy( 
    IRAS __RPC_FAR * This);


void __RPC_STUB IRAS_Clear_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRAS_get_Validate_Proxy( 
    IRAS __RPC_FAR * This,
    BSTR bName,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRAS_get_Validate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRAS_get_AllConnections_Proxy( 
    IRAS __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pVal);


void __RPC_STUB IRAS_get_AllConnections_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRAS_DeleteEntry_Proxy( 
    IRAS __RPC_FAR * This,
    BSTR bName);


void __RPC_STUB IRAS_DeleteEntry_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IRAS_get_Version_Proxy( 
    IRAS __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IRAS_get_Version_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IRAS_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_Timer;

#ifdef __cplusplus

class DECLSPEC_UUID("B1F386E0-6986-11D3-99B1-0040055A16DF")
Timer;
#endif

EXTERN_C const CLSID CLSID_RAS;

#ifdef __cplusplus

class DECLSPEC_UUID("A60ADFB6-8530-11D3-9C5A-0040055A16DF")
RAS;
#endif
#endif /* __MGCEWIN32Lib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
