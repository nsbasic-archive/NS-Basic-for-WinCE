//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by YachtCE.rc
//
#define IDD_MAINDLG                     103
#define IDI_MAINICON                    104
#define IDD_ABOUT                       105
#define IDI_ICON1                       107
#define IDI_ICON2                       108
#define IDI_ICON3                       109
#define IDI_ICON4                       110
#define IDI_ICON5                       111
#define IDI_ICON6                       112
#define IDD_SPLASH                      113
#define IDC_DICE1                       1000
#define IDC_DICE2                       1001
#define IDC_DICE3                       1002
#define IDC_DICE4                       1003
#define IDC_DICE5                       1004
#define IDC_ROLL                        1005
#define IDC_ONES                        1006
#define IDC_TWOS                        1007
#define IDC_THREES                      1008
#define IDC_FOURS                       1009
#define IDC_FIVES                       1010
#define IDC_SIXES                       1011
#define IDC_BONUS                       1012
#define IDC_ONEPAIR                     1013
#define IDC_TWOPAIR                     1014
#define IDC_THREEOFAKIND                1015
#define IDC_FOUROFAKIND                 1016
#define IDC_SMSTRAIGHT                  1017
#define IDC_LGSTRAIGHT                  1018
#define IDC_FULLHOUSE                   1019
#define IDC_CHANCE                      1020
#define IDC_YACHT                       1021
#define IDC_SUBTOTAL                    1022
#define IDC_SCORE                       1023
#define IDC_NEWGAME                     1025
#define IDC_ABOUT                       1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
