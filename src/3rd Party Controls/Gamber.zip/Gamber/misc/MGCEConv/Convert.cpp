// Convert.cpp : Implementation of CConvert
#include "stdafx.h"
#include "MGCEConv.h"
#include "Convert.h"

/////////////////////////////////////////////////////////////////////////////
// CConvert


STDMETHODIMP CConvert::BinaryToHex(VARIANT *pBin, BSTR *pbHex)
{
	long lLBound, lUBound, lElements, i;
	VARIANT *pArray;
	BSTR pBuffer;
	TCHAR szStr[ 128 ];


	wsprintf( szStr, L"vt=%d", pBin->vt );
	*pbHex = SysAllocString( szStr );
	return S_OK;

	if( ( pBin->vt & VT_ARRAY ) == 0 )   return E_FAIL;
	if( SafeArrayAccessData( V_ARRAY( pBin ), (void **)&pArray ) != S_OK )
		return E_FAIL;
	SafeArrayGetLBound( V_ARRAY( pBin ), 1, &lLBound );
	SafeArrayGetUBound( V_ARRAY( pBin ), 1, &lUBound );
	lElements = lUBound - lLBound + 1;
	pBuffer = (BSTR)LocalAlloc( LPTR, ( lElements + 8 ) * sizeof(TCHAR) );
	if( ! pBuffer ) {
		SafeArrayUnaccessData( V_ARRAY( pBin ) );
		SafeArrayDestroy( V_ARRAY( pBin ) );
		return E_FAIL;
	}

	SafeArrayUnaccessData( V_ARRAY( pBin ) );
	SafeArrayDestroy( V_ARRAY( pBin ) );
	*pbHex = SysAllocString( pBuffer );
	LocalFree( pBuffer );
	return S_OK;
}
