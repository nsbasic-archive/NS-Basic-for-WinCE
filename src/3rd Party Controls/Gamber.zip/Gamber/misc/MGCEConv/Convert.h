// Convert.h : Declaration of the CConvert

#ifndef __CONVERT_H_
#define __CONVERT_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CConvert
class ATL_NO_VTABLE CConvert : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CConvert, &CLSID_Convert>,
	public IDispatchImpl<IConvert, &IID_IConvert, &LIBID_MGCECONVLib>
{
public:
	CConvert()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CONVERT)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CConvert)
	COM_INTERFACE_ENTRY(IConvert)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IConvert
public:
	STDMETHOD(BinaryToHex)(VARIANT *pBin, BSTR *pbHex);
};

#endif //__CONVERT_H_
