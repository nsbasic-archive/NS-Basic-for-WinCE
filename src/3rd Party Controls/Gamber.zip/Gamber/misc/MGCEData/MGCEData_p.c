/* this ALWAYS GENERATED file contains the proxy stub code */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed Oct 20 16:55:38 1999
 */
/* Compiler settings for MGCEData.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )

#define USE_STUBLESS_PROXY


/* verify that the <rpcproxy.h> version is high enough to compile this file*/
#ifndef __REDQ_RPCPROXY_H_VERSION__
#define __REQUIRED_RPCPROXY_H_VERSION__ 440
#endif


#include "rpcproxy.h"
#ifndef __RPCPROXY_H_VERSION__
#error this stub requires an updated version of <rpcproxy.h>
#endif // __RPCPROXY_H_VERSION__


#include "MGCEData.h"

#define TYPE_FORMAT_STRING_SIZE   837                               
#define PROC_FORMAT_STRING_SIZE   357                               

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;


/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IDispatch, ver. 0.0,
   GUID={0x00020400,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: ICollection, ver. 0.0,
   GUID={0x407076D1,0x86F8,0x11D3,{0x9C,0x5A,0x00,0x40,0x05,0x5A,0x16,0xDF}} */


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ICollection_ServerInfo;

#pragma code_seg(".orpc")
extern const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[1];

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    __MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0x20000, /* Ndr library version */
    0,
    0x50100a4, /* MIDL Version 5.1.164 */
    0,
    UserMarshalRoutines,
    0,  /* notify & notify_flag routine table */
    1,  /* Flags */
    0,  /* Reserved3 */
    0,  /* Reserved4 */
    0   /* Reserved5 */
    };

static const unsigned short ICollection_FormatStringOffsetTable[] = 
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0,
    34,
    68,
    96,
    124,
    158,
    192,
    214,
    248,
    282,
    328
    };

static const MIDL_SERVER_INFO ICollection_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ICollection_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO ICollection_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ICollection_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };

CINTERFACE_PROXY_VTABLE(18) _ICollectionProxyVtbl = 
{
    &ICollection_ProxyInfo,
    &IID_ICollection,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *)-1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *)-1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *)-1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *)-1 /* ICollection::get_Data */ ,
    (void *)-1 /* ICollection::put_Data */ ,
    (void *)-1 /* ICollection::get_Count */ ,
    (void *)-1 /* ICollection::get_AllKeys */ ,
    (void *)-1 /* ICollection::get_Name */ ,
    (void *)-1 /* ICollection::put_Name */ ,
    (void *)-1 /* ICollection::Sort */ ,
    (void *)-1 /* ICollection::get_TypeStart */ ,
    (void *)-1 /* ICollection::get_TypeLength */ ,
    (void *)-1 /* ICollection::Search */ ,
    (void *)-1 /* ICollection::get_Version */
};


static const PRPC_STUB_FUNCTION ICollection_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ICollectionStubVtbl =
{
    &IID_ICollection,
    &ICollection_ServerInfo,
    18,
    &ICollection_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};

#pragma data_seg(".rdata")

static const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[1] = 
        {
            
            {
            VARIANT_UserSize
            ,VARIANT_UserMarshal
            ,VARIANT_UserUnmarshal
            ,VARIANT_UserFree
            }

        };


#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

#if !(TARGET_IS_NT40_OR_LATER)
#error You need a Windows NT 4.0 or later to run this stub because it uses these features:
#error   -Oif or -Oicf, [wire_marshal] or [user_marshal] attribute.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will die there with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {

	/* Procedure get_Data */

			0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/*  2 */	NdrFcLong( 0x0 ),	/* 0 */
/*  6 */	NdrFcShort( 0x7 ),	/* 7 */
#ifndef _ALPHA_
/*  8 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 10 */	NdrFcShort( 0x0 ),	/* 0 */
/* 12 */	NdrFcShort( 0x8 ),	/* 8 */
/* 14 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter pvName */

/* 16 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
#ifndef _ALPHA_
/* 18 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 20 */	NdrFcShort( 0x324 ),	/* Type Offset=804 */

	/* Parameter pVal */

/* 22 */	NdrFcShort( 0x4113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=16 */
#ifndef _ALPHA_
/* 24 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 26 */	NdrFcShort( 0x336 ),	/* Type Offset=822 */

	/* Return value */

/* 28 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
#ifndef _ALPHA_
/* 30 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 32 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Data */

/* 34 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 36 */	NdrFcLong( 0x0 ),	/* 0 */
/* 40 */	NdrFcShort( 0x8 ),	/* 8 */
#ifndef _ALPHA_
/* 42 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 44 */	NdrFcShort( 0x0 ),	/* 0 */
/* 46 */	NdrFcShort( 0x8 ),	/* 8 */
/* 48 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter pvName */

/* 50 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
#ifndef _ALPHA_
/* 52 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 54 */	NdrFcShort( 0x324 ),	/* Type Offset=804 */

	/* Parameter newVal */

/* 56 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
#ifndef _ALPHA_
/* 58 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 60 */	NdrFcShort( 0x324 ),	/* Type Offset=804 */

	/* Return value */

/* 62 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
#ifndef _ALPHA_
/* 64 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 66 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Count */

/* 68 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 70 */	NdrFcLong( 0x0 ),	/* 0 */
/* 74 */	NdrFcShort( 0x9 ),	/* 9 */
#ifndef _ALPHA_
/* 76 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 78 */	NdrFcShort( 0x0 ),	/* 0 */
/* 80 */	NdrFcShort( 0x10 ),	/* 16 */
/* 82 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pVal */

/* 84 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
#ifndef _ALPHA_
/* 86 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 88 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 90 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
#ifndef _ALPHA_
/* 92 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 94 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_AllKeys */

/* 96 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 98 */	NdrFcLong( 0x0 ),	/* 0 */
/* 102 */	NdrFcShort( 0xa ),	/* 10 */
#ifndef _ALPHA_
/* 104 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 106 */	NdrFcShort( 0x0 ),	/* 0 */
/* 108 */	NdrFcShort( 0x8 ),	/* 8 */
/* 110 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter pVal */

/* 112 */	NdrFcShort( 0x4113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=16 */
#ifndef _ALPHA_
/* 114 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 116 */	NdrFcShort( 0x336 ),	/* Type Offset=822 */

	/* Return value */

/* 118 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
#ifndef _ALPHA_
/* 120 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 122 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Name */

/* 124 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 126 */	NdrFcLong( 0x0 ),	/* 0 */
/* 130 */	NdrFcShort( 0xb ),	/* 11 */
#ifndef _ALPHA_
/* 132 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 134 */	NdrFcShort( 0x8 ),	/* 8 */
/* 136 */	NdrFcShort( 0x8 ),	/* 8 */
/* 138 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x3,		/* 3 */

	/* Parameter lID */

/* 140 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
#ifndef _ALPHA_
/* 142 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 144 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pVal */

/* 146 */	NdrFcShort( 0x4113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=16 */
#ifndef _ALPHA_
/* 148 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 150 */	NdrFcShort( 0x336 ),	/* Type Offset=822 */

	/* Return value */

/* 152 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
#ifndef _ALPHA_
/* 154 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 156 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Name */

/* 158 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 160 */	NdrFcLong( 0x0 ),	/* 0 */
/* 164 */	NdrFcShort( 0xc ),	/* 12 */
#ifndef _ALPHA_
/* 166 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 168 */	NdrFcShort( 0x8 ),	/* 8 */
/* 170 */	NdrFcShort( 0x8 ),	/* 8 */
/* 172 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter lID */

/* 174 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
#ifndef _ALPHA_
/* 176 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 178 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter newVal */

/* 180 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
#ifndef _ALPHA_
/* 182 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 184 */	NdrFcShort( 0x324 ),	/* Type Offset=804 */

	/* Return value */

/* 186 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
#ifndef _ALPHA_
/* 188 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 190 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Sort */

/* 192 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 194 */	NdrFcLong( 0x0 ),	/* 0 */
/* 198 */	NdrFcShort( 0xd ),	/* 13 */
#ifndef _ALPHA_
/* 200 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 202 */	NdrFcShort( 0x0 ),	/* 0 */
/* 204 */	NdrFcShort( 0x8 ),	/* 8 */
/* 206 */	0x4,		/* Oi2 Flags:  has return, */
			0x1,		/* 1 */

	/* Return value */

/* 208 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
#ifndef _ALPHA_
/* 210 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 212 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_TypeStart */

/* 214 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 216 */	NdrFcLong( 0x0 ),	/* 0 */
/* 220 */	NdrFcShort( 0xe ),	/* 14 */
#ifndef _ALPHA_
/* 222 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 224 */	NdrFcShort( 0x8 ),	/* 8 */
/* 226 */	NdrFcShort( 0x10 ),	/* 16 */
/* 228 */	0x4,		/* Oi2 Flags:  has return, */
			0x3,		/* 3 */

	/* Parameter lType */

/* 230 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
#ifndef _ALPHA_
/* 232 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 234 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pVal */

/* 236 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
#ifndef _ALPHA_
/* 238 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 240 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 242 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
#ifndef _ALPHA_
/* 244 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 246 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_TypeLength */

/* 248 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 250 */	NdrFcLong( 0x0 ),	/* 0 */
/* 254 */	NdrFcShort( 0xf ),	/* 15 */
#ifndef _ALPHA_
/* 256 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 258 */	NdrFcShort( 0x8 ),	/* 8 */
/* 260 */	NdrFcShort( 0x10 ),	/* 16 */
/* 262 */	0x4,		/* Oi2 Flags:  has return, */
			0x3,		/* 3 */

	/* Parameter lType */

/* 264 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
#ifndef _ALPHA_
/* 266 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 268 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter pVal */

/* 270 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
#ifndef _ALPHA_
/* 272 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 274 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 276 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
#ifndef _ALPHA_
/* 278 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 280 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure Search */

/* 282 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 284 */	NdrFcLong( 0x0 ),	/* 0 */
/* 288 */	NdrFcShort( 0x10 ),	/* 16 */
#ifndef _ALPHA_
/* 290 */	NdrFcShort( 0x18 ),	/* x86, MIPS, PPC Stack size/offset = 24 */
#else
			NdrFcShort( 0x30 ),	/* Alpha Stack size/offset = 48 */
#endif
/* 292 */	NdrFcShort( 0x10 ),	/* 16 */
/* 294 */	NdrFcShort( 0x10 ),	/* 16 */
/* 296 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x5,		/* 5 */

	/* Parameter pvData */

/* 298 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
#ifndef _ALPHA_
/* 300 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 302 */	NdrFcShort( 0x324 ),	/* Type Offset=804 */

	/* Parameter lStart */

/* 304 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
#ifndef _ALPHA_
/* 306 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 308 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter lType */

/* 310 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
#ifndef _ALPHA_
/* 312 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 314 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter lPos */

/* 316 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
#ifndef _ALPHA_
/* 318 */	NdrFcShort( 0x10 ),	/* x86, MIPS, PPC Stack size/offset = 16 */
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 320 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 322 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
#ifndef _ALPHA_
/* 324 */	NdrFcShort( 0x14 ),	/* x86, MIPS, PPC Stack size/offset = 20 */
#else
			NdrFcShort( 0x28 ),	/* Alpha Stack size/offset = 40 */
#endif
/* 326 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Version */

/* 328 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 330 */	NdrFcLong( 0x0 ),	/* 0 */
/* 334 */	NdrFcShort( 0x11 ),	/* 17 */
#ifndef _ALPHA_
/* 336 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 338 */	NdrFcShort( 0x0 ),	/* 0 */
/* 340 */	NdrFcShort( 0x10 ),	/* 16 */
/* 342 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pVal */

/* 344 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
#ifndef _ALPHA_
/* 346 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 348 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 350 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
#ifndef _ALPHA_
/* 352 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 354 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */
/*  2 */	
			0x11, 0x0,	/* FC_RP */
/*  4 */	NdrFcShort( 0x320 ),	/* Offset= 800 (804) */
/*  6 */	
			0x12, 0x0,	/* FC_UP */
/*  8 */	NdrFcShort( 0x308 ),	/* Offset= 776 (784) */
/* 10 */	
			0x2b,		/* FC_NON_ENCAPSULATED_UNION */
			0x7,		/* FC_USHORT */
/* 12 */	0x7,		/* Corr desc: FC_USHORT */
			0x0,		/*  */
/* 14 */	NdrFcShort( 0xfff8 ),	/* -8 */
/* 16 */	NdrFcShort( 0x2 ),	/* Offset= 2 (18) */
/* 18 */	NdrFcShort( 0x10 ),	/* 16 */
/* 20 */	NdrFcShort( 0x29 ),	/* 41 */
/* 22 */	NdrFcLong( 0x3 ),	/* 3 */
/* 26 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 28 */	NdrFcLong( 0x11 ),	/* 17 */
/* 32 */	NdrFcShort( 0x8002 ),	/* Simple arm type: FC_CHAR */
/* 34 */	NdrFcLong( 0x2 ),	/* 2 */
/* 38 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 40 */	NdrFcLong( 0x4 ),	/* 4 */
/* 44 */	NdrFcShort( 0x800a ),	/* Simple arm type: FC_FLOAT */
/* 46 */	NdrFcLong( 0x5 ),	/* 5 */
/* 50 */	NdrFcShort( 0x800c ),	/* Simple arm type: FC_DOUBLE */
/* 52 */	NdrFcLong( 0xb ),	/* 11 */
/* 56 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 58 */	NdrFcLong( 0xa ),	/* 10 */
/* 62 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 64 */	NdrFcLong( 0x6 ),	/* 6 */
/* 68 */	NdrFcShort( 0xca ),	/* Offset= 202 (270) */
/* 70 */	NdrFcLong( 0x7 ),	/* 7 */
/* 74 */	NdrFcShort( 0x800c ),	/* Simple arm type: FC_DOUBLE */
/* 76 */	NdrFcLong( 0x8 ),	/* 8 */
/* 80 */	NdrFcShort( 0xc4 ),	/* Offset= 196 (276) */
/* 82 */	NdrFcLong( 0xd ),	/* 13 */
/* 86 */	NdrFcShort( 0xd6 ),	/* Offset= 214 (300) */
/* 88 */	NdrFcLong( 0x9 ),	/* 9 */
/* 92 */	NdrFcShort( 0xe2 ),	/* Offset= 226 (318) */
/* 94 */	NdrFcLong( 0x2000 ),	/* 8192 */
/* 98 */	NdrFcShort( 0xee ),	/* Offset= 238 (336) */
/* 100 */	NdrFcLong( 0x4011 ),	/* 16401 */
/* 104 */	NdrFcShort( 0x268 ),	/* Offset= 616 (720) */
/* 106 */	NdrFcLong( 0x4002 ),	/* 16386 */
/* 110 */	NdrFcShort( 0x266 ),	/* Offset= 614 (724) */
/* 112 */	NdrFcLong( 0x4003 ),	/* 16387 */
/* 116 */	NdrFcShort( 0x264 ),	/* Offset= 612 (728) */
/* 118 */	NdrFcLong( 0x4004 ),	/* 16388 */
/* 122 */	NdrFcShort( 0x262 ),	/* Offset= 610 (732) */
/* 124 */	NdrFcLong( 0x4005 ),	/* 16389 */
/* 128 */	NdrFcShort( 0x260 ),	/* Offset= 608 (736) */
/* 130 */	NdrFcLong( 0x400b ),	/* 16395 */
/* 134 */	NdrFcShort( 0x24e ),	/* Offset= 590 (724) */
/* 136 */	NdrFcLong( 0x400a ),	/* 16394 */
/* 140 */	NdrFcShort( 0x24c ),	/* Offset= 588 (728) */
/* 142 */	NdrFcLong( 0x4006 ),	/* 16390 */
/* 146 */	NdrFcShort( 0x252 ),	/* Offset= 594 (740) */
/* 148 */	NdrFcLong( 0x4007 ),	/* 16391 */
/* 152 */	NdrFcShort( 0x248 ),	/* Offset= 584 (736) */
/* 154 */	NdrFcLong( 0x4008 ),	/* 16392 */
/* 158 */	NdrFcShort( 0x24a ),	/* Offset= 586 (744) */
/* 160 */	NdrFcLong( 0x400d ),	/* 16397 */
/* 164 */	NdrFcShort( 0x248 ),	/* Offset= 584 (748) */
/* 166 */	NdrFcLong( 0x4009 ),	/* 16393 */
/* 170 */	NdrFcShort( 0x246 ),	/* Offset= 582 (752) */
/* 172 */	NdrFcLong( 0x6000 ),	/* 24576 */
/* 176 */	NdrFcShort( 0x244 ),	/* Offset= 580 (756) */
/* 178 */	NdrFcLong( 0x400c ),	/* 16396 */
/* 182 */	NdrFcShort( 0x242 ),	/* Offset= 578 (760) */
/* 184 */	NdrFcLong( 0x10 ),	/* 16 */
/* 188 */	NdrFcShort( 0x8002 ),	/* Simple arm type: FC_CHAR */
/* 190 */	NdrFcLong( 0x12 ),	/* 18 */
/* 194 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 196 */	NdrFcLong( 0x13 ),	/* 19 */
/* 200 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 202 */	NdrFcLong( 0x16 ),	/* 22 */
/* 206 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 208 */	NdrFcLong( 0x17 ),	/* 23 */
/* 212 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 214 */	NdrFcLong( 0xe ),	/* 14 */
/* 218 */	NdrFcShort( 0x226 ),	/* Offset= 550 (768) */
/* 220 */	NdrFcLong( 0x400e ),	/* 16398 */
/* 224 */	NdrFcShort( 0x22c ),	/* Offset= 556 (780) */
/* 226 */	NdrFcLong( 0x4010 ),	/* 16400 */
/* 230 */	NdrFcShort( 0x1ea ),	/* Offset= 490 (720) */
/* 232 */	NdrFcLong( 0x4012 ),	/* 16402 */
/* 236 */	NdrFcShort( 0x1e8 ),	/* Offset= 488 (724) */
/* 238 */	NdrFcLong( 0x4013 ),	/* 16403 */
/* 242 */	NdrFcShort( 0x1e6 ),	/* Offset= 486 (728) */
/* 244 */	NdrFcLong( 0x4016 ),	/* 16406 */
/* 248 */	NdrFcShort( 0x1e0 ),	/* Offset= 480 (728) */
/* 250 */	NdrFcLong( 0x4017 ),	/* 16407 */
/* 254 */	NdrFcShort( 0x1da ),	/* Offset= 474 (728) */
/* 256 */	NdrFcLong( 0x0 ),	/* 0 */
/* 260 */	NdrFcShort( 0x0 ),	/* Offset= 0 (260) */
/* 262 */	NdrFcLong( 0x1 ),	/* 1 */
/* 266 */	NdrFcShort( 0x0 ),	/* Offset= 0 (266) */
/* 268 */	NdrFcShort( 0xffffffff ),	/* Offset= -1 (267) */
/* 270 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 272 */	NdrFcShort( 0x8 ),	/* 8 */
/* 274 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 276 */	
			0x12, 0x0,	/* FC_UP */
/* 278 */	NdrFcShort( 0xc ),	/* Offset= 12 (290) */
/* 280 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 282 */	NdrFcShort( 0x2 ),	/* 2 */
/* 284 */	0x9,		/* Corr desc: FC_ULONG */
			0x0,		/*  */
/* 286 */	NdrFcShort( 0xfffc ),	/* -4 */
/* 288 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 290 */	
			0x17,		/* FC_CSTRUCT */
			0x3,		/* 3 */
/* 292 */	NdrFcShort( 0x8 ),	/* 8 */
/* 294 */	NdrFcShort( 0xfffffff2 ),	/* Offset= -14 (280) */
/* 296 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 298 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 300 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 302 */	NdrFcLong( 0x0 ),	/* 0 */
/* 306 */	NdrFcShort( 0x0 ),	/* 0 */
/* 308 */	NdrFcShort( 0x0 ),	/* 0 */
/* 310 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 312 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 314 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 316 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 318 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 320 */	NdrFcLong( 0x20400 ),	/* 132096 */
/* 324 */	NdrFcShort( 0x0 ),	/* 0 */
/* 326 */	NdrFcShort( 0x0 ),	/* 0 */
/* 328 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 330 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 332 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 334 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 336 */	
			0x12, 0x0,	/* FC_UP */
/* 338 */	NdrFcShort( 0x16c ),	/* Offset= 364 (702) */
/* 340 */	
			0x2a,		/* FC_ENCAPSULATED_UNION */
			0x49,		/* 73 */
/* 342 */	NdrFcShort( 0x8 ),	/* 8 */
/* 344 */	NdrFcShort( 0x8 ),	/* 8 */
/* 346 */	NdrFcLong( 0x8 ),	/* 8 */
/* 350 */	NdrFcShort( 0x4c ),	/* Offset= 76 (426) */
/* 352 */	NdrFcLong( 0xd ),	/* 13 */
/* 356 */	NdrFcShort( 0x6c ),	/* Offset= 108 (464) */
/* 358 */	NdrFcLong( 0x9 ),	/* 9 */
/* 362 */	NdrFcShort( 0x88 ),	/* Offset= 136 (498) */
/* 364 */	NdrFcLong( 0xc ),	/* 12 */
/* 368 */	NdrFcShort( 0xb0 ),	/* Offset= 176 (544) */
/* 370 */	NdrFcLong( 0x10 ),	/* 16 */
/* 374 */	NdrFcShort( 0xc4 ),	/* Offset= 196 (570) */
/* 376 */	NdrFcLong( 0x2 ),	/* 2 */
/* 380 */	NdrFcShort( 0xdc ),	/* Offset= 220 (600) */
/* 382 */	NdrFcLong( 0x3 ),	/* 3 */
/* 386 */	NdrFcShort( 0xf4 ),	/* Offset= 244 (630) */
/* 388 */	NdrFcLong( 0x14 ),	/* 20 */
/* 392 */	NdrFcShort( 0x10c ),	/* Offset= 268 (660) */
/* 394 */	NdrFcShort( 0x0 ),	/* Offset= 0 (394) */
/* 396 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 398 */	NdrFcShort( 0x4 ),	/* 4 */
/* 400 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 402 */	NdrFcShort( 0x0 ),	/* 0 */
/* 404 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 406 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 408 */	NdrFcShort( 0x4 ),	/* 4 */
/* 410 */	NdrFcShort( 0x0 ),	/* 0 */
/* 412 */	NdrFcShort( 0x1 ),	/* 1 */
/* 414 */	NdrFcShort( 0x0 ),	/* 0 */
/* 416 */	NdrFcShort( 0x0 ),	/* 0 */
/* 418 */	0x12, 0x0,	/* FC_UP */
/* 420 */	NdrFcShort( 0xffffff7e ),	/* Offset= -130 (290) */
/* 422 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 424 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 426 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 428 */	NdrFcShort( 0x8 ),	/* 8 */
/* 430 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 432 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 434 */	NdrFcShort( 0x4 ),	/* 4 */
/* 436 */	NdrFcShort( 0x4 ),	/* 4 */
/* 438 */	0x11, 0x0,	/* FC_RP */
/* 440 */	NdrFcShort( 0xffffffd4 ),	/* Offset= -44 (396) */
/* 442 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 444 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 446 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 448 */	NdrFcShort( 0x0 ),	/* 0 */
/* 450 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 452 */	NdrFcShort( 0x0 ),	/* 0 */
/* 454 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 458 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 460 */	NdrFcShort( 0xffffff60 ),	/* Offset= -160 (300) */
/* 462 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 464 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 466 */	NdrFcShort( 0x8 ),	/* 8 */
/* 468 */	NdrFcShort( 0x0 ),	/* 0 */
/* 470 */	NdrFcShort( 0x6 ),	/* Offset= 6 (476) */
/* 472 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 474 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 476 */	
			0x11, 0x0,	/* FC_RP */
/* 478 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (446) */
/* 480 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 482 */	NdrFcShort( 0x0 ),	/* 0 */
/* 484 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 486 */	NdrFcShort( 0x0 ),	/* 0 */
/* 488 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 492 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 494 */	NdrFcShort( 0xffffff50 ),	/* Offset= -176 (318) */
/* 496 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 498 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 500 */	NdrFcShort( 0x8 ),	/* 8 */
/* 502 */	NdrFcShort( 0x0 ),	/* 0 */
/* 504 */	NdrFcShort( 0x6 ),	/* Offset= 6 (510) */
/* 506 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 508 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 510 */	
			0x11, 0x0,	/* FC_RP */
/* 512 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (480) */
/* 514 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 516 */	NdrFcShort( 0x4 ),	/* 4 */
/* 518 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 520 */	NdrFcShort( 0x0 ),	/* 0 */
/* 522 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 524 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 526 */	NdrFcShort( 0x4 ),	/* 4 */
/* 528 */	NdrFcShort( 0x0 ),	/* 0 */
/* 530 */	NdrFcShort( 0x1 ),	/* 1 */
/* 532 */	NdrFcShort( 0x0 ),	/* 0 */
/* 534 */	NdrFcShort( 0x0 ),	/* 0 */
/* 536 */	0x12, 0x0,	/* FC_UP */
/* 538 */	NdrFcShort( 0xf6 ),	/* Offset= 246 (784) */
/* 540 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 542 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 544 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 546 */	NdrFcShort( 0x8 ),	/* 8 */
/* 548 */	NdrFcShort( 0x0 ),	/* 0 */
/* 550 */	NdrFcShort( 0x6 ),	/* Offset= 6 (556) */
/* 552 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 554 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 556 */	
			0x11, 0x0,	/* FC_RP */
/* 558 */	NdrFcShort( 0xffffffd4 ),	/* Offset= -44 (514) */
/* 560 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 562 */	NdrFcShort( 0x1 ),	/* 1 */
/* 564 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 566 */	NdrFcShort( 0x0 ),	/* 0 */
/* 568 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 570 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 572 */	NdrFcShort( 0x8 ),	/* 8 */
/* 574 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 576 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 578 */	NdrFcShort( 0x4 ),	/* 4 */
/* 580 */	NdrFcShort( 0x4 ),	/* 4 */
/* 582 */	0x12, 0x0,	/* FC_UP */
/* 584 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (560) */
/* 586 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 588 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 590 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 592 */	NdrFcShort( 0x2 ),	/* 2 */
/* 594 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 596 */	NdrFcShort( 0x0 ),	/* 0 */
/* 598 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 600 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 602 */	NdrFcShort( 0x8 ),	/* 8 */
/* 604 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 606 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 608 */	NdrFcShort( 0x4 ),	/* 4 */
/* 610 */	NdrFcShort( 0x4 ),	/* 4 */
/* 612 */	0x12, 0x0,	/* FC_UP */
/* 614 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (590) */
/* 616 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 618 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 620 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 622 */	NdrFcShort( 0x4 ),	/* 4 */
/* 624 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 626 */	NdrFcShort( 0x0 ),	/* 0 */
/* 628 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 630 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 632 */	NdrFcShort( 0x8 ),	/* 8 */
/* 634 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 636 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 638 */	NdrFcShort( 0x4 ),	/* 4 */
/* 640 */	NdrFcShort( 0x4 ),	/* 4 */
/* 642 */	0x12, 0x0,	/* FC_UP */
/* 644 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (620) */
/* 646 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 648 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 650 */	
			0x1b,		/* FC_CARRAY */
			0x7,		/* 7 */
/* 652 */	NdrFcShort( 0x8 ),	/* 8 */
/* 654 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 656 */	NdrFcShort( 0x0 ),	/* 0 */
/* 658 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 660 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 662 */	NdrFcShort( 0x8 ),	/* 8 */
/* 664 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 666 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 668 */	NdrFcShort( 0x4 ),	/* 4 */
/* 670 */	NdrFcShort( 0x4 ),	/* 4 */
/* 672 */	0x12, 0x0,	/* FC_UP */
/* 674 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (650) */
/* 676 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 678 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 680 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 682 */	NdrFcShort( 0x8 ),	/* 8 */
/* 684 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 686 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 688 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 690 */	NdrFcShort( 0x8 ),	/* 8 */
/* 692 */	0x7,		/* Corr desc: FC_USHORT */
			0x0,		/*  */
/* 694 */	NdrFcShort( 0xffe8 ),	/* -24 */
/* 696 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 698 */	NdrFcShort( 0xffffffee ),	/* Offset= -18 (680) */
/* 700 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 702 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 704 */	NdrFcShort( 0x18 ),	/* 24 */
/* 706 */	NdrFcShort( 0xffffffee ),	/* Offset= -18 (688) */
/* 708 */	NdrFcShort( 0x0 ),	/* Offset= 0 (708) */
/* 710 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 712 */	0x38,		/* FC_ALIGNM4 */
			0x8,		/* FC_LONG */
/* 714 */	0x8,		/* FC_LONG */
			0x4c,		/* FC_EMBEDDED_COMPLEX */
/* 716 */	0x0,		/* 0 */
			NdrFcShort( 0xfffffe87 ),	/* Offset= -377 (340) */
			0x5b,		/* FC_END */
/* 720 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 722 */	0x2,		/* FC_CHAR */
			0x5c,		/* FC_PAD */
/* 724 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 726 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */
/* 728 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 730 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 732 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 734 */	0xa,		/* FC_FLOAT */
			0x5c,		/* FC_PAD */
/* 736 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 738 */	0xc,		/* FC_DOUBLE */
			0x5c,		/* FC_PAD */
/* 740 */	
			0x12, 0x0,	/* FC_UP */
/* 742 */	NdrFcShort( 0xfffffe28 ),	/* Offset= -472 (270) */
/* 744 */	
			0x12, 0x10,	/* FC_UP */
/* 746 */	NdrFcShort( 0xfffffe2a ),	/* Offset= -470 (276) */
/* 748 */	
			0x12, 0x10,	/* FC_UP */
/* 750 */	NdrFcShort( 0xfffffe3e ),	/* Offset= -450 (300) */
/* 752 */	
			0x12, 0x10,	/* FC_UP */
/* 754 */	NdrFcShort( 0xfffffe4c ),	/* Offset= -436 (318) */
/* 756 */	
			0x12, 0x10,	/* FC_UP */
/* 758 */	NdrFcShort( 0xfffffe5a ),	/* Offset= -422 (336) */
/* 760 */	
			0x12, 0x10,	/* FC_UP */
/* 762 */	NdrFcShort( 0x2 ),	/* Offset= 2 (764) */
/* 764 */	
			0x12, 0x0,	/* FC_UP */
/* 766 */	NdrFcShort( 0xfffffd02 ),	/* Offset= -766 (0) */
/* 768 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 770 */	NdrFcShort( 0x10 ),	/* 16 */
/* 772 */	0x6,		/* FC_SHORT */
			0x2,		/* FC_CHAR */
/* 774 */	0x2,		/* FC_CHAR */
			0x38,		/* FC_ALIGNM4 */
/* 776 */	0x8,		/* FC_LONG */
			0x39,		/* FC_ALIGNM8 */
/* 778 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 780 */	
			0x12, 0x0,	/* FC_UP */
/* 782 */	NdrFcShort( 0xfffffff2 ),	/* Offset= -14 (768) */
/* 784 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x7,		/* 7 */
/* 786 */	NdrFcShort( 0x20 ),	/* 32 */
/* 788 */	NdrFcShort( 0x0 ),	/* 0 */
/* 790 */	NdrFcShort( 0x0 ),	/* Offset= 0 (790) */
/* 792 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 794 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 796 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 798 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 800 */	NdrFcShort( 0xfffffcea ),	/* Offset= -790 (10) */
/* 802 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 804 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 806 */	NdrFcShort( 0x0 ),	/* 0 */
/* 808 */	NdrFcShort( 0x10 ),	/* 16 */
/* 810 */	NdrFcShort( 0x0 ),	/* 0 */
/* 812 */	NdrFcShort( 0xfffffcda ),	/* Offset= -806 (6) */
/* 814 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 816 */	NdrFcShort( 0x6 ),	/* Offset= 6 (822) */
/* 818 */	
			0x13, 0x0,	/* FC_OP */
/* 820 */	NdrFcShort( 0xffffffdc ),	/* Offset= -36 (784) */
/* 822 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 824 */	NdrFcShort( 0x0 ),	/* 0 */
/* 826 */	NdrFcShort( 0x10 ),	/* 16 */
/* 828 */	NdrFcShort( 0x0 ),	/* 0 */
/* 830 */	NdrFcShort( 0xfffffff4 ),	/* Offset= -12 (818) */
/* 832 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/* 834 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */

			0x0
        }
    };

const CInterfaceProxyVtbl * _MGCEData_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_ICollectionProxyVtbl,
    0
};

const CInterfaceStubVtbl * _MGCEData_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_ICollectionStubVtbl,
    0
};

PCInterfaceName const _MGCEData_InterfaceNamesList[] = 
{
    "ICollection",
    0
};

const IID *  _MGCEData_BaseIIDList[] = 
{
    &IID_IDispatch,
    0
};


#define _MGCEData_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _MGCEData, pIID, n)

int __stdcall _MGCEData_IID_Lookup( const IID * pIID, int * pIndex )
{
    
    if(!_MGCEData_CHECK_IID(0))
        {
        *pIndex = 0;
        return 1;
        }

    return 0;
}

const ExtendedProxyFileInfo MGCEData_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _MGCEData_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _MGCEData_StubVtblList,
    (const PCInterfaceName * ) & _MGCEData_InterfaceNamesList,
    (const IID ** ) & _MGCEData_BaseIIDList,
    & _MGCEData_IID_Lookup, 
    1,
    2,
    0, /* table of [async_uuid] interfaces */
    0, /* Filler1 */
    0, /* Filler2 */
    0  /* Filler3 */
};
