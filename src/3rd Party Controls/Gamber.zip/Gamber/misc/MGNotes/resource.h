//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MGNotes.rc
//
#define IDC_ALL                         3
#define IDC_HELP                        3
#define IDI_TRAYICON                    102
#define IDR_MAINMENU                    103
#define IDD_NOTENAME                    104
#define IDD_CLOSEDLG                    105
#define IDD_ABOUT                       106
#define IDD_SELECTNOTE                  107
#define IDD_FONTS                       108
#define IDD_FINDTEXT                    109
#define IDD_COLORDLG                    110
#define IDD_IMPEXPORT                   112
#define IDD_SPLASH                      113
#define IDC_NAMEEDIT                    1000
#define IDC_NOTELIST                    1001
#define IDC_SELECTLIST                  1002
#define IDC_FONTLIST                    1003
#define IDC_FONTSIZE                    1004
#define IDC_TEXTCOLOR                   1005
#define IDC_BOLDFONT                    1006
#define IDC_XSIZE                       1007
#define IDC_YSIZE                       1008
#define IDC_BKCOLOR                     1009
#define IDC_TEXTCOLOR2                  1009
#define IDC_FIND                        1010
#define IDC_CASE                        1011
#define IDC_HIDE                        1012
#define IDC_CONFIRM                     1015
#define IDC_DOIMPORT                    1016
#define IDC_FILENAME                    1018
#define IDC_DOEXPORT                    1019
#define IDC_BROWSE                      1020
#define IDC_NOTELIST2                   1021
#define IDC_FILEDIR                     1022
#define ID_OPEN                         40007
#define ID_SAVE                         40008
#define ID_CLOSE                        40009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40010
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
