//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ObjBrowse.rc
//
#define IDI_ICON1                       102
#define IDI_ICON2                       103
#define IDI_ICON3                       104
#define IDI_ICON4                       105
#define IDI_ICON5                       107
#define IDI_ICON6                       108
#define IDI_ICON7                       109
#define IDI_ICON8                       110
#define IDI_ICON9                       111
#define IDI_ICON10                      112
#define IDI_ICON11                      113
#define IDI_ICON12                      114

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
