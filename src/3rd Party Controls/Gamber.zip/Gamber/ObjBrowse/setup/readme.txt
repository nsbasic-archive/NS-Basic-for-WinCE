
Welcome to Object Browser setup! The Object Browser displays COM objects on a Windows CE device including their public interfaces, methods, properties and variables.


Windows CE is (c) Microsoft Corporation.
Object Browser by Mark Gamber, September 1999
