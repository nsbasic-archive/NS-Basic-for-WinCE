/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sat Nov 06 14:58:49 1999
 */
/* Compiler settings for MGCETreeView.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __MGCETreeView_h__
#define __MGCETreeView_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ITreeView_FWD_DEFINED__
#define __ITreeView_FWD_DEFINED__
typedef interface ITreeView ITreeView;
#endif 	/* __ITreeView_FWD_DEFINED__ */


#ifndef ___ITreeViewEvents_FWD_DEFINED__
#define ___ITreeViewEvents_FWD_DEFINED__
typedef interface _ITreeViewEvents _ITreeViewEvents;
#endif 	/* ___ITreeViewEvents_FWD_DEFINED__ */


#ifndef __TreeView_FWD_DEFINED__
#define __TreeView_FWD_DEFINED__

#ifdef __cplusplus
typedef class TreeView TreeView;
#else
typedef struct TreeView TreeView;
#endif /* __cplusplus */

#endif 	/* __TreeView_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ITreeView_INTERFACE_DEFINED__
#define __ITreeView_INTERFACE_DEFINED__

/* interface ITreeView */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITreeView;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("7CCCDEEF-6B04-11D3-99B4-0040055A16DF")
    ITreeView : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddImage( 
            BSTR bFilename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RemoveImage( 
            long lIndex) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_UseImages( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_UseImages( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_UseSelectedImages( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_UseSelectedImages( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddItem( 
            /* [optional][in] */ long lParent,
            /* [optional][in] */ long lInsertAfter,
            /* [in] */ BSTR bText,
            /* [optional][in] */ long lParam,
            /* [optional][in] */ long lImage,
            /* [optional][in] */ long lSelectedImage,
            /* [retval][out] */ long __RPC_FAR *pRet) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_HasLines( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_HasLines( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_HasButtons( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_HasButtons( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Border( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Border( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Clear( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteItem( 
            long lItem) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_RootLines( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_RootLines( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ExpandItem( 
            long lItem) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CollapseItem( 
            long lItem) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ToggleItem( 
            long lItem) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MakeVisible( 
            long lItem) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FirstItem( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ItemText( 
            long lItem,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ItemText( 
            long lItem,
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ItemImage( 
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ItemImage( 
            long lItem,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ItemSelectedImage( 
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ItemSelectedImage( 
            long lItem,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ItemValue( 
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ItemValue( 
            long lItem,
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Indent( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Indent( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Child( 
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Parent( 
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_NextSibling( 
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_PreviousSibling( 
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_NextVisible( 
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_PreviousVisible( 
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FirstVisible( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FirstVisible( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Select( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Select( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_AllowEdit( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_AllowEdit( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Tabstop( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Tabstop( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetFocus( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Show( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Hide( void) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_AllowEvent( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_AllowEventAsDefault( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_AllowEventAsDefault( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectionDisplay( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectionDisplay( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_AutoExpand( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_AutoExpand( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TreePath( 
            long lItem,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE StartEdit( 
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pEdit) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE EndEdit( 
            /* [optional][in] */ long lDeny) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontName( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontSize( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontSize( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_FontBold( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_FontBold( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddContextItem( 
            BSTR bText) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RemoveContextItem( 
            long lIndex) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ClearContext( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Style( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Style( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Version( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_hWnd( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITreeViewVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITreeView __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITreeView __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ITreeView __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddImage )( 
            ITreeView __RPC_FAR * This,
            BSTR bFilename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RemoveImage )( 
            ITreeView __RPC_FAR * This,
            long lIndex);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_UseImages )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_UseImages )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_UseSelectedImages )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_UseSelectedImages )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddItem )( 
            ITreeView __RPC_FAR * This,
            /* [optional][in] */ long lParent,
            /* [optional][in] */ long lInsertAfter,
            /* [in] */ BSTR bText,
            /* [optional][in] */ long lParam,
            /* [optional][in] */ long lImage,
            /* [optional][in] */ long lSelectedImage,
            /* [retval][out] */ long __RPC_FAR *pRet);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_HasLines )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_HasLines )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_HasButtons )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_HasButtons )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Border )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Border )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clear )( 
            ITreeView __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Count )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteItem )( 
            ITreeView __RPC_FAR * This,
            long lItem);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_RootLines )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_RootLines )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ExpandItem )( 
            ITreeView __RPC_FAR * This,
            long lItem);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CollapseItem )( 
            ITreeView __RPC_FAR * This,
            long lItem);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ToggleItem )( 
            ITreeView __RPC_FAR * This,
            long lItem);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MakeVisible )( 
            ITreeView __RPC_FAR * This,
            long lItem);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FirstItem )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ItemText )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ItemText )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ItemImage )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ItemImage )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ItemSelectedImage )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ItemSelectedImage )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ItemValue )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ItemValue )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Indent )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Indent )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Child )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Parent )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_NextSibling )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PreviousSibling )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_NextVisible )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PreviousVisible )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FirstVisible )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FirstVisible )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Select )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Select )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AllowEdit )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_AllowEdit )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Tabstop )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Tabstop )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFocus )( 
            ITreeView __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Show )( 
            ITreeView __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Hide )( 
            ITreeView __RPC_FAR * This);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_AllowEvent )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AllowEventAsDefault )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_AllowEventAsDefault )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SelectionDisplay )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SelectionDisplay )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AutoExpand )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_AutoExpand )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TreePath )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *StartEdit )( 
            ITreeView __RPC_FAR * This,
            long lItem,
            /* [retval][out] */ long __RPC_FAR *pEdit);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *EndEdit )( 
            ITreeView __RPC_FAR * This,
            /* [optional][in] */ long lDeny);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontName )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontName )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontSize )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontSize )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontBold )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontBold )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddContextItem )( 
            ITreeView __RPC_FAR * This,
            BSTR bText);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RemoveContextItem )( 
            ITreeView __RPC_FAR * This,
            long lIndex);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ClearContext )( 
            ITreeView __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Style )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Style )( 
            ITreeView __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Version )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_hWnd )( 
            ITreeView __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        END_INTERFACE
    } ITreeViewVtbl;

    interface ITreeView
    {
        CONST_VTBL struct ITreeViewVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITreeView_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITreeView_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITreeView_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITreeView_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITreeView_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITreeView_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITreeView_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITreeView_AddImage(This,bFilename)	\
    (This)->lpVtbl -> AddImage(This,bFilename)

#define ITreeView_RemoveImage(This,lIndex)	\
    (This)->lpVtbl -> RemoveImage(This,lIndex)

#define ITreeView_get_UseImages(This,pVal)	\
    (This)->lpVtbl -> get_UseImages(This,pVal)

#define ITreeView_put_UseImages(This,newVal)	\
    (This)->lpVtbl -> put_UseImages(This,newVal)

#define ITreeView_get_UseSelectedImages(This,pVal)	\
    (This)->lpVtbl -> get_UseSelectedImages(This,pVal)

#define ITreeView_put_UseSelectedImages(This,newVal)	\
    (This)->lpVtbl -> put_UseSelectedImages(This,newVal)

#define ITreeView_AddItem(This,lParent,lInsertAfter,bText,lParam,lImage,lSelectedImage,pRet)	\
    (This)->lpVtbl -> AddItem(This,lParent,lInsertAfter,bText,lParam,lImage,lSelectedImage,pRet)

#define ITreeView_get_HasLines(This,pVal)	\
    (This)->lpVtbl -> get_HasLines(This,pVal)

#define ITreeView_put_HasLines(This,newVal)	\
    (This)->lpVtbl -> put_HasLines(This,newVal)

#define ITreeView_get_HasButtons(This,pVal)	\
    (This)->lpVtbl -> get_HasButtons(This,pVal)

#define ITreeView_put_HasButtons(This,newVal)	\
    (This)->lpVtbl -> put_HasButtons(This,newVal)

#define ITreeView_get_Border(This,pVal)	\
    (This)->lpVtbl -> get_Border(This,pVal)

#define ITreeView_put_Border(This,newVal)	\
    (This)->lpVtbl -> put_Border(This,newVal)

#define ITreeView_Clear(This)	\
    (This)->lpVtbl -> Clear(This)

#define ITreeView_get_Count(This,pVal)	\
    (This)->lpVtbl -> get_Count(This,pVal)

#define ITreeView_DeleteItem(This,lItem)	\
    (This)->lpVtbl -> DeleteItem(This,lItem)

#define ITreeView_get_RootLines(This,pVal)	\
    (This)->lpVtbl -> get_RootLines(This,pVal)

#define ITreeView_put_RootLines(This,newVal)	\
    (This)->lpVtbl -> put_RootLines(This,newVal)

#define ITreeView_ExpandItem(This,lItem)	\
    (This)->lpVtbl -> ExpandItem(This,lItem)

#define ITreeView_CollapseItem(This,lItem)	\
    (This)->lpVtbl -> CollapseItem(This,lItem)

#define ITreeView_ToggleItem(This,lItem)	\
    (This)->lpVtbl -> ToggleItem(This,lItem)

#define ITreeView_MakeVisible(This,lItem)	\
    (This)->lpVtbl -> MakeVisible(This,lItem)

#define ITreeView_get_FirstItem(This,pVal)	\
    (This)->lpVtbl -> get_FirstItem(This,pVal)

#define ITreeView_get_ItemText(This,lItem,pVal)	\
    (This)->lpVtbl -> get_ItemText(This,lItem,pVal)

#define ITreeView_put_ItemText(This,lItem,newVal)	\
    (This)->lpVtbl -> put_ItemText(This,lItem,newVal)

#define ITreeView_get_ItemImage(This,lItem,pVal)	\
    (This)->lpVtbl -> get_ItemImage(This,lItem,pVal)

#define ITreeView_put_ItemImage(This,lItem,newVal)	\
    (This)->lpVtbl -> put_ItemImage(This,lItem,newVal)

#define ITreeView_get_ItemSelectedImage(This,lItem,pVal)	\
    (This)->lpVtbl -> get_ItemSelectedImage(This,lItem,pVal)

#define ITreeView_put_ItemSelectedImage(This,lItem,newVal)	\
    (This)->lpVtbl -> put_ItemSelectedImage(This,lItem,newVal)

#define ITreeView_get_ItemValue(This,lItem,pVal)	\
    (This)->lpVtbl -> get_ItemValue(This,lItem,pVal)

#define ITreeView_put_ItemValue(This,lItem,newVal)	\
    (This)->lpVtbl -> put_ItemValue(This,lItem,newVal)

#define ITreeView_get_Indent(This,pVal)	\
    (This)->lpVtbl -> get_Indent(This,pVal)

#define ITreeView_put_Indent(This,newVal)	\
    (This)->lpVtbl -> put_Indent(This,newVal)

#define ITreeView_get_Child(This,lItem,pVal)	\
    (This)->lpVtbl -> get_Child(This,lItem,pVal)

#define ITreeView_get_Parent(This,lItem,pVal)	\
    (This)->lpVtbl -> get_Parent(This,lItem,pVal)

#define ITreeView_get_NextSibling(This,lItem,pVal)	\
    (This)->lpVtbl -> get_NextSibling(This,lItem,pVal)

#define ITreeView_get_PreviousSibling(This,lItem,pVal)	\
    (This)->lpVtbl -> get_PreviousSibling(This,lItem,pVal)

#define ITreeView_get_NextVisible(This,lItem,pVal)	\
    (This)->lpVtbl -> get_NextVisible(This,lItem,pVal)

#define ITreeView_get_PreviousVisible(This,lItem,pVal)	\
    (This)->lpVtbl -> get_PreviousVisible(This,lItem,pVal)

#define ITreeView_get_FirstVisible(This,pVal)	\
    (This)->lpVtbl -> get_FirstVisible(This,pVal)

#define ITreeView_put_FirstVisible(This,newVal)	\
    (This)->lpVtbl -> put_FirstVisible(This,newVal)

#define ITreeView_get_Select(This,pVal)	\
    (This)->lpVtbl -> get_Select(This,pVal)

#define ITreeView_put_Select(This,newVal)	\
    (This)->lpVtbl -> put_Select(This,newVal)

#define ITreeView_get_AllowEdit(This,pVal)	\
    (This)->lpVtbl -> get_AllowEdit(This,pVal)

#define ITreeView_put_AllowEdit(This,newVal)	\
    (This)->lpVtbl -> put_AllowEdit(This,newVal)

#define ITreeView_get_Tabstop(This,pVal)	\
    (This)->lpVtbl -> get_Tabstop(This,pVal)

#define ITreeView_put_Tabstop(This,newVal)	\
    (This)->lpVtbl -> put_Tabstop(This,newVal)

#define ITreeView_SetFocus(This)	\
    (This)->lpVtbl -> SetFocus(This)

#define ITreeView_Show(This)	\
    (This)->lpVtbl -> Show(This)

#define ITreeView_Hide(This)	\
    (This)->lpVtbl -> Hide(This)

#define ITreeView_put_AllowEvent(This,newVal)	\
    (This)->lpVtbl -> put_AllowEvent(This,newVal)

#define ITreeView_get_AllowEventAsDefault(This,pVal)	\
    (This)->lpVtbl -> get_AllowEventAsDefault(This,pVal)

#define ITreeView_put_AllowEventAsDefault(This,newVal)	\
    (This)->lpVtbl -> put_AllowEventAsDefault(This,newVal)

#define ITreeView_get_SelectionDisplay(This,pVal)	\
    (This)->lpVtbl -> get_SelectionDisplay(This,pVal)

#define ITreeView_put_SelectionDisplay(This,newVal)	\
    (This)->lpVtbl -> put_SelectionDisplay(This,newVal)

#define ITreeView_get_AutoExpand(This,pVal)	\
    (This)->lpVtbl -> get_AutoExpand(This,pVal)

#define ITreeView_put_AutoExpand(This,newVal)	\
    (This)->lpVtbl -> put_AutoExpand(This,newVal)

#define ITreeView_get_TreePath(This,lItem,pVal)	\
    (This)->lpVtbl -> get_TreePath(This,lItem,pVal)

#define ITreeView_StartEdit(This,lItem,pEdit)	\
    (This)->lpVtbl -> StartEdit(This,lItem,pEdit)

#define ITreeView_EndEdit(This,lDeny)	\
    (This)->lpVtbl -> EndEdit(This,lDeny)

#define ITreeView_get_FontName(This,pVal)	\
    (This)->lpVtbl -> get_FontName(This,pVal)

#define ITreeView_put_FontName(This,newVal)	\
    (This)->lpVtbl -> put_FontName(This,newVal)

#define ITreeView_get_FontSize(This,pVal)	\
    (This)->lpVtbl -> get_FontSize(This,pVal)

#define ITreeView_put_FontSize(This,newVal)	\
    (This)->lpVtbl -> put_FontSize(This,newVal)

#define ITreeView_get_FontBold(This,pVal)	\
    (This)->lpVtbl -> get_FontBold(This,pVal)

#define ITreeView_put_FontBold(This,newVal)	\
    (This)->lpVtbl -> put_FontBold(This,newVal)

#define ITreeView_AddContextItem(This,bText)	\
    (This)->lpVtbl -> AddContextItem(This,bText)

#define ITreeView_RemoveContextItem(This,lIndex)	\
    (This)->lpVtbl -> RemoveContextItem(This,lIndex)

#define ITreeView_ClearContext(This)	\
    (This)->lpVtbl -> ClearContext(This)

#define ITreeView_get_Style(This,pVal)	\
    (This)->lpVtbl -> get_Style(This,pVal)

#define ITreeView_put_Style(This,newVal)	\
    (This)->lpVtbl -> put_Style(This,newVal)

#define ITreeView_get_Version(This,pVal)	\
    (This)->lpVtbl -> get_Version(This,pVal)

#define ITreeView_get_hWnd(This,pVal)	\
    (This)->lpVtbl -> get_hWnd(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_AddImage_Proxy( 
    ITreeView __RPC_FAR * This,
    BSTR bFilename);


void __RPC_STUB ITreeView_AddImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_RemoveImage_Proxy( 
    ITreeView __RPC_FAR * This,
    long lIndex);


void __RPC_STUB ITreeView_RemoveImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_UseImages_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_UseImages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_UseImages_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_UseImages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_UseSelectedImages_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_UseSelectedImages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_UseSelectedImages_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_UseSelectedImages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_AddItem_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [optional][in] */ long lParent,
    /* [optional][in] */ long lInsertAfter,
    /* [in] */ BSTR bText,
    /* [optional][in] */ long lParam,
    /* [optional][in] */ long lImage,
    /* [optional][in] */ long lSelectedImage,
    /* [retval][out] */ long __RPC_FAR *pRet);


void __RPC_STUB ITreeView_AddItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_HasLines_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_HasLines_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_HasLines_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_HasLines_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_HasButtons_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_HasButtons_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_HasButtons_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_HasButtons_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_Border_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_Border_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_Border_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_Border_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_Clear_Proxy( 
    ITreeView __RPC_FAR * This);


void __RPC_STUB ITreeView_Clear_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_Count_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_DeleteItem_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem);


void __RPC_STUB ITreeView_DeleteItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_RootLines_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_RootLines_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_RootLines_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_RootLines_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_ExpandItem_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem);


void __RPC_STUB ITreeView_ExpandItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_CollapseItem_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem);


void __RPC_STUB ITreeView_CollapseItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_ToggleItem_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem);


void __RPC_STUB ITreeView_ToggleItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_MakeVisible_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem);


void __RPC_STUB ITreeView_MakeVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_FirstItem_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_FirstItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_ItemText_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_ItemText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_ItemText_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [in] */ BSTR newVal);


void __RPC_STUB ITreeView_put_ItemText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_ItemImage_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_ItemImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_ItemImage_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_ItemImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_ItemSelectedImage_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_ItemSelectedImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_ItemSelectedImage_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_ItemSelectedImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_ItemValue_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_ItemValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_ItemValue_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_ItemValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_Indent_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_Indent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_Indent_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_Indent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_Child_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_Child_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_Parent_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_Parent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_NextSibling_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_NextSibling_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_PreviousSibling_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_PreviousSibling_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_NextVisible_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_NextVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_PreviousVisible_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_PreviousVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_FirstVisible_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_FirstVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_FirstVisible_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_FirstVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_Select_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_Select_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_Select_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_Select_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_AllowEdit_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_AllowEdit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_AllowEdit_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_AllowEdit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_Tabstop_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_Tabstop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_Tabstop_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_Tabstop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_SetFocus_Proxy( 
    ITreeView __RPC_FAR * This);


void __RPC_STUB ITreeView_SetFocus_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_Show_Proxy( 
    ITreeView __RPC_FAR * This);


void __RPC_STUB ITreeView_Show_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_Hide_Proxy( 
    ITreeView __RPC_FAR * This);


void __RPC_STUB ITreeView_Hide_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_AllowEvent_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_AllowEvent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_AllowEventAsDefault_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_AllowEventAsDefault_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_AllowEventAsDefault_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_AllowEventAsDefault_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_SelectionDisplay_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_SelectionDisplay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_SelectionDisplay_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_SelectionDisplay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_AutoExpand_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_AutoExpand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_AutoExpand_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_AutoExpand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_TreePath_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_TreePath_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_StartEdit_Proxy( 
    ITreeView __RPC_FAR * This,
    long lItem,
    /* [retval][out] */ long __RPC_FAR *pEdit);


void __RPC_STUB ITreeView_StartEdit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_EndEdit_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [optional][in] */ long lDeny);


void __RPC_STUB ITreeView_EndEdit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_FontName_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_FontName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_FontName_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ITreeView_put_FontName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_FontSize_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_FontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_FontSize_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_FontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_FontBold_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_FontBold_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_FontBold_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_FontBold_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_AddContextItem_Proxy( 
    ITreeView __RPC_FAR * This,
    BSTR bText);


void __RPC_STUB ITreeView_AddContextItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_RemoveContextItem_Proxy( 
    ITreeView __RPC_FAR * This,
    long lIndex);


void __RPC_STUB ITreeView_RemoveContextItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITreeView_ClearContext_Proxy( 
    ITreeView __RPC_FAR * This);


void __RPC_STUB ITreeView_ClearContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_Style_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_Style_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ITreeView_put_Style_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ITreeView_put_Style_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_Version_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_Version_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ITreeView_get_hWnd_Proxy( 
    ITreeView __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ITreeView_get_hWnd_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITreeView_INTERFACE_DEFINED__ */



#ifndef __MGCETREEVIEWLib_LIBRARY_DEFINED__
#define __MGCETREEVIEWLib_LIBRARY_DEFINED__

/* library MGCETREEVIEWLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_MGCETREEVIEWLib;

#ifndef ___ITreeViewEvents_DISPINTERFACE_DEFINED__
#define ___ITreeViewEvents_DISPINTERFACE_DEFINED__

/* dispinterface _ITreeViewEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__ITreeViewEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("7CCCDEF1-6B04-11D3-99B4-0040055A16DF")
    _ITreeViewEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _ITreeViewEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _ITreeViewEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _ITreeViewEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _ITreeViewEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _ITreeViewEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _ITreeViewEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _ITreeViewEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _ITreeViewEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _ITreeViewEventsVtbl;

    interface _ITreeViewEvents
    {
        CONST_VTBL struct _ITreeViewEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _ITreeViewEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _ITreeViewEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _ITreeViewEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _ITreeViewEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _ITreeViewEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _ITreeViewEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _ITreeViewEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___ITreeViewEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_TreeView;

#ifdef __cplusplus

class DECLSPEC_UUID("7CCCDEF0-6B04-11D3-99B4-0040055A16DF")
TreeView;
#endif
#endif /* __MGCETREEVIEWLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
