/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Sep 21 01:52:09 2001
 */
/* Compiler settings for MGCEHCtrl.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IIPAddress = {0xD1E30FC9,0x671E,0x11D3,{0x99,0xAC,0x00,0x40,0x05,0x5A,0x16,0xDF}};


const IID IID_IHTML = {0xEE1C2477,0x6720,0x11D3,{0x99,0xAC,0x00,0x40,0x05,0x5A,0x16,0xDF}};


const IID LIBID_MGCEHCTRLLib = {0xD1E30FBD,0x671E,0x11D3,{0x99,0xAC,0x00,0x40,0x05,0x5A,0x16,0xDF}};


const CLSID CLSID_IPAddress = {0xD1E30FCA,0x671E,0x11D3,{0x99,0xAC,0x00,0x40,0x05,0x5A,0x16,0xDF}};


const IID DIID__IHTMLEvents = {0xEE1C2479,0x6720,0x11D3,{0x99,0xAC,0x00,0x40,0x05,0x5A,0x16,0xDF}};


const CLSID CLSID_HTML = {0xEE1C2478,0x6720,0x11D3,{0x99,0xAC,0x00,0x40,0x05,0x5A,0x16,0xDF}};


#ifdef __cplusplus
}
#endif

