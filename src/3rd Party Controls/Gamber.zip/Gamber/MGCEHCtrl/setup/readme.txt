
Welcome to MGCENet setup! MGCENet provides several controls to applications capable of using objects such as NS Basic. Included with this package are:

IP Address control
HTML control

Control documentation and NS Basic example source code are located in the "\My Documents" folder in text format.


NS Basic is (c) NS Basic Corporation
Windows CE is (c) Microsoft Corporation.
MGCENet is by Mark Gamber, September 1999
